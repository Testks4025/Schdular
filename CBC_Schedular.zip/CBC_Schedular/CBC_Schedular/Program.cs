﻿
using CBC_Schedular;
using CBC_Schedular.Data.Contexts;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using static CBC_Schedular.Worker;


IHost host = Host.CreateDefaultBuilder(args)
    .ConfigureLogging(logging =>
    {
        logging.ClearProviders();
        logging.AddConsole();  // ✅ still log to console
        logging.AddFile("Logs/app_{Date}.log"); // ✅ log to files
    })
    .ConfigureServices((context, services) =>
    {
        // Database
        services.AddDbContext<MyDbContext>(options =>
    options.UseNpgsql(context.Configuration.GetConnectionString("DefaultConnection")));

        services.AddHostedService<Worker>();


        // ✅ Configure SMTP settings
        services.Configure<SmtpSettings>(context.Configuration.GetSection("Smtp"));
    })
    .Build();

await host.RunAsync();
