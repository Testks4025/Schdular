﻿using CBC_Schedular.Data.Contexts;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using System;
using System.Net.Mail;

namespace CBC_Schedular;

public class Worker : BackgroundService
{
    private readonly ILogger<Worker> _logger;
    private readonly IServiceScopeFactory _scopeFactory;
    private readonly SmtpSettings _smtpSettings;

    public Worker(
        ILogger<Worker> logger,
    IServiceScopeFactory scopeFactory,
        IOptions<SmtpSettings> smtpOptions)
    {
        _logger = logger;
        _scopeFactory = scopeFactory;
        _smtpSettings = smtpOptions.Value;
    }
    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        _logger.LogInformation("CBC Scheduler Worker starting at: {Time}", DateTimeOffset.Now);

        try
        {
            while (!stoppingToken.IsCancellationRequested)
            {
                await CheckAndSendReapplyMails();
                DateTime now = DateTime.Now;
                //Enable if you runs 3 months service for weekly basis
                //DateTime nextRun = GetNextRunTime(now);
                //Enable if you runs 6 months service for daily basis
                DateTime nextRun = GetNextRunDayTime(now);
                TimeSpan delay = nextRun - now;

                _logger.LogInformation(
                    "Service sleeping for {delay} until next run at {nextRun}",
                    delay,
                    nextRun);

                await Task.Delay(delay, stoppingToken);
            }
        }
        catch (Exception ex) when (ex is not OperationCanceledException)
        {
            _logger.LogCritical(ex, "Fatal error in scheduler worker");
            throw;
        }
        
            _logger.LogInformation("CBC Scheduler Worker stopped at: {Time}", DateTimeOffset.Now);
        
    }
    private async Task CheckAndSendReapplyMails()
    {

        using var scope = _scopeFactory.CreateScope();
        var dbContext = scope.ServiceProvider.GetRequiredService<MyDbContext>();

        DateTime today = DateTime.UtcNow.Date;
        DateTime threeMonthsFromNow = today.AddMonths(3);

        _logger.LogInformation("Checking expiring certificates between {today} and {threeMonthsFromNow}", today, threeMonthsFromNow);
        Console.WriteLine($"Checking expiring certificates between {today} and {threeMonthsFromNow}");
        DateTime sixMonthsFromNow = today.AddMonths(6);
        DateTime sixMonthsEnd = sixMonthsFromNow.AddDays(1);

        //Case 1: Expiring soon
        var expiringHospitals_three = await (from h in dbContext.InstituteRegistraions
                                             join c in dbContext.CertifiedHospital on h.id equals c.hospital_id
                                             join u in dbContext.UserMasters on h.userid equals u.id
                                             where c.valid_to >= today
                                                   && c.valid_to <= threeMonthsFromNow
                                                   && h.is_reapply_renew == false
                                                   && h.stageid == 170
                                             select new
                                             {
                                                 h.org_name,
                                                 h.application_no,
                                                 ExpiryDate = c.valid_to,
                                                 Email = u.email,
                                                 h.nodal_officer
                                             }).ToListAsync();
        _logger.LogInformation("Found {count} hospitals with expiring certificates", expiringHospitals_three.Count);
        Console.WriteLine($"Found {expiringHospitals_three.Count} hospitals with expiring certificates");

        var expiringHospitals_six = await (from h in dbContext.InstituteRegistraions
                                           join c in dbContext.CertifiedHospital on h.id equals c.hospital_id
                                           join u in dbContext.UserMasters on h.userid equals u.id
                                           where c.valid_to >= sixMonthsFromNow
                                                 && c.valid_to < sixMonthsEnd
                                                 && h.is_reapply_renew == false
                                                 && h.stageid == 170
                                           select new
                                           {
                                               h.org_name,
                                               h.application_no,
                                               ExpiryDate = c.valid_to,
                                               Email = u.email,
                                               h.nodal_officer
                                           }).ToListAsync();



        _logger.LogInformation("Found {count} hospitals with expired certificates", expiringHospitals_six.Count);
        Console.WriteLine($"Found {expiringHospitals_six.Count} hospitals with expired certificates");
        // Load template once
        string mailTemplate = "";
        //Enable if you runs 3 months service for weekly basis
        //if (expiringHospitals_three != null && expiringHospitals_three.Count != 0)
        //{
        //    mailTemplate = ReadFile("./wwwroot/EmailTemplates/ReaccreditationReminder.html");
        //}
        //Enable if you runs 6 months service for daily basis
        if (expiringHospitals_six != null && expiringHospitals_six.Count != 0)
        {
            mailTemplate = ReadFile("./wwwroot/EmailTemplates/ReaccreditationT6Reminder.html");
        }
        //Enable if you runs 3 months service for weekly basis
        //foreach (var hosp in expiringHospitals_three)
        //{
        //    await SendReapplyMail(hosp.Email, hosp.nodal_officer, hosp.org_name, hosp.application_no, hosp.ExpiryDate.Value, isExpired: false, mailTemplate);
        //}
        //Enable if you runs 6 months service for daily basis
        foreach (var hosp in expiringHospitals_six)
        {
            await SendReapplyMail(hosp.Email, hosp.nodal_officer, hosp.org_name, hosp.application_no, hosp.ExpiryDate.Value, isExpired: false, mailTemplate);
        }
    }

    private async Task SendReapplyMail(string toEmail, string nodelofficer, string orgName, string appNo, DateTime expiryDate, bool isExpired, string template)
    {
        try
        {
            // ✅ Always work on a copy
            string mailBody = template;

            // Replace placeholders
            mailBody = mailBody.Replace("{{nodelofficer}}", nodelofficer ?? "")
                               .Replace("{{orgname}}", orgName ?? "")
                               .Replace("{{appno}}", appNo ?? "")
                               .Replace("{{expirydate}}", expiryDate.ToString("dd/MM/yyyy"));

            using var mail = new MailMessage
            {
                From = new MailAddress("testks4025@gmail.com"),
                Subject = isExpired
                    ? "Action Required: Certificate Expired"
                    : "Reminder to apply for NSCSTI re-accreditation",
                Body = mailBody,
                IsBodyHtml = true
            };

            // test override
            toEmail = "testks4025@gmail.com";
            mail.To.Add(toEmail);

            // Primary recipient (in To:)
            if (!string.IsNullOrWhiteSpace(toEmail))
            {
                mail.To.Add(toEmail);
            }

            // CC recipients change the CC mail's as per the requirement or setup configuration settings
            string[] ccMails = {
    "skamuni@keypoint-tech.com" 
};

            foreach (var cc in ccMails)
            {
                if (!string.IsNullOrWhiteSpace(cc))
                    mail.CC.Add(cc.Trim());
            }

            using var smtp = new SmtpClient("smtp.gmail.com")
            {
                Port = 587,
                Credentials = new System.Net.NetworkCredential("testks4025@gmail.com", "dyup uurv cwkm aacp"),
                EnableSsl = true
            };

            await smtp.SendMailAsync(mail);

            _logger.LogInformation("Mail sent to {email} for Application No: {appNo}", toEmail, appNo);
            Console.WriteLine($"Mail sent to {toEmail} for Application No: {appNo}");
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Mail send failed for {email}", toEmail);
            Console.WriteLine($"Mail send failed for {toEmail} : {ex.Message}");
        }
    }

    // Utility
    public static string ReadFile(string fileName)
    {
        try
        {
            if (!File.Exists(fileName))
                throw new FileNotFoundException("File not found", fileName);

            return File.ReadAllText(fileName);
        }
        catch
        {
            throw; // keep stack trace
        }
    }
    private static DateTime GetNextRunTime(DateTime now)
    {
        // Example: Next Monday 03:00 AM (IST)
        DayOfWeek targetDay = DayOfWeek.Monday;
        TimeSpan targetTime = new TimeSpan(3, 0, 0); // 03:00 AM

        int daysUntilTarget = ((int)targetDay - (int)now.DayOfWeek + 7) % 7;
        if (daysUntilTarget == 0 && now.TimeOfDay >= targetTime)
        {
            daysUntilTarget = 7;
        }

        DateTime nextRun = now.Date
            .AddDays(daysUntilTarget)
            .Add(targetTime);

        return nextRun;
    }

    private static DateTime GetNextRunDayTime(DateTime now)
    {
        DateTime today3AM = now.Date.AddHours(3);

        // If current time is already past 3 AM, schedule for tomorrow
        if (now >= today3AM)
        {
            return today3AM.AddDays(1);
        }

        return today3AM;
    }


    public class SmtpSettings
    {
        public string Host { get; set; }
        public int Port { get; set; }
        public string User { get; set; }
        public string Password { get; set; }
        public bool EnableSsl { get; set; }
        public string From { get; set; }
        public List<string> CcMails { get; set; }
    }

}
