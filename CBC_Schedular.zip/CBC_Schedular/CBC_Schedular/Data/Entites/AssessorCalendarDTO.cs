﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CBC_Schedular.Data.Entites
{
    public class AssessorCalendarDTO
    {
        public long id { get; set; }
        public long? assessorid { get; set; }
        public string asrstatus { get; set; } // available, not-available
        public DateTime? datevalue { get; set; }
    }

    public class AssessorCalendarSearchResponse
    {
        public long total { get; set; }
        public int rowCount { get; set; }
        public int current { get; set; }
        public List<AssessorCalendarDTO> rows { get; set; }
    }

    public class AssessorCalendarSearchItems
    {
        public int? limit { get; set; }
        public int? offset { get; set; }
        public long? assessorid { get; set; }
        public string asrstatus { get; set; }
    }

    public class AssessorCalendarItem
    {
        public long id { get; set; }
        public long? assessorid { get; set; }
        public string title { get; set; }
        public DateTime? start { get; set; }
    }
    public class AssessorCalendarItemInput
    {

        public long id { get; set; }
        //public long? assessorid { get; set; }
        public string title { get; set; }
        public DateTime? start { get; set; }
        public string startenddate { get; set; }
    }

    public class AssessorCalendarResponse
    {
        public AssessorCalendarResponse()
        {
            this.Item = new List<AssessorCalendarItem>();
        }
        public string Message { get; set; }
        public List<AssessorCalendarItem> Item { get; set; }
    }

    public class EntityOperationCalendarResult
    {
        public long id { get; set; }
        public bool isSuccess { get; set; }
        public string Message { get; set; }
        public string Good { get; set; }
        public string Bad { get; set; }

    }

}
