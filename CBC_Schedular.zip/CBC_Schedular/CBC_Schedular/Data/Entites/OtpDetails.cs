﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CBC_Schedular.Data.Entites
{
   public class OtpDetails
    {
        public String institute_name { get; set; }
        public long? institute_id { get; set; }
        public String mobile { get; set; }
        public String email { get; set; }
        public String otp { get; set; }
    }
}
