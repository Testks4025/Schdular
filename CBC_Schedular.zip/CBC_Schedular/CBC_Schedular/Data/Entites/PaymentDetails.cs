﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CBC_Schedular.Data.Entites
{
    public class PaymentDetails
    {
        public PaymentDetails()
        {
            this.billing_info = new BillingInfo();
            this.shipping_info = new ShippingInfo();
            this.payment_summary = new PaymentSummary();
            this.all_paydetails = new List<PayCollectionDetails>();
        }

        public String hospital_type { get; set; }

        public String sanctioned_bed_no { get; set; }

        public BillingInfo billing_info { get; set; }
        public ShippingInfo shipping_info { get; set; }
        public PaymentSummary payment_summary { get; set; }

        public List<PayCollectionDetails> all_paydetails { get; set; }

        public long? hospid { get; set; } // rrc
        public long? userid { get; set; } // rrc
        public long? stageid { get; set; } // rrc
    }
    public class BillingInfo
    {
        public String org_name { get; set; }
        public String country { get; set; }
        public String state { get; set; }
        public String district { get; set; }
        public String email { get; set; }
        public String mobileno { get; set; }
        public String pincode { get; set; }
        public String address { get; set; }
        public String pan { get; set; }
        public String tan { get; set; }
        public String tradename { get; set; }
        public String gstin { get; set; }
        public String gstno { get; set; }
        public String gstcertficate { get; set; }

        public String city { get; set; } // rrc
    }
    public class ShippingInfo
    {
        public String name { get; set; }
        public String country { get; set; }
        public String state { get; set; }
        public String district { get; set; }
        public String contactno { get; set; }
        public String pincode { get; set; }
        public String address { get; set; }



    }
    public class PaymentSummary
    {
        public Boolean tds_amount { get; set; }
        public String qci_pan { get; set; }
        public String qci_tan { get; set; }
        public String qci_gstin { get; set; }

    }

    public class PayCollectionDetails
    {
        public long id { get; set; }
        public string application_type { get; set; }
        public decimal? amount { get; set; }
        public long? transaction_no { get; set; }
        public string payment_mode { get; set; }
        public DateTime? payment_date { get; set; }
    }

}
