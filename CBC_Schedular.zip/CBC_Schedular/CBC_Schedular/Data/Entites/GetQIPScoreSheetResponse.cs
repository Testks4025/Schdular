﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CBC_Schedular.Data.Entites
{
    public class GetQIPScoreSheetResponse
    {
        public long InstituteId { get; set; }
        public List<QIPScoreSheetModel> Metrics { get; set; }
    }
    public class QIPScoreSheetModel
    {
        public int SrNo { get; set; }
        public string Pillar { get; set; }
        public int PillarWeightage { get; set; }
        public string MetricNo { get; set; }
        public int MaximumStage { get; set; }
        public int SimulatedScore { get; set; }
        public double Score { get; set; }
        public double PotentialGain { get; set; }
        public string HealthStatus { get; set; }
        public int? NSCSTI20Mapping { get; set; }

        public double PillarAverage { get; set; }
    }



}
