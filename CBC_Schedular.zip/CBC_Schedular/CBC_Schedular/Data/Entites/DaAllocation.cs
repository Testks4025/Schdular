﻿using CBC_Schedular.Data.Entites.HospitalSections;
using System;
using System.Collections.Generic;
using System.Text;

namespace CBC_Schedular.Data.Entites
{
   public class DaAllocation
    {

      public long hospital_id { get; set; }
        public long da_id { get; set; }

        public DateStruct assessment_date { get; set; }
        
    }
}
