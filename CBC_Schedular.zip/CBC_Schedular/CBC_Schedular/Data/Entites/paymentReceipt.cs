﻿using CBC_Schedular.Data.Entites.Common;
using CBC_Schedular.Data.Entites.HospitalSections;
using System;
using System.Collections.Generic;
using System.Text;

namespace CBC_Schedular.Data.Entites
{
    public class paymentReceipt
    {

        public long institute_id { get; set; }
        public String receipt_number { get; set; }
        public String amount { get; set; }
        public DateStruct date_of_pymt { get; set; }
        public DateTime payment_date { get; set; }
        public String to_whom_pymt_done { get; set; }
        public String paymt_receipt_doc { get; set; }
        public String payment_type { get; set; }


    }

    public class pament_ReceiptList
    {
        public int current { get; set; }
        public long total { get; set; }
        public int rowcount { get; set; }
        public List<paymentReceipt> rows { get; set; }
    }
    public class PaymentReceiptFilter
    {
        public String receipt_number { get; set; }
        public String search_type { get; set; }
    
        public Int32? offset { get; set; }
        public Int32? limit { get; set; }
       
    }


}
