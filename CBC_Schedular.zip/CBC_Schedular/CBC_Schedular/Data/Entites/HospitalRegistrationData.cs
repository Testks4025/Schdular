﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CBC_Schedular.Data.Entites
{
    public class HospitalRegistrationData
    {
        public String type { get; set; }
        public String institute_type { get; set; }
        public String ministry { get; set; }
        public String department { get; set; }
        public String institute_name { get; set; }
        public String state { get; set; }
        public String district { get; set; }
        public String city { get; set; }
        public String nodal { get; set; }
        public String designation { get; set; }
        public String email { get; set; }
        public String mobile { get; set; }
    }
}
