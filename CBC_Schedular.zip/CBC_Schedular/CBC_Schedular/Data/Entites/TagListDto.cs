﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CBC_Schedular.Data.Entites
{
    public class TagListDto
    {
        public long institute_id { get; set; }
        public String tag_1 { get; set; }
        public String tag_2 { get; set; }
        public String tag_3 { get; set; }
        public String tag_4 { get; set; }
        public String tag_5 { get; set; }
        public String tag_6 { get; set; }
    }
}
