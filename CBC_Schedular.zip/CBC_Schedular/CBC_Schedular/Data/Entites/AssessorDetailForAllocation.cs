﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CBC_Schedular.Data.Entites
{
  public  class AssessorDetailForAllocation
    {
        public long assr_id { get; set; }
        public String assr_name { get; set; }

        public String qualification { get; set; }
        public decimal? experience { get; set; }

        public String city { get; set; }
        public String district { get; set; }
        public String state { get; set; }

        public String specilities { get; set; }

        public int da_completed_count { get; set; }
        public long? oa_completed_count { get; set; }

        public String photourl { get; set; }


    }
}
