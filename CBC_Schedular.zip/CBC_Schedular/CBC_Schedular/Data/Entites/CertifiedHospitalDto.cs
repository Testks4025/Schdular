﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CBC_Schedular.Data.Entites
{
   public class CertifiedHospitalListDto
    {

       public String reference_id { get; set; }
        public String organisation_name { get; set; }
        public String application_no { get; set; }
        public String city { get; set; }
        public String state { get; set; }
        public String organisation_type { get; set; }
        public String certificate_no { get; set; }
        public String valid_from { get; set; }
        public String valid_to { get; set; }
        public String remark { get; set; }
        public String address { get; set; }
        








        
    }
}
