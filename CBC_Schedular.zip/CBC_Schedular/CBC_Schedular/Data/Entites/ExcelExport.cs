﻿using System;
using System.Collections.Generic;
using System.Text;
using CBC_Schedular.Data.Entites.InstituteSections;

namespace CBC_Schedular.Data.Entites
{
    public class ExcelExportApplicationForm
    {
        public ExcelExportApplicationForm()
        {
            this.application_form = new ApplicationFormDTO();
        }
        public long id { get; set; }
        public long da_usr_id { get; set; }
        public long da_usr_id_onsite { get; set; }
        public long institute_id { get; set; }
        public String application_no { get; set; }
        public long stage_id { get; set; }
        public String institute_name { get; set; }
        public String affiliation { get; set; }
        public int? city_id { get; set; }
        public String state_code { get; set; }
        public String address { get; set; }
        public bool status { get; set; }
        public String state { get; set; }
        public String city { get; set; }
        public String ministry { get; set; }
        public String department { get; set; }
        public String designation { get; set; }
        public String nodal_officer { get; set; }
        public String email { get; set; }
        public String mobile { get; set; }
        public String district { get; set; }
        public String state_central { get; set; }
        public String institute_type { get; set; }
        public long agency_id { get; set; }
        public long agency_id_onsite { get; set; }



        public ApplicationFormDTO application_form { get; set; }
    }

    public class ExcelExportScores
    {
        public long institute_id { get; set; }
        public long da_ussr_id { get; set; }
        public String application_no { get; set; }
        public long stage_id { get; set; }
        public String institute_name { get; set; }
        public bool status { get; set; }

        public decimal pillar_1_self_assmt_score { get; set; }
        public decimal pillar_2_self_assmt_score { get; set; }
        public decimal pillar_3_self_assmt_score { get; set; }
        public decimal pillar_4_self_assmt_score { get; set; }
        public decimal pillar_5_self_assmt_score { get; set; }
        public decimal pillar_6_self_assmt_score { get; set; }
        public decimal pillar_7_self_assmt_score { get; set; }
        public decimal pillar_8_self_assmt_score { get; set; }


        public decimal pillar_1_onsite_assmt_score { get; set; }
        public decimal pillar_2_onsite_assmt_score { get; set; }
        public decimal pillar_3_onsite_assmt_score { get; set; }
        public decimal pillar_4_onsite_assmt_score { get; set; }
        public decimal pillar_5_onsite_assmt_score { get; set; }
        public decimal pillar_6_onsite_assmt_score { get; set; }
        public decimal pillar_7_onsite_assmt_score { get; set; }
        public decimal pillar_8_onsite_assmt_score { get; set; }

        public long institute_agency { get; set; }
        public long institute_agency_onsite { get; set; }

    }

    public class SectionExcelExport
    {
        public long id { get; set; }
        public string section_name { get; set; }
        public int section_score { get; set; }
    }
}
