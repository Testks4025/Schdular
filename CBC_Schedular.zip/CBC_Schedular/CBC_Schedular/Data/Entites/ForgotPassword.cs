﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CBC_Schedular.Data.Entites
{
   public class ForgotPassword
    {
        public ForgotPassword()
        {

        }

        public String email { get; set; }
        public String uid { get; set; }

        public String password { get; set; }
    }
}
