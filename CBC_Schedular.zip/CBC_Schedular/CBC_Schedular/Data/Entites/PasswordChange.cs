﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CBC_Schedular.Data.Entites
{
   public class PasswordChange
    {

        public String Password { get; set; }
    }
}
