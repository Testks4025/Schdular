﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CBC_Schedular.Data.Entites
{
    public class UserMasterDTO
    {
        public long id { get; set; }


        public long roleid { get; set; }
        public String  institute_app_no { get; set; }
        public string firstname { get; set; }
        public string lastname { get; set; }
        public string nodal_officer { get; set; }
        public string email { get; set; }
        public string mobile { get; set; }
        public string userpassword { get; set; }
        public bool? isactive { get; set; }
        public string notes { get; set; }
        public long? otplogid { get; set; }
        public bool isFirstTimeLogin { get; set; }
        public DateTime? creationdate { get; set; }
        public string rolename { get; set; }
       public String app_no { get; set; }
        public int sNo { get; set; }
        public string fullname
        {
            get
            {
                return string.Format("{0} {1}", firstname ?? "", lastname ?? "").Trim();
            }
        }
        public string nodal { get; set; }

        public long desktop_assessor_agency { get; set; }
        public long institute_agency { get; set; }
        public long institute_agency_onsite { get; set; }

        
    }
}
