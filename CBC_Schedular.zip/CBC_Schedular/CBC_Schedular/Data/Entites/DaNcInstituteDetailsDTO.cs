﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CBC_Schedular.Data.Entites
{
   public class DaNcInstituteDetailsDTO
    {

        public long id { get; set; }
        public long institute_id { get; set; }
        public long ques_id { get; set; }
        public long section_id { get; set; }

        public bool? isnc { get; set; }
        public string remarks { get; set; }
        public string reply { get; set; }
       
        public bool? isopen { get; set; }
        public string finalremark { get; set; }
        public DateTime? nccreatedate { get; set; }
        public DateTime? nccreatedatebyda { get; set; }
        public String nccreatedate_string { get; set; }
        public String nccreatedatebyda_string { get; set; }
        public int? ncstage { get; set; }
        public bool? isnc_status { get; set; }
        
        public bool is_active { get; set; }
       
        public bool is_reviewed { get; set; }
        public int? nc_cycle_count { get; set; }
    }

    public class DaNcInstituteDetailsSearchResponse
    {
        public long total { get; set; }
        public int rowCount { get; set; }
        public int current { get; set; }
        public List<DaNcInstituteDetailsDTO> rows { get; set; }
    }
    public class DaNcLatestRecordQuestionWise
    {
        public DaNcInstituteDetailsDTO nc_record { get; set; }
        public int section_nc_count { get; set; }
    }
}
