﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CBC_Schedular.Data.Entites
{
   public class OnsiteAssessmentsRecord
    {
        public long assessment_id { get; set; }
        public DateTime? assessment_date { get; set; }
    }
}
