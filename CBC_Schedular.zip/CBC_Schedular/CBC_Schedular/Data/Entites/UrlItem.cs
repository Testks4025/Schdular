﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CBC_Schedular.Data.Entites
{
    public class UrlItem
    {
        public Int32 id { get; set; }
        public string url { get; set; }
        public string description { get; set; }
        public string org_doc_name { get; set; }

        
    }
}
