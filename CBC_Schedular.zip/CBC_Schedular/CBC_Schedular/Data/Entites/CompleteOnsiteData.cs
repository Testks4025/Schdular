﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CBC_Schedular.Data.Entites
{
    public class CompleteOnsiteData
    {

       public long assessment_id { get; set; }
        public String remark { get; set; }
    }
}
