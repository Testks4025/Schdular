﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CBC_Schedular.Data.Entites
{
   public class InstituteApprovalDTO
    {
        public long institute_id { get; set; }
        public long agency_id { get; set; }
        public long assessor_id { get; set; }
    }
    public class InstituteMetorApprovalDTO
    {
        public long institute_id { get; set; }
        public long mentor_id { get; set; }
    }

}
