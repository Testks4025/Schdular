﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CBC_Schedular.Data.Entites
{
   
    public class CertifiedHospitalDto
    {

        public long hosp_id { get; set; }
        public String reference_id { get; set; }
        public String org_name { get; set; }
        public long state_id { get; set; }
        public String state { get; set; }
        public String certificate_no { get; set; }
        public String type { get; set; }

     //   public String application_no { get; set; }
        public DateTime registration_date { get; set; }
        public String stage { get; set; }
      
        public long stage_id { get; set; }
        public long disrictid { get; set; }
        public String district { get; set; }
        public Boolean status { get; set; }
       public DateTime? valid_from { get; set; }
        public DateTime? valid_to { get; set; }








    }
    public class CertifiedHospitalList
    {
        public int current { get; set; }
        public long total { get; set; }
        public int rowcount { get; set; }
        public List<CertifiedHospitalDto> rows { get; set; }


    }
}
