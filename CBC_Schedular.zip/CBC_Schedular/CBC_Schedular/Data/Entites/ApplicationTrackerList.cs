﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CBC_Schedular.Data.Entites
{
    public class ApplicationTracker
    {
       

        public long institute_id { get; set; }
        public long userid { get; set; }
        public String reference_id { get; set; }
        public String org_name { get; set; }
        public long state_id { get; set; }
        public String state { get; set; }
        public String application_type { get; set; }
        public String type { get; set; }
        public bool can_genrate_certificate { get; set; }
        public bool is_reapply { get; set; }
        public String application_no { get; set; }
        public DateTime registration_date { get; set; }
        public String stage { get; set; }
        public long stage_id { get; set; }
        public Boolean status { get; set; }
        public long hospital_apply_for { get; set; }
        public string NameOfNodalOfficer { get; set; }
        public string EmailOfNodalOfficer { get; set; }
        public string MobileOfNodalOfficer { get; set; }

        public List<HospitalStage> stage_history { get; set; }

        //  public String current_da { get; set; }
        // public long current_da_id { get; set; }
        public String certi_coordinator_no { get; set; }
        public String certi_coordinator_email { get; set; }
        public String certi_coordinator_desig { get; set; }
        public String certi_coordinator_name { get; set; }

        public String org_head_no { get; set; }
        public String org_head_email { get; set; }
        public String org_head_desig { get; set; }
        public String org_head_name { get; set; }

        public string operational_beds { get; set; }
        public string sanctioned_beds { get; set; }
        public String specialities { get; set; }

        public String city { get; set; }
        public String district { get; set; }


        // rrc 
        public bool? oadone { get; set; } // either application is 130/OA Completed OR 190/OA Rejected OR 200/OA Accepted
        public bool? hiddenactionbtn_da { get; set; }
        public bool? hiddenactionbtn_oa { get; set; }
        public bool? hiddenactionbtn_advisory { get; set; }
        public bool? hiddenactionbtn_remark { get; set; }
        public bool? hiddenactionbtn_reject { get; set; }

        public Int32? stageid_timeline_workingdays { get; set; }
        public DateTime? stageid_enddate { get; set; }
        public string workingdaysleft { get; set; }

        // rrc 
        public DateTime? extended_date { get; set; }
        public bool isactive { get; set; }
        public string oa_remarks { get; set; }
        public string oa_asmtdate { get; set; }

        public string oa_primary_asrname { get; set; }
        public string oa_sendoray_asrname { get; set; }

        public string da_remarks { get; set; }

        public string da_remarks_rej { get; set; }

        public string da_asmtdate { get; set; }

        public string da_asrname { get; set; }
        public string da_asrname_onsite { get; set; }
        public string agency_name { get; set; }
        public string agency_name_onsite { get; set; }
        public long da_asr_id { get; set; }
        public long da_asr_id_onsite { get; set; }
        
        public long agency_id { get; set; }
        public long agency_id_onsite { get; set; }

        public string agency_name_qip { get; set; }
        public long agency_id_qip { get; set; }
        public bool is_cbc_institute { get; set; }
        public bool is_da_allocated_cbc_institute { get; set; }
        public String cert_reject_remark { get; set; }
        public String tag_1 { get; set; }
        public String tag_2 { get; set; }
        public String tag_3 { get; set; }

        public String tag_4 { get; set; }
        public String tag_5 { get; set; }
        public String tag_6 { get; set; }
        public DateTime? onsite_assmt_start_date { get; set; }

        public long pendency { get; set; }



    }
    public class applicationTrackerList
    {
        public int current { get; set; }
        public long total { get; set; }
        public int rowcount { get; set; }
        public List<ApplicationTracker> rows { get; set; }

        
    }
    public class ApplicationTrackerExportResponseModel
    {
        public long TotalRecord { get; set; }
        public string Message { get; set; }
        public bool IsSuccess { get; set; }
        public List<ApplicationTrackerExportModel> Data { get; set; }

    }
    public class CommandMethodResponse
    {
        public string Message { get; set; }
        public bool IsSuccess { get; set; }
    }
    public class ApplicationTrackerStageHistoryModel
    {
        public long Id { get; set; }
        public long? UpdateBy { get; set; }
        public long? CreatedBy { get; set; }
        public long? StageId { get; set; }
        public DateTime? StageCreationDate { get; set; }
        public DateTime? StageUpdateDate { get; set; }
    }
    public class ApplicationTrackerExportModel
    {
        public long Id { get; set; }
        public long StageId { get; set; }
        public DateTime RegistrationDate { get; set; }
        public string ApplicationNo { get; set; }
        public string UniqueCallQueryNo { get; set; }
        public string NameOfInstitute { get; set; }
        public string CurrentStage { get; set; }
        public string NameOfDesktopAssessor { get; set; }
        public string EmailOfDesktopAssessor { get;set; }
        public string MobileOfDesktopAssessor { get; set; }
        public string NameOfNodalOfficer { get; set; }
        public string EmailOfNodalOfficer { get; set; }
        public string MobileOfNodalOfficer { get; set; }
        public string AgencyName { get;set; }
        public long agency_id { get; set; }
        public long agency_id_onsite { get; set; }

        //Call Details log table properties
        public string CallerName { get; set; }
        public DateTime? CallingDate { get; set; }
        public string SupportOfCBC { get; set; }
        public string Issue { get; set; }
        public string Organization { get; set; }
        public string InteractionDetails { get; set; }
        public string Medium { get; set; }
        public string MediumOther { get; set; }
        public string IssueOther { get; set; }

        public DateTime? LastStageUpdatedOn { get; set;}
        public ApplicationTrackerStageHistoryModel LastStage { get; set; }

        public int AgingDays
        {
            get
            {
                if (LastStage != null && LastStage.StageCreationDate.HasValue)
                {
                   // LastStageUpdatedOn = LastStage.StageUpdateDate.Value;
                    return  (DateTime.Now.Date -  Convert.ToDateTime(LastStage.StageCreationDate.Value)).Days + 1;
                }
                else
                    return 0;

            }
        }
    }

}
