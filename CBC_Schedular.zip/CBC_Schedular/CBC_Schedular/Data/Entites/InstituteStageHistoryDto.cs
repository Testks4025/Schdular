﻿using CBC_Schedular.Data.Entites.HospitalSections;
using System;
using System.Collections.Generic;
using System.Text;

namespace CBC_Schedular.Data.Entites
{
    public class InstituteStageHistoryDto
    {
        public InstituteStageHistoryDto()
        {
            this.stage = new List<InstituteStage>();
        }
        public bool is_cbc_institute { get; set; }
        public String application_no { get; set; }
        public String institute_name { get; set; }
        public long stage_id { get; set; }

        public String nodal_officer_name { get; set; }
        public String email { get; set; }
        public String mobile { get; set; }
        public String da_name { get; set; }

        public String da_agency { get; set; }
        public String oa_agency { get; set; }
        public String qip_agency { get; set; }

        public List<InstituteStage> stage { get; set; }

        public String tag_1 { get; set; }
        public String tag_2 { get; set; }
        public String tag_3 { get; set; }
        public String tag_4 { get; set; }
        public String tag_5 { get; set; }
        public String tag_6 { get; set; }

        public String ministry { get; set; }
        public String department { get; set; }
        public String state { get; set; }
        public String district { get; set; }
        public String callername { get; set; }
        public String? intercationdetails { get; set; }
        public String? supportofcbc { get; set; }
        public String calling_dateString { get; set; }
        public DateStruct? calling_date { get; set; }

        public string issue { get; set; }
        public string medium { get; set; }
        public string med_other { get; set; }
        public string issue_othr { get; set; }


        public int open_nc { get; set; }


    }
    public class InstituteStage
    {
        public long stage_id { get; set; }
        public String stage { get; set; }
        public DateTime? stage_date { get; set; }

        public String stage_date_string
        {
            get
            {
                if (stage_date == null)
                {
                    return "";
                }
                else
                {
                    return Convert.ToDateTime(stage_date).ToString("dd/MM/yyyy");
                }

            }
        }
    }

}
