﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CBC_Schedular.Data.Entites
{
    public class HospitalQuestionBankDTO
    {
        public long id { get; set; }
        public long? section_id { get; set; }
        public string section_name { get; set; }
        public long ques_stndrd_code { get; set; }
        public string stndrd_code_text { get; set; }
        public string ques_text { get; set; }
        public string ques_help_text { get; set; }
        public string question_property { get; set; }
    }

    public class HospitalQuestionBankResponse
    {
       public HospitalQuestionBankResponse()
        {
            this.queList = new List<HospitalQuestionBankDTO>();
        }
        public long total { get; set; }
        public long current { get; set; }
        public long rowCount { get; set; }
        public List<HospitalQuestionBankDTO> queList { get; set; }

    }
}
