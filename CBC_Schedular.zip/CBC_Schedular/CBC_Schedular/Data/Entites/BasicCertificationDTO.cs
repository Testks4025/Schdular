﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CBC_Schedular.Data.Entites
{
    public class BasicCertificationDTO
    {
        public long id { get; set; }
        public long hospital_id { get; set; }
        public string organization_type { get; set; }
        public string ayush_system { get; set; }
        public string sanctioned_bed_category { get; set; }
        public string sanctioned_bed_no { get; set; }
    }
}
