﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CBC_Schedular.Data.Entites
{
    public class DropdownInstituteList
    {

        public String institute_name { get; set; }
        public String department { get; set; }
        public String ministry { get; set; }
        public String status { get; set; }
        public String app_no { get; set; }

        




    }
}
