﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CBC_Schedular.Data.Entites
{
    public class CompleteQcDto
    {
        public long institute_id { get; set; }

    }

    public class UpdateQcDataDto
    {
        public long institute_id { get; set; }
        public long assessmentId { get; set; }
        public long ques_id { get; set; }

        public String remark { get; set; }
        public String ques_image_url_update { get; set; }

        

    }


}
