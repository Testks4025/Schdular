﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CBC_Schedular.Data.Entites.HospitalInvoiceReport
{
    public class HospitalInvoiceReportItem
    {
        public long hospitalid { get; set; }
        public string hospitalname { get; set; }
      
      
        public int? noofbed { get; set; }
        public string representative_name { get; set; }

        public string state { get; set; }
        public string statewithcode { get; set; }

        
        public string fulladdress{ get; set; }
        public string address { get; set; }
      

        public string applicationnumber { get; set; }
      

        public decimal? amount { get; set; }
        public bool? ispaid { get; set; }
        public long? trackingid { get; set; } // transaction Id 
        public DateTime? paydate { get; set; }

        public string paydatestr
        {
            get
            {
                if (paydate != null)
                {
                    return paydate != null ? paydate.Value.ToString("dd-MMM-yyyy") : "";

                }
                else
                    return "";
            }
        }

        public string trackingidstr
        {
            get
            {
                if (trackingid != null && trackingid.HasValue == true)
                {
                    return trackingid.ToString();

                }
                else
                    return "";
            }
        }
        public string pan { get; set; }
        public string gstin { get; set; }
        public HospitalInvRptHdrItem header { get; set; }
        public List<HospitalInvRptDetsItem> details { get; set; }
        public List<HospitalInvRptTaxDetsItem> taxdetails { get; set; }
        public List<HospitalInvRptTaxDets4DelhiItem> taxdetails4delhi { get; set; }
        public HospitalInvRptFooterItem Footer { get; set; }
        public HospitalInvRptReceiptItem recipt { get; set; }

        public string type { get; set; }
    }

    public class HospitalInvRptHdrItem
    {
        public long hospitalid { get; set; }
        public string qciname { get; set; }
        public string qciaddress { get; set; }
        public string buyername { get; set; }
        public string buyeraddress { get; set; }
        public bool isdelhi { get; set; }
        public string invoiceno { get; set; }
        public string invdate { get; set; }
        public string pan { get; set; }
        public string gstin { get; set; }
        public string representative_name { get; set; }
        public string state { get; set; }

        public string statewithcode { get; set; }
        


    }

    public class HospitalInvRptDetsItem
    {
        public long hospitalid { get; set; }
        public long srno { get; set; }
        public string srnoshow { get; set; }
        public string particulars { get; set; }
        public string hsnsac { get; set; }
        public string quantity { get; set; }
        public string rate { get; set; }
        public string per { get; set; }
        public decimal? amount { get; set; }

    }

    public class HospitalInvRptTaxDetsItem
    {
        public long hospitalid { get; set; }
        public long srno { get; set; }
        public string hsnsac { get; set; }
        public decimal? taxablevalue { get; set; }
        public decimal? rate { get; set; }
        public string ratestr { get; set; }
        public decimal? amtaftertax { get; set; }
        public decimal? taxamount { get; set; }
        public bool? reporthidden { get; set; }
    }

    public class HospitalInvRptTaxDets4DelhiItem
    {
        public long hospitalid { get; set; }
        public long srno { get; set; }
        public string hsnsac { get; set; }
        public decimal? taxablevalue { get; set; }
        public string taxablevaluestr { get; set; }

        public decimal? centeraltaxrate { get; set; }
        public string centeraltaxratestr { get; set; }
        public decimal? centeraltaxamtaftertax { get; set; }
        public string centeraltaxamtaftertaxstr { get; set; }

        public decimal? statetaxrate { get; set; }
        public string statetaxratestr { get; set; }
        public decimal? statetaxamtaftertax { get; set; }
        public string statetaxamtaftertaxstr { get; set; }

        public decimal? taxamount { get; set; }
        public string taxamountstr { get; set; }
        public bool? reporthidden { get; set; }
    }

    public class HospitalInvRptFooterItem
    {
        public long hospitalid { get; set; }
        public decimal? amount { get; set; }
        public string amountinwords { get; set; }
        public string companyspanno { get; set; }
        public string declr_accountholdername { get; set; }
        public string declr_accountno { get; set; }
        public string declr_bankname { get; set; }
        public string declr_branckaddress { get; set; }
        public string declr_natureofaccount { get; set; }
        public string declr_micrcode { get; set; }
        public string declr_ifsccode { get; set; }
        public string amountinwords2 { get; set; }
    }

    public class HospitalInvRptReceiptItem
    {
        public long hospitalid { get; set; }
        public string applicationno { get; set; }
        public string hospitalname { get; set; }
        public string districtname { get; set; }
        public string statename { get; set; }
        public string city { get; set; }
        public string pin { get; set; }
        public string rcptno { get; set; }
        public decimal? amount { get; set; }
        public string amountinwords { get; set; }
        public DateTime? paydate { get; set; }
        public long? trackingid { get; set; } // transaction Id 

        public string trackingidstr
        {
            get
            {
                if (trackingid != null && trackingid.HasValue == true)
                {
                    return trackingid.ToString();

                }
                else
                    return "";
            }
        }

        public string paydatestr
        {
            get
            {
                if (paydate != null)
                {
                    return paydate != null ? paydate.Value.ToString("dd-MMM-yyyy") : "";

                }
                else
                    return "";
            }
        }

        public string amountstr
        {
            get
            {
                if (amount != null)
                {
                    return "** Rs. " + amount.ToString() + "/-";

                }
                else
                    return "";
            }
        }

        public string transactiondetails
        {
            get
            {
                var ret = "";
                ret = "Being Amount received for " + applicationno + " dated " + paydatestr + " Txn Id " + trackingidstr;
                return ret;
            }
        }

        public string finyr_str { get; set; }

    }
}
