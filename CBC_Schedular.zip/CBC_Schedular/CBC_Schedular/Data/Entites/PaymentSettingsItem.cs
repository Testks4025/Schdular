﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CBC_Schedular.Data.Entites
{
    public class PaymentSettingsItem
    {
        public string merchant_id { get; set; }
        public string workingkey { get; set; }
        public string straccesscode { get; set; }
        public string redirect_url { get; set; }
        public string cancel_url { get; set; }
        public string nonem_redirect_url { get; set; }
        public string nonem_cancel_url { get; set; }
        public decimal payableamount { get; set; }
        public string paymentfor { get; set; }
    }

}
