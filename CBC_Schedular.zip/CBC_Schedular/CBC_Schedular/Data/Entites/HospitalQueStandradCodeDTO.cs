﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CBC_Schedular.Data.Entites
{
    public class HospitalQueStandradCodeDTO
    {
        public long id { get; set; }
        public string organization_type { get; set; }
        public string stndrcode { get; set; }
        public string code { get; set; }
        public string standards { get; set; }
        public string objctve_no { get; set; }
        public string objctve_elmnt { get; set; }
        public long code_id { get; set; }
    }
}
