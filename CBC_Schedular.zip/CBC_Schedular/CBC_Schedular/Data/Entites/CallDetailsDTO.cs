﻿using System;
using System.Collections.Generic;
using System.Text;
using CBC_Schedular.Data.Entites.Common;
using CBC_Schedular.Data.Entites.HospitalSections;


namespace CBC_Schedular.Data.Entites
{
    public class CallDetailsDTO
    {
        public CallDetailsDTO()
        {            
        }
        public long? id { get; set; }
        public long institute_id { get; set; }
        public long agency_id { get; set; }
        public string callername { get; set; }
        public DateStruct? calling_date { get; set; }
        //public DateTime? createdon { get; set; }
        public string? supportofcbc { get; set; }
        public string? issue { get; set; }
        public string? organization { get; set; }
        public string intercationdetails { get; set; }
        public string medium {  get; set; }
        public long stage_id { get; set; }
        public string calling_dateString { get; set; }
        public string med_other { get; set; }
        public string issue_othr { get; set; }
        public string unique_call_query_no { get; set; }

       public DateTime? calling_date_date_format { get; set; }

    }

    public class GetCallDetailsResponseModel: EntityOperationResult
    {
        public CallDetailsDTO Data { get; set; }
    }

    //public class AsrDateStruct
    //{
    //    public int? year { get; set; }
    //    public int? month { get; set; }
    //    public int? day { get; set; }
    //}

    //public class AsrFilter
    //{
    //    public int? limit { get; set; }
    //    public int? offset { get; set; }
    //    public string sort { get; set; }
    //    public string searchtext { get; set; }
    //    public long? stateid { get; set; }
    //    public long? districtid { get; set; }
    //    public string city { get; set; }
    //    public Int32? capacity { get; set; } // rrc Principal Assessor (1), Assessor (2) 
    //    public bool? profile { get; set; }
    //    //public SearchDatee searchdate { get; set; }
    //}

    //public class SearchDatee
    //{
    //    public Data.Entites.HospitalSections.DateStruct from_date { get; set; }
    //    public Data.Entites.HospitalSections.DateStruct to_date { get; set; }
    //}

    //public class AsrSearchResponse
    //{
    //    public long total { get; set; }
    //    public int rowCount { get; set; }
    //    public int current { get; set; }
    //    public List<AssesorDTO> rows { get; set; }
    //}    

    //public class WorkExperienceDTO
    //{
    //    public string experience_years { get; set; }
    //    public string last_org_work { get; set; }
    //}

}
