﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CBC_Schedular.Data.Entites
{
   public class FeedbackDTO
    {
        public AssessorfeedbackDTO feedbk_by_hco_to_assr { get; set; }
        public AssessorSummaryDTO feedbk_assr1_to_assr2 { get; set; }
    }
}
