﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace CBC_Schedular.Data.Entites
{
    public class OANcHospitalOrCenterDetailsDTO
    {
        public long id { get; set; }
        public long hospital_id { get; set; }
        public long assessment_id { get; set; }
        public long form_id { get; set; }

        public long section_id { get; set; }
        public string section_name { get; set; }
        public long ques_id { get; set; }
        //public bool? isNc { get; set; }
        public string remarks { get; set; }
        public string reply { get; set; }
        public string uploadUrl { get; set; }
        public bool? isOpen { get; set; }
        public string finalRemark { get; set; }
        public DateTime? ncCreateDate { get; set; }
        public int? ncStage { get; set; }
        public DateTime? nccreatedatebyoa { get; set; }
        //public bool? isnc_status { get; set; }

        public List<UploadDocsClss> uploadItems
        {
            get
            {
                List<UploadDocsClss> itemList = new List<UploadDocsClss>();
                if (this.uploadUrl == "" || this.uploadUrl == null)
                    return itemList;
                else
                {
                    var str_array = this.uploadUrl.Split("||");
                    if (str_array.Length > 0)
                    {
                        if (str_array.Length > 1)
                        {
                            for (var i = 0; i < str_array.Length; i++)
                            {
                                if (str_array[i].Length > 0)
                                {
                                    UploadDocsClss obj = new UploadDocsClss();
                                    obj.fn = str_array[i].Split('|')[0];
                                    obj.orgfn = str_array[i].Split('|')[1];
                                    itemList.Add(obj);
                                }

                            }
                        }

                    }
                    return itemList;
                }
            }
        }
    }

    public class UploadDocsClss
    {
        public string orgfn { get; set; }
        public string fn { get; set; }

    }

    public class OANcCompletOrRejectSugCls
    {
        public long id { get; set; }
        public string remarks { get; set; }

        public Boolean isOAComplete { get; set; }// true if da accept the form else false 

    }


    public class OANcHospitalOrCenterDetailsSearchResponse
    {
        public long total { get; set; }
        public int rowCount { get; set; }
        public int current { get; set; }
        public List<OANcHospitalOrCenterDetailsDTO> rows { get; set; }
    }

}
