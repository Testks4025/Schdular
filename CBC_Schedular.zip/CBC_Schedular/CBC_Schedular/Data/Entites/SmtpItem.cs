﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CBC_Schedular.Data.Entites
{
    
    public class SmtpItem
    {

        public string Host { get; set; }
        public int Port { get; set; }
        public string UserName { get; set; }
        public string Password { get; set; }
        public string FromEmail { get; set; }
        public string EmailFromDisplayName { get; set; }
        public bool UseDefaultCredentials { get; set; }
        public bool RequiresSSL { get; set; }
        public string Subject { get; set; }
        public bool IsLabUserCreationEnable { get; set; }
        public bool IsAssessorUserCreationEnable { get; set; }
        public bool IsAllocationEnable { get; set; }
        public string LoginLink { get; set; }
        public string applink { get; set; }
        public string CC { get; set; }
        public string CC_Registration { get; set; }
        
        public string CC_Agency { get; set; }
        public string BCC { get; set; }
    }

    public class SendGridItem
    {

        public string Host { get; set; }
        public string SENDGRID_API_KEY { get; set; }
        public int Port { get; set; }
        public string UserName { get; set; }
        public string Password { get; set; }
        public string FromEmail { get; set; }
        public string EmailFromDisplayName { get; set; }
        public bool UseDefaultCredentials { get; set; }
        public bool RequiresSSL { get; set; }
        public string Subject { get; set; }
        public bool IsLabUserCreationEnable { get; set; }
        public bool IsAssessorUserCreationEnable { get; set; }
        public bool IsAllocationEnable { get; set; }
        public string LoginLink { get; set; }
        public string CC { get; set; }
    }

    public class emailFormatVariableItem
    {
        public string toEmail { get; set; }
        public string toEmail2 { get; set; }
        public string orgname { get; set; }
        public string orgid { get; set; }
        public string appno { get; set; }
        public string address { get; set; }
        public String? asmtdate { get; set; }
        public String? asmtdate_to { get; set; }
        public string asrname { get; set; }
        public string? password { get; set; }
        public string? username { get; set; }

        public string asrname2 { get; set; }
        public string mobile1 { get; set; }
        public string mobile2 { get; set; }

        public string capacity1 { get; set; }
        public string capacity2 { get; set; }
        public string da_name { get; set; }
        public string da_mobile { get; set; }
        public string nodal_name { get; set; }
        public String oa_completion_date { get; set; }
        public DateTime last_login_date { get; set; }
    }

}
