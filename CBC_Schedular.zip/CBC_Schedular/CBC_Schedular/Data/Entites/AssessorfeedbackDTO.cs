﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CBC_Schedular.Data.Entites
{

    public class AssessorfeedbackDTO
    {
        public AssessorfeedbackDTO()
        {
            this.p_asrfeedback = new Assessorfeedback();
            this.s_asrfeedback = new SecondAssessorfeedback();
           
        }
        public Assessorfeedback p_asrfeedback { get; set; }
        public SecondAssessorfeedback s_asrfeedback { get; set; }
        public long hospital_id { get; set; }
        public long? pasr_id { get; set; }
        public long? sasr_id { get; set; }
        public string pasr_name { get; set; }
        public string sasr_name { get; set; }
        public long asmtid { get; set; }
        public string orgname { get; set; }

        public DateTime? asmtdate { get; set; }
        public DateTime? to_asmtdate { get; set; }

    }
    public class Assessorfeedback
    {
        public Assessorfeedback()
        {
            this.knowledge_of_hco_pract = new Knowledge();
            this.assessment_skills = new Assessment_skills();
            this.adapability = new Abality();
            this.timemanagement = new TimeManagement();
            this.commmunication_information = new Communication();
            this.teamplayer = new TeamPlayer();
            this.playing_organisation = new PlayngOrg();
            this.any_other_singni = new Others();
        }
        public Knowledge knowledge_of_hco_pract { get; set; }
        public Assessment_skills assessment_skills { get; set; }
        public Abality adapability { get; set; }
        public TimeManagement timemanagement { get; set; }
        public Communication commmunication_information { get; set; }
        public TeamPlayer teamplayer { get; set; }
        public PlayngOrg playing_organisation { get; set; }
        public Others any_other_singni { get; set; }

    }

    public class SecondAssessorfeedback
    {
        public SecondAssessorfeedback()
        {
            this.knowledge_of_hco_pract = new Knowledge();
            this.assessment_skills = new Assessment_skills();
            this.adapability = new Abality();
            this.timemanagement = new TimeManagement();
            this.commmunication_information = new Communication();
            this.teamplayer = new TeamPlayer();
            this.playing_organisation = new PlayngOrg();
            this.any_other_singni = new Others();
        }
        public Knowledge knowledge_of_hco_pract { get; set; }
        public Assessment_skills assessment_skills { get; set; }
        public Abality adapability { get; set; }
        public TimeManagement timemanagement { get; set; }
        public Communication commmunication_information { get; set; }
        public TeamPlayer teamplayer { get; set; }
        public PlayngOrg playing_organisation { get; set; }
        public Others any_other_singni { get; set; }
    }
     
    public class Knowledge
    {
        public Knowledge()
        {
            this.depth_knowldg_stndrs_objectv_elemnts = new QuestionPropertyy();
            this.competnt_requrd_assesmnt = new QuestionPropertyy();
            this.exhbts_ablity_lern_skills = new QuestionPropertyy();
            this.keeps_abreast_cuurnt = new QuestionPropertyy();
        }
        public QuestionPropertyy depth_knowldg_stndrs_objectv_elemnts { get; set; }
        public QuestionPropertyy competnt_requrd_assesmnt { get; set; }
        public QuestionPropertyy exhbts_ablity_lern_skills { get; set; }
        public QuestionPropertyy keeps_abreast_cuurnt { get; set; }

    }

    public class Assessment_skills
    {
        public Assessment_skills()
        {
            this.intrprt_appropite_objectve = new QuestionPropertyy();
            this.flexible_accpt_stndrd_resources = new QuestionPropertyy();
            this.gathr_analysis_sklfuly_concieved = new QuestionPropertyy();
            this.adhere_ethical_prncpl = new QuestionPropertyy();
        }
        public QuestionPropertyy intrprt_appropite_objectve { get; set; }
        public QuestionPropertyy flexible_accpt_stndrd_resources { get; set; }
        public QuestionPropertyy gathr_analysis_sklfuly_concieved { get; set; }
        public QuestionPropertyy adhere_ethical_prncpl { get; set; }
    }

    public class Abality
    {
        public Abality()
        {
            this.adpts_chnge_assesmnt = new QuestionPropertyy();
            this.mange_conficitng_demands_frame = new QuestionPropertyy();
            this.accepts_instructn_consitve = new QuestionPropertyy();
            this.chnge_approch_methd_stuatn = new QuestionPropertyy();
        }
        public QuestionPropertyy adpts_chnge_assesmnt { get; set; }
        public QuestionPropertyy mange_conficitng_demands_frame { get; set; }
        public QuestionPropertyy accepts_instructn_consitve { get; set; }
        public QuestionPropertyy chnge_approch_methd_stuatn { get; set; }
    }

    public class TimeManagement
    {
        public TimeManagement()
        {

            this.arrvs_meetng_scussn = new QuestionPropertyy();
            this.begns_worng_effectively = new QuestionPropertyy();
            this.change_aprch_best_situtn = new QuestionPropertyy();
            this.reviws_documnts_prepars_obsvatn = new QuestionPropertyy();
            this.comminats_delay = new QuestionPropertyy();
        }
        public QuestionPropertyy arrvs_meetng_scussn { get; set; }
        public QuestionPropertyy begns_worng_effectively { get; set; }
        public QuestionPropertyy change_aprch_best_situtn { get; set; }
        public QuestionPropertyy reviws_documnts_prepars_obsvatn { get; set; }
        public QuestionPropertyy comminats_delay { get; set; }
    }

    public class Communication
    {
        public Communication()
        {
            this.express_findng_verblly = new QuestionPropertyy();
            this.expres_findng_observtn = new QuestionPropertyy();
            this.exhbts_listng_comprehensn = new QuestionPropertyy();
            this.prficnt_computer_skills = new QuestionPropertyy();
            this.ncs_clesrly_documents = new QuestionPropertyy();
        }
        public QuestionPropertyy express_findng_verblly { get; set; }
        public QuestionPropertyy expres_findng_observtn { get; set; }
        public QuestionPropertyy exhbts_listng_comprehensn { get; set; }
        public QuestionPropertyy prficnt_computer_skills { get; set; }
        public QuestionPropertyy ncs_clesrly_documents { get; set; }
    }

    public class TeamPlayer
    {
        public TeamPlayer()
        {
            this.works_cooper_group = new QuestionPropertyy();
            this.exhibts_diplomacy_considertn = new QuestionPropertyy();
            this.display_positve_outlk_mannr = new QuestionPropertyy();
            this.offers_assistance_develop_assesor = new QuestionPropertyy();
            this.works_activly_prevent_resolve = new QuestionPropertyy();
        }
        public QuestionPropertyy works_cooper_group { get; set; }
        public QuestionPropertyy exhibts_diplomacy_considertn { get; set; }
        public QuestionPropertyy display_positve_outlk_mannr { get; set; }
        public QuestionPropertyy offers_assistance_develop_assesor { get; set; }
        public QuestionPropertyy works_activly_prevent_resolve { get; set; }
    }

    public class PlayngOrg
    {
        public PlayngOrg()
        {
            this.priortze_plans_activets = new QuestionPropertyy();
            this.plans_additnl = new QuestionPropertyy();
            this.works_orgnl_mannr = new QuestionPropertyy();
        }
        public QuestionPropertyy priortze_plans_activets { get; set; }
        public QuestionPropertyy plans_additnl { get; set; }
        public QuestionPropertyy works_orgnl_mannr { get; set; }
    }

    public class Others
    {
      
        public string other_text_ { get; set; }
    }
 

    public class QuestionPropertyy
    {
        public string ques_rating { get; set; }
        //public string ques_rating_poor { get; set; }
        //public string ques_rating_fair { get; set; }
        //public string ques_rating_good { get; set; }
        //public string ques_rating_verygood { get; set; }
        //public string ques_rating_excellent { get; set; }
        public string ques_comment { get; set; }
        //public string any_other_singni { get; set; }
    }


}
