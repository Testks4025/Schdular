﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CBC_Schedular.Data.Entites.InstituteSections
{
    public class InstituteSetionsDataDTO
    {
        public InstituteSetionsDataDTO()
        {
            this.application_form = new ApplicationFormDTO();
        }
        public long id { get; set; }
        public long institute_id { get; set; }

        public String application_no { get; set; }
        public int saveType { get; set; }
        public long stage_id { get; set; }
        public bool isFinalSubmit { get; set; }
        public bool is_part_a_submitted { get; set; }

        public String institute_name { get; set; }
        public String affiliation { get; set; }

        public int? city_id { get; set; }
        public String state_code { get; set; }
        public String address { get; set; }
        // public String org_name { get; set; }
        //public DateTime asmt_date { get; set; }
        public String asr_name { get; set; }
        public bool status { get; set; }
        public bool isDaAccepted { get; set; }
        public String daRemark { get; set; }
        public bool isDaCompleted { get; set; }

        public String institute_type { get; set; }
        public bool is_cbc_institute { get; set; }
        public long? department_id { get; set; }
        public long? ministry_id { get; set; }
        public String state_central { get; set; }

        public String final_da_remark { get; set; }

        public ApplicationFormDTO application_form { get; set; }
        public String final_oa_remark { get; set; }


    }

}
