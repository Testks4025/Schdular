﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CBC_Schedular.Data.Entites.InstituteSections
{
    public class ApplicationFormDTO
    {
        public ApplicationFormDTO()
        {
            trng_progm_by_inst = new List<String>();
            total_recpt_govt_fv_year = new List<last_fv_year>();

            total_recpt_non_govt_fv_year = new List<last_fv_year>();

            total_expndtr_fv_year = new List<last_fv_year>();

            mous_sgnd_fv_year = new List<last_fv_year>();


            annul_rprt_pblsh_fv_year = new List<last_fv_year>();


            trainee_atndng_indcn_trng_fv_year = new List<last_fv_year>();

            in_srvc_trng_fv_year = new List<last_fv_year>();

            trnee_atndn_in_srvc_trng_fv_year = new List<last_fv_year>();

            mid_crrer_trng_fv_year = new List<last_fv_year>();

            trnee_atndn_mid_crrer_trng_fv_year = new List<last_fv_year>();


            trainee_traned_fv_year = new List<last_fv_year>();
            trainee_atndng_shortterm_trng_fv_year = new List<last_fv_year>();
            ministry_dept_org_fv_year = new List<last_fv_year>();
            institute_consult = new Institute_consult();

            faculty_fdp_prog_fv_year= new List<last_fv_year>();
            total_expndtr_non_training_fv_year= new List<last_fv_year>();
            training_mn_defined_fr_training = new TrainingManDay();
            training_mn_achieved_fr_training = new TrainingManDay();
            short_trm_training_course_by_inst = new List<short_trm_training_last_fv_year>();

        }

       

        public String zonal_admin_institute_no { get; set; }

        public String institute_mission { get; set; }
        public String institute_vision { get; set; }
        public String primary_trainee_prof { get; set; }
        public String secondary_trainee_prof { get; set; }

        public String fulltime_faculty_no { get; set; }
        public String guest_faculty_no { get; set; }
        public String admin_staff_no { get; set; }
        public String research_staff_no { get; set; }
        public String total_annual_tn { get; set; }
        public List<last_fv_year> trainee_traned_fv_year { get; set; }

        public List<String> trng_progm_by_inst { get; set; }

        public String _0_to_3_shrt_trm_trng_course_by_inst { get; set; }
        public String _3_to_5_shrt_trm_trng_course_by_inst { get; set; }
        public String _5_to_7_shrt_trm_trng_course_by_inst { get; set; }

        public List<last_fv_year> trainee_atndng_indcn_trng_fv_year { get; set; }

        public List<last_fv_year> in_srvc_trng_fv_year { get; set; }

        public List<last_fv_year> trnee_atndn_in_srvc_trng_fv_year { get; set; }

        public List<last_fv_year> mid_crrer_trng_fv_year { get; set; }

        public List<last_fv_year> trnee_atndn_mid_crrer_trng_fv_year { get; set; }

        public String ministry_dept_org { get; set; }

        public String area_trng_inst { get; set; }
        public String lecture_hall_no { get; set; }
        public String sitinf_capacity_lecture_hall { get; set; }

        public String confrnc_hall_no { get; set; }
        public String sitinf_capacity_confrnc_hall { get; set; }

        public String trnee_room_female { get; set; }
        public String avg_trnee_cost_residence { get; set; }
        public String avg_trnee_cost_non_residence { get; set; }

        public List<last_fv_year> annul_rprt_pblsh_fv_year { get; set; }
        public String total_annual_publictn { get; set; }

        public String digital_prgm_no { get; set; }
        public String no_blended_trng { get; set; }

        public String total_vdeo_avl { get; set; }
        public String total_ppt_dgtl_course_mat_avl { get; set; }
        public String spons_rsrch_prjct_no { get; set; }

        public List<last_fv_year> total_recpt_govt_fv_year { get; set; }

        public List<last_fv_year> total_recpt_non_govt_fv_year { get; set; }

        public List<last_fv_year> total_expndtr_fv_year { get; set; }

        public List<last_fv_year> mous_sgnd_fv_year { get; set; }
       



        public String material_avl { get; set; }
        //newly added
        public String type_of_institute { get; set; }
        public String train_civil_servent { get; set; }
        public String institute_change_the_pedagogy { get; set; }
        public String institute_curate_spcl_module { get; set; }
        public String practical_training { get; set; }
        public String learning_management { get; set; }
        public String elearning_video_avl { get; set; }
        public String course_uploaded_igot { get; set; }

        public String collect_feedbk_trainee { get; set; }
        public String format_feedback_trainee { get; set; }
        public String format_feedback_trainee_other_text { get; set; }
        public String periodic_feedbk_superviser { get; set; }
        public String domain_sanctn_faculty { get; set; }
        public String functional_sanctn_faculty { get; set; }

        public String bahavoral_sanctn_faculty { get; set; }
        public String subject_matter_expert { get; set; }
        public String private_sector { get; set; }
        public String ex_govt_officer { get; set; }
        public String academician { get; set; }
        public String formal_faculty_dev { get; set; }
        public String formal_faculty_dev_created_updt { get; set; }
        public String mentorship_program { get; set; }
        public String mentor_mentee_ratio { get; set; }
        public String tot_certificate { get; set; }
        public String instruction_methodologies { get; set; }
        public String rsrch_publication_no { get; set; }
        public String amount_of_sponsership { get; set; }

        public String source_of_sponsership { get; set; }
        public String sme { get; set; }
        public String guest_facility { get; set; }
        public String visual_designer { get; set; }

        public String consultants { get; set; }
        public String instructer { get; set; }
        public String outsource_human_others { get; set; }
        public String grievance_redressal_mechanism { get; set; }
        public String turn_around_time_grievance { get; set; }
        public String sanctn_admin_post { get; set; }
        public String occupied_admin_post { get; set; }

        public String facilities_lecture_hall { get; set; }
        public String facilities_board_room { get; set; }
        public String facilities_amphithrater { get; set; }
        public String facilities_seminarhall { get; set; }
        public String facilities_others { get; set; }

        public String avg_seating_fac { get; set; }
        public String accomodation_facility_trainer { get; set; }
        public String room_cpcty_accomod_trainer { get; set; }
        public String no_accomodation_fac { get; set; }
        public String no_sport_facility { get; set; }
        public String no_book_library { get; set; }
        public String no_magzine_subscribe { get; set; }
        public String no_digital_lib_subscribe { get; set; }
        public String inst_engg_alumuni { get; set; }

        public String inter_cti_netwrork { get; set; }
        public String intra_cti_netwrork { get; set; }
        public String no_networking_event { get; set; }
        public List<last_fv_year> trainee_atndng_shortterm_trng_fv_year { get; set; }
        public List<last_fv_year> ministry_dept_org_fv_year { get; set; }

        public Institute_consult institute_consult { get; set; }
       
         public List<last_fv_year> faculty_fdp_prog_fv_year { get; set; }
        public List<last_fv_year> total_expndtr_non_training_fv_year { get; set; }
        

     public TrainingManDay training_mn_defined_fr_training { get; set; }
        public TrainingManDay training_mn_achieved_fr_training { get; set; }
      

        public String annual_report_doc_url { get; set; }

        public List<short_trm_training_last_fv_year> short_trm_training_course_by_inst { get; set; }

        public String establishment_year { get; set; }
        public String institute_history { get; set; }

    
        public String current_head_of_institute { get; set; }
        public String email_head_of_institute { get; set; }

    }

    public class short_trm_training_last_fv_year
    {

        public String year { get; set; }
        public String _0_to_3_shrt_trm_trng_course_by_inst { get; set; }
        public String _3_to_5_shrt_trm_trng_course_by_inst { get; set; }
        public String _5_to_7_shrt_trm_trng_course_by_inst { get; set; }
      
    }
    public class TrainingManDay
    {
        public bool group_a_selected { get; set; }
        public String group_a_no { get; set; }

        public bool group_b_selected { get; set; }
        public String group_b_no { get; set; }
        public bool group_c_selected { get; set; }
        public String group_c_no { get; set; }

    }
    public class Institute_consult
    {
        public bool cadre_ctrl_auth { get; set; }
        public bool trainee_immdt_suprvsr { get; set; }
        public bool acedemic_wt_xpertise { get; set; }
        public bool retired_govt_offcr { get; set; }
        public bool consult_othrers { get; set; }

     
    }
    public class last_fv_year
    {
        public String year { get; set; }
        public String value { get; set; }
    }
}
