﻿
using CBC_Schedular.Data.Entites.HospitalSections;
using System;
using System.Collections.Generic;
using System.Text;

namespace CBC_Schedular.Data.Entites
{
    // Root myDeserializedClass = JsonConvert.DeserializeObject<Root>(myJsonResponse); 

    public class OnsiteAllocationDto_Header
    {
        public string label { get; set; }
        public string value { get; set; }
    }

    //public class OnsiteAllocationDto_HeaderValue
    //{
    //    public string value { get; set; }
    //}

    public class OnsiteAllocationDto_Row
    {
        public OnsiteAllocationDto_Row()
        {
            this.showitem = new List<OnsiteAllocationDto_Header>();
            //this.header_value = new List<string>();
          
        }
        public long? pkid { get; set; }
        public long? assessment_id { get; set; }
        public DateTime? assessment_date { get; set; }
        public string assessment_date_str { get; set; }
        public long? oa_userid { get; set; }
        public string oa_username { get; set; }
        public long? stage_id { get; set; }
        public string stage { get; set; }
        public long form_id { get; set; }
        public string assessorType { get; set; }
        public string ismultipleAsr { get; set; }
        public List<OnsiteAllocationDto_Header> showitem { get; set; }
      
        //public List<string> header_value { get; set; }
    }

    public class OnsiteAllocationDto_Obj
    {
        public OnsiteAllocationDto_Obj()
        {
            this.row = new List<OnsiteAllocationDto_Row>();
        }
        public bool isSuccess { get; set; }
        public string message { get; set; }
        public List<OnsiteAllocationDto_Row> row { get; set; }
    }

    public class OnsiteAllocationDto_app
    {
        public OnsiteAllocationDto_Obj obj { get; set; }
    }



}
