﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CBC_Schedular.Data.Entites
{

    public class HospitalDashboardDto
    {
        public HospitalDashboardDto()
        {
            this.stage_history = new List<HospitalStage>();
        }

        public long id { get; set; }
        public String hospital_name { get; set; }
        public String hosp_id { get; set; }
        public String application_number { get; set; }
        public String reference_number { get; set; }
        public String state { get; set; }
        public long? stage_id { get; set; }
        public String organisation_type { get; set; }
        public String onsite_date { get; set; }
        public List<HospitalStage> stage_history { get; set; }


        public String application_type { get; set; }

        public string assessor_name { get; set; }

        public string assessor2{ get; set; }
        public string mob { get; set; }

        public string mob2 { get; set; }
        public bool is_da_payment_receipt_submitted { get; set; }
        public bool is_oa_payment_receipt_submitted { get; set; }
    }
    public class  HospitalStage
    {

        public long id { get; set; }
        public String stage { get; set; }
        public long? stage_id { get; set; }
        public DateTime? creation_date { get; set; }
     
    }
}
