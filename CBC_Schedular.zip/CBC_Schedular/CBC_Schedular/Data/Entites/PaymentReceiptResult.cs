﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CBC_Schedular.Data.Entites
{
   public class PaymentReceiptResult
    {
        public String HospitalId { get; set; }
        public String financial_year { get; set; }
        public String HospitalName { get; set; }
        public String State { get; set; }
        public String City { get; set; }

        public decimal? PaidAmount { get; set; }
        public String PaidAmountInWords { get; set; }

        public String Pan { get; set; }
        public String Gst { get; set; }

        public String PaymentDate { get; set; }

        public String TransactionDetails { get; set; }

        

        
    }
}
