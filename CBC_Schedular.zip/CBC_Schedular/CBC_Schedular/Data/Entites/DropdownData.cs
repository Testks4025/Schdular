﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CBC_Schedular.Data.Entites
{
   public class DropdownDataModel
    {
        public long value { get; set; }
        public String text { get; set; }
    }

    public class ApplicationTrackerDropdownData
    {

        public List<DropdownDataModel> statedropdown { get; set; }
        public List<DropdownDataModel> stagedropdown { get; set; }
        public List<DropdownDataModel> agencydropdown { get; set; }
        public List<DropdownDataModel> assessordropdown { get; set; }
        public List<DropdownDataModel> citydropdown { get; set; }
        public List<DropdownDataModel> principalassessordropdown { get; set; } // rrc
        public List<DropdownDataModel> nonprincipalassessordropdown { get; set; } // rrc
        public List<DropdownDataModel> cometememberdropdown { get; set; } // rrc
        public List<DropdownDataModel> ccstagesdropdown { get; set; } // rrc
        public List<DropdownDataModel> oastagesdropdown { get; set; } // rrc
        public List<String> institutedropdown { get; set; } 
        public List<String> applicationnodropdown { get; set; } 

    }

    public class AllocationDaDropdownData
    {

      
        public List<String> institutedropdown { get; set; }
        public List<String> applicationnodropdown { get; set; }
        public List<StateDTO> statedropdown { get; set; }

       

    }

}
