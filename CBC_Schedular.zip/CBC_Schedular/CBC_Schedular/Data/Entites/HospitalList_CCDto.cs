﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CBC_Schedular.Data.Entites
{
    public class HospitalList_CCDto
    {
        public long hosp_id { get; set; }
        public String reference_id { get; set; }
        public String org_name { get; set; }
        public long state_id { get; set; }
        public String state { get; set; }
        public String type { get; set; }

        public String application_no { get; set; }
        public String stage { get; set; }
        public long? stage_id { get; set; }
        public DateTime? committeedate { get; set; }
        public long? cometemember_id { get; set; }

    }

   

    public class CC_HospAllocationList
    {
        public int current { get; set; }
        public long total { get; set; }
        public int rowcount { get; set; }
        public List<HospitalList_CCDto> rows { get; set; }
    }

}
