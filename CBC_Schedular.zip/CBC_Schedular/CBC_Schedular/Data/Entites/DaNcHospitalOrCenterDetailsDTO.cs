﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace CBC_Schedular.Data.Entites
{
    public class DaNcHospitalOrCenterDetailsDTO
    {
        public long id { get; set; }
        public long hospital_id { get; set; }
        public long ques_id { get; set; }
        public string classObject { get; set; }
        public string propertyName { get; set; }
        public bool? isNc { get; set; }
        public string remarks { get; set; }
        public string reply { get; set; }
        public string uploadUrl { get; set; }
        public bool? isOpen { get; set; }
        public string finalRemark { get; set; }
        public DateTime? ncCreateDate { get; set; }
        public int? ncStage { get; set; }
        public DateTime? nccreatedatebyda { get; set; }
        public bool? isnc_status { get; set; }

        public List<UploadDocsCls> uploadItems
        {
            get
            {
                List<UploadDocsCls> itemList = new List<UploadDocsCls>();
                if (this.uploadUrl == "" || this.uploadUrl == null)
                    return itemList;
                else
                {
                    var str_array = this.uploadUrl.Split("||");
                    if (str_array.Length > 0)
                    {
                        if (str_array.Length > 1)
                        {
                            for (var i = 0; i < str_array.Length; i++)
                            {
                                if (str_array[i].Length > 0)
                                {
                                    UploadDocsCls obj = new UploadDocsCls();
                                    obj.fn = str_array[i].Split('|')[0];
                                    obj.orgfn = str_array[i].Split('|')[1];
                                    itemList.Add(obj);
                                }

                            }
                        }

                    }
                    return itemList;
                }
            }
        }
    }

    public class UploadDocsCls
    {
        public string orgfn { get; set; }
        public string fn { get; set; }

    }

    public class DaNcCompletOrRejectSugCls
    {
        public long id { get; set; }
        public string remarks { get; set; }

        public Boolean isDaComplete { get; set; }// true if da accept the form else false 

        public bool? declare { get; set; }

        public bool? declare_asr { get; set; }

    }


    public class DaNcHospitalOrCenterDetailsSearchResponse
    {
        public long total { get; set; }
        public int rowCount { get; set; }
        public int current { get; set; }
        public List<DaNcHospitalOrCenterDetailsDTO> rows { get; set; }
    }

}
