﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CBC_Schedular.Data.Entites
{
   
    public class HospitalList_DaAllocationDto
    {

        public long hosp_id { get; set; }
        public String reference_id { get; set; }
        public String org_name { get; set; }
        public String state_id { get; set; }
        public String state { get; set; }
        public String application_type { get; set; }
        public String type { get; set; }

        public String application_no { get; set; }
        public DateTime registration_date { get; set; }
        public DateTime? updated_date { get; set; }

        public DateTime? assessment_date { get; set; }
        public DateTime? to_assessment_date { get; set; }
        
        public String stage { get; set; }
        public long stage_id { get; set; }
        public Boolean status { get; set; }
        public long hospital_apply_for { get; set; }

        public List<HospitalStage> stage_history { get; set; }

          public String current_da { get; set; }
         public long current_da_id { get; set; }

        public String assmt_type { get; set; }

        public long assessorid { get; set; }

        public string senction_bed { get; set; }

        public string district { get; set; }

        public long assr_usrid { get; set; }



        public bool? isactive { get; set; }
        public String agency { get; set; }


    }

    public class DA_AllocationList
    {
        public int current { get; set; }
        public long total { get; set; }
        public int rowcount { get; set; }
        public List<HospitalList_DaAllocationDto> rows { get; set; }


    }

}
