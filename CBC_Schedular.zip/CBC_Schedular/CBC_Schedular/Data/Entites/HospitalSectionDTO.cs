﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CBC_Schedular.Data.Entites
{
   public class HospitalSectionDTO
    {
        
        public long id { get; set; }
        public long section_id { get; set; }
        public string section_name { get; set; }
    }
}
