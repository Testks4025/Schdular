﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CBC_Schedular.Data.Entites
{
   public class AssessorDashboardDto
    {

        public int da_alloc_count { get; set; }
        public int da_nc_reply_count { get; set; }
        public int da_nc_review_count { get; set; }

        public int oa_alloc_count { get; set; }
        public int oa_nc_reply_count { get; set; }
        public int oa_nc_review_count { get; set; }
    }
}
