﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CBC_Schedular.Data.Entites.CentralHospitalSection
{
    public class cen_Infection_Control
    {

        public cen_Infection_Control()
            {
            this.does_international_guidelines_for_hand_hygiene=new cen_QuestionProperty();
            this.cleaning_disinfection_and_sterilization = new cen_QuestionProperty();
            this.disinfectant_for_cleaning_sterilization_purpose = new cen_QuestionProperty();
            this.maintain_Infection_control_and_prevention_programmes = new cen_QuestionProperty();
            this.staff_ensure_weekly_rigorous_cleaning_scrubbing = new cen_QuestionProperty();
            this.practicesof_staff_respect_biomedical_waste_handling = new cen_QuestionProperty();
            this.biomedical_waste_sufficient_personal_protective = new cen_QuestionProperty();
        }

        public cen_QuestionProperty does_international_guidelines_for_hand_hygiene { get; set; }
        public cen_QuestionProperty cleaning_disinfection_and_sterilization { get; set; }
        public cen_QuestionProperty disinfectant_for_cleaning_sterilization_purpose { get; set; }
        public cen_QuestionProperty maintain_Infection_control_and_prevention_programmes { get; set; }
        public cen_QuestionProperty staff_ensure_weekly_rigorous_cleaning_scrubbing { get; set; }
        public cen_QuestionProperty practicesof_staff_respect_biomedical_waste_handling { get; set; }
        public cen_QuestionProperty biomedical_waste_sufficient_personal_protective { get; set; }

    }
}
