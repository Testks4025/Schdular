﻿using CBC_Schedular.Data.Entites.HospitalSections;
using System;
using System.Collections.Generic;
using System.Text;

namespace CBC_Schedular.Data.Entites.CentralHospitalSection
{
    public class CentralSupportServiceDTO
    {
        public CentralSupportServiceDTO()
        {
            list_of_non_clinical_and_administrative_departments = new SupportServiceList();
            list_of_paramedical_allied_services = new ParamedicalServiceList();
            centre_has_laboratory_services = new QuestionPropertyCentralSupportServc();
            out_sourced_laboratory_test_service = new CentralMouOutsourcedQuestionProperty();
            laboratory_services = new SupportLabServiceList();

            testing_and_calibration_laboratories = new cen_QuestionProperty();
            centre_provide_laboratory_services_that_commensurate = new cen_QuestionProperty();
            safe_transportation_processing_and_disposal = new cen_QuestionProperty();
            interpret_the_investigations_and_supervise_them = new cen_QuestionProperty();
            lab_technician = new StaffDetailsQuestionProperty();
            centre_prescribes_turn_around_time = new cen_QuestionProperty();
            centre_defined_critical_limits_for_different_tests = new cen_QuestionProperty();
            procedure_to_intimate_the_concerned_personnels = new cen_QuestionProperty();
            centre_maintain_the_quality_control_laboratory = new cen_QuestionProperty();

            centre_has_imaging_services = new QuestionPropertyCentralSupportServc();
            mou_for_out_sourced_imaging_test_service = new CentralMouOutsourcedQuestionProperty();


            centre_provide_imaging_services_commensurate = new cen_QuestionProperty();
            policy_sop_for_handling_and_disposing = new cen_QuestionProperty();
            imaging_service_competent_specifically_qualified = new cen_QuestionProperty();
            image_technician = new StaffDetailsQuestionProperty();
            centre_prescribe_the_turn_around_time = new cen_QuestionProperty();
            centre_defined_the_critical_test_results = new cen_QuestionProperty();
            concerned_personnel_regarding_critical_results = new cen_QuestionProperty();
            concerned_staffs_properly_trained_in_imaging = new cen_QuestionProperty();
            centre_provide_safety_equipments_to_concerned = new cen_QuestionProperty();
            centre_ensures_quality_control_and_radiation_safety = new cen_QuestionProperty();
            centre_provide_transport_services_ambulance = new QuestionPropertyCentralSupportServc();
            centre_have_standardized_protocol_to_identify = new cen_QuestionProperty();
            centre_have_defined_policies_and_procedure = new cen_QuestionProperty();
            number_of_ambulance = new cen_QuestionProperty();
            daily_check_list_of_ambulance = new cen_QuestionProperty();
            upload_document_ambulnce = new cen_QuestionProperty();
            mou_for_outsourced_ambulance_service = new CentralMouOutsourcedQuestionProperty();
            centre_have_linen_management_system_insource = new QuestionPropertyCentralSupportServc();
            centre_ensure_availability_of_different_categories = new cen_QuestionProperty();

            this.inhouse_imaging_services_licensed_aerb =new cen_QuestionProperty();
            this.imaging_service_list = new List<DiagnosticService>();

    }
        public SupportServiceList list_of_non_clinical_and_administrative_departments { get; set; }
        public ParamedicalServiceList list_of_paramedical_allied_services { get; set; }
        public QuestionPropertyCentralSupportServc centre_has_laboratory_services { get; set; }
        public CentralMouOutsourcedQuestionProperty out_sourced_laboratory_test_service { get; set; }
        public SupportLabServiceList laboratory_services { get; set; }

        public cen_QuestionProperty testing_and_calibration_laboratories { get; set; }
        public cen_QuestionProperty centre_provide_laboratory_services_that_commensurate { get; set; }
        public cen_QuestionProperty safe_transportation_processing_and_disposal { get; set; }
        public cen_QuestionProperty interpret_the_investigations_and_supervise_them { get; set; }
        public StaffDetailsQuestionProperty lab_technician { get; set; }
        public cen_QuestionProperty centre_prescribes_turn_around_time { get; set; }
        public cen_QuestionProperty centre_defined_critical_limits_for_different_tests { get; set; }
        public cen_QuestionProperty procedure_to_intimate_the_concerned_personnels { get; set; }
        public cen_QuestionProperty centre_maintain_the_quality_control_laboratory { get; set; }

        public QuestionPropertyCentralSupportServc centre_has_imaging_services { get; set; }
        public CentralMouOutsourcedQuestionProperty mou_for_out_sourced_imaging_test_service { get; set; }
          public cen_QuestionProperty inhouse_imaging_services_licensed_aerb { get; set; }
        public List<DiagnosticService> imaging_service_list { get; set; }
        public cen_QuestionProperty centre_provide_imaging_services_commensurate { get; set; }
        public cen_QuestionProperty policy_sop_for_handling_and_disposing { get; set; }
        public cen_QuestionProperty imaging_service_competent_specifically_qualified { get; set; }
        public StaffDetailsQuestionProperty image_technician { get; set; }
        public cen_QuestionProperty centre_prescribe_the_turn_around_time { get; set; }
        public cen_QuestionProperty centre_defined_the_critical_test_results { get; set; }
        public cen_QuestionProperty concerned_personnel_regarding_critical_results { get; set; }
        public cen_QuestionProperty concerned_staffs_properly_trained_in_imaging { get; set; }
        public cen_QuestionProperty centre_provide_safety_equipments_to_concerned { get; set; }
        public cen_QuestionProperty centre_ensures_quality_control_and_radiation_safety { get; set; }
        public QuestionPropertyCentralSupportServc centre_provide_transport_services_ambulance { get; set; }
        public cen_QuestionProperty centre_have_standardized_protocol_to_identify { get; set; }
        public cen_QuestionProperty centre_have_defined_policies_and_procedure { get; set; }
        public cen_QuestionProperty number_of_ambulance { get; set; }
        public cen_QuestionProperty daily_check_list_of_ambulance { get; set; }
        public cen_QuestionProperty upload_document_ambulnce { get; set; }
        public CentralMouOutsourcedQuestionProperty mou_for_outsourced_ambulance_service { get; set; }
        public QuestionPropertyCentralSupportServc centre_have_linen_management_system_insource { get; set; }
        public cen_QuestionProperty centre_ensure_availability_of_different_categories { get; set; }



    }

    public class CentralMouOutsourcedQuestionProperty : cen_QuestionProperty
    {


        public String agency_name { get; set; }
        public bool? available { get; set; }
        
        public DateStruct valid_from { get; set; }
        public DateStruct valid_till { get; set; }


    }
    public class SupportServiceList : cen_QuestionProperty
    {
        public SupportServiceList()
        {
            this.support_servc_list = new List<SupportService>();
        }
        public List<SupportService> support_servc_list { get; set; }

    }


    public class ParamedicalServiceList : cen_QuestionProperty
    {
        public ParamedicalServiceList()
        {
            this.oushadhashala = new List<SupportService>();
            this.pathyaahara_vibhaga = new List<SupportService>();
            this.rehabilitative_services = new List<SupportService>();
        }
        public List<SupportService> oushadhashala { get; set; }
        public List<SupportService> pathyaahara_vibhaga { get; set; }
        public List<SupportService> rehabilitative_services { get; set; }


    }

    public class SupportService
    {
        public string service { get; set; }
        public bool inhouse { get; set; }
        public bool outsource { get; set; }
        public bool not_applicable { get; set; }
    }
    public class SupportLabServiceList : cen_QuestionProperty
    {
        public SupportLabServiceList()
        {
            this._laboratorty_servc_list = new List<LabService_Licience>();
            this.transfusioin_servc_list = new List<LabService_Licience>();
        }
        public List<LabService_Licience> _laboratorty_servc_list { get; set; }
        public List<LabService_Licience> transfusioin_servc_list { get; set; }


    }

    public class SupportLabService
    {
        public string service { get; set; }
        public bool inhouse { get; set; }
        public bool outsource { get; set; }
        public bool serves_other_org { get; set; }
    }

    public class QuestionPropertyCentralSupportServc
    {
        public long ques_id { get; set; }
        public string ques_stndrd_code { get; set; }
        public string ques_text { get; set; }
        public string ques_help_text { get; set; }
        public string ques_selected_opt { get; set; }

        public string ques_text_value { get; set; }
        public string ques_doc_url { get; set; }
        public bool? old_ques_histry_opt { get; set; }
        public string old_ques_doc_url { get; set; }
    }

    public class DiagnosticService : SupportLabService
    {
        public DiagnosticService()
        {
            this.aerb_lic_details = new AerbLicienceDetails();
            this.mou_lic_detail = new CenMouDetailsOutsourced();
        }
        public AerbLicienceDetails aerb_lic_details { get; set; }
        public CenMouDetailsOutsourced mou_lic_detail { get; set; }
       

    }
    public class AerbLicienceDetails
        {


        public string agent_name { get; set; }
        public string status { get; set; }
        public string application_no { get; set; }
        public string lic_no { get; set; }
        public DateStruct valid_from { get; set; }
        public DateStruct valid_till { get; set; }
        public string license_url { get; set; }


    }
    public class  CenMouDetailsOutsourced
    {
        public string agent_name { get; set; }
        public string available { get; set; }
        public DateStruct valid_from { get; set; }
        public DateStruct valid_till { get; set; }
        public string license_url { get; set; }




    }
   public  class LabService_Licience
    {
        public LabService_Licience()
        {
            this.mou_lic_detail = new CenMouDetailsOutsourced();
        }
       public String service { get; set; }
        public bool inhouse { get; set; }
        public bool outsource { get; set; }
        public bool serves_other_org { get; set; }
        public CenMouDetailsOutsourced mou_lic_detail { get; set; }
}
}
