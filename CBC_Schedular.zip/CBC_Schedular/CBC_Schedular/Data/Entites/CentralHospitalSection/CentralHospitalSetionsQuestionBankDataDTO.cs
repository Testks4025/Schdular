﻿using CBC_Schedular.Data.Entites.CentralHospitalSection;
using System;
using System.Collections.Generic;
using System.Text;

namespace CBC_Schedular.Data.Entites.HospitalSections
{
    public class CentralHospitalSetionsQuestionBankDataDTO
    {
        public CentralHospitalSetionsQuestionBankDataDTO()
        {
            this.ceninfectioncontrol = new cen_Infection_Control();
            this.centraining = new cen_Training();
            this.cenadminrecord = new CenAdminRecord();
            this.cenqualitycare = new CentralQualityOfCareDTO();
            this.cenopdregispro = new OPDRegistrationProcessDTO();
            this.cenpatientrecord = new CentralPatientRecordDTO();
            this.cenhumanresource = new CentralHumanResourceDTO();
            this.censupportservice = new CentralSupportServiceDTO();
            this.generalinfo = new SectionCenterGeneralInfoQuesBankDTO();
            this.censtatutarylicense = new CentralStatutoryCompilanceDTO();
            this.scope_of_service = new SectionCenterScopeOfServiceQuestionBankDTO();
        }

        public cen_Infection_Control ceninfectioncontrol { get; set; }
        public cen_Training centraining { get; set; }
        public CenAdminRecord cenadminrecord { get; set; }
        public CentralQualityOfCareDTO cenqualitycare { get; set; }
        public OPDRegistrationProcessDTO cenopdregispro { get; set; }
        public CentralPatientRecordDTO cenpatientrecord { get; set; }
        public CentralHumanResourceDTO cenhumanresource { get; set; }
        public CentralSupportServiceDTO censupportservice { get; set; }
        public SectionCenterGeneralInfoQuesBankDTO generalinfo { get; set; }
        public CentralStatutoryCompilanceDTO censtatutarylicense { get; set; }

        public SectionCenterScopeOfServiceQuestionBankDTO scope_of_service { get; set; }

        




    }
}
