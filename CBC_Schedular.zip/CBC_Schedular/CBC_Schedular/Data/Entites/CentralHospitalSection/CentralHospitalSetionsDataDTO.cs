﻿using CBC_Schedular.Data.Entites.CentralHospitalSection;
using System;
using System.Collections.Generic;
using System.Text;

namespace CBC_Schedular.Data.Entites.HospitalSections
{
    public class CentralHospitalSetionsDataDTO
    {
        public CentralHospitalSetionsDataDTO()
        {
            this.generalInfo = new SectionCenterGeneralInfoDTO();
            this.ceninfectioncontrol = new cen_Infection_Control();
            this.centraining = new cen_Training();
            this.cenadminrecord = new CenAdminRecord();
            this.cenqualitycare = new CentralQualityOfCareDTO();
            this.cenopdregispro = new OPDRegistrationProcessDTO();
            this.cenpatientrecord = new CentralPatientRecordDTO();
            this.cenhumanresource = new CentralHumanResourceDTO();
            this.censupportservice = new CentralSupportServiceDTO();
            this.scope_of_service = new SectionCenterScopeOfServiceDTO();
           this.censtatutarylicense = new CentralStatutoryCompilanceDTO();

        }



        public long id { get; set; }
        public long hospital_id { get; set; }
        public String application_no { get; set; }
        public int saveType { get; set; } //1 for save as draft and 2 for final submit
        public long stage_id { get; set; }
        public bool isFinalSubmit { get; set; }
        public bool isDaAccepted { get; set; }
        public bool isDaCompleted { get; set; }
        
        public String daRemark { get; set; }

        public int? hosp_progress { get; set; } // rrc
        public String org_name { get; set; } // added for asr by vk
        public String ref_id { get; set; } // added for asr by vk

        public String state { get; set; } // added for asr by vk

        public DateTime? asmt_date { get; set; } // added for asr by vk

        public String type { get; set; } // added for asr by vk
        public String asr_name { get; set; } // added for asr by vk
        public bool status { get; set; }
        public String senction_bed { get; set; }
        public String sepeciality { get; set; }

        public SectionCenterGeneralInfoDTO generalInfo { get; set; }
        public cen_Infection_Control ceninfectioncontrol { get; set; }
        public cen_Training centraining { get; set; }
        public CenAdminRecord cenadminrecord { get; set; }
        public CentralQualityOfCareDTO cenqualitycare { get; set; }
        public OPDRegistrationProcessDTO cenopdregispro { get; set; }
        public CentralPatientRecordDTO cenpatientrecord { get; set; }

        public CentralHumanResourceDTO cenhumanresource { get; set; }
        public CentralSupportServiceDTO censupportservice { get; set; }
        public SectionCenterScopeOfServiceDTO scope_of_service { get; set; }
        public CentralStatutoryCompilanceDTO censtatutarylicense { get; set; }

        


    }
}
