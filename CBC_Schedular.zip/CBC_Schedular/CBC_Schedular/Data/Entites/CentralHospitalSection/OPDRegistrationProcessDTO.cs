﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CBC_Schedular.Data.Entites.CentralHospitalSection
{
   public class OPDRegistrationProcessDTO
    {
        public OPDRegistrationProcessDTO()
        {
            this.policy_for_patients_registration_and_admission = new cen_QuestionProperty();
            this.centre_have_policy_to_register_patients = new cen_QuestionProperty();
            this.centre_maintain_the_registration_register = new cen_QuestionProperty();
            this.centre_have_standardised_initial_assessment = new cen_QuestionProperty();
            this.centre_define_criteria_mechanism_identify_patients = new cen_QuestionProperty();
            this.policy_to_proceed_additional_specialized_assessments = new cen_QuestionProperty();
            this.policy_to_incorporate_outside_assessment = new cen_QuestionProperty();
            this.centres_scope_of_services_mission_resources = new cen_QuestionProperty();
            this.centre_have_referralout_system_for_additional_care = new cen_QuestionProperty();
            this.maintain_proper_coordination_between_medical_centres = new cen_QuestionPropertyopd();
        }
      public  cen_QuestionProperty policy_for_patients_registration_and_admission { get; set; }
        public cen_QuestionProperty centre_have_policy_to_register_patients { get; set; }
        public cen_QuestionProperty centre_maintain_the_registration_register { get; set; }
        public cen_QuestionProperty centre_have_standardised_initial_assessment { get; set; }
        public cen_QuestionProperty centre_define_criteria_mechanism_identify_patients { get; set; }
        public cen_QuestionProperty policy_to_proceed_additional_specialized_assessments { get; set; }
        public cen_QuestionProperty policy_to_incorporate_outside_assessment { get; set; }
        public cen_QuestionProperty centres_scope_of_services_mission_resources { get; set; }
        public cen_QuestionProperty centre_have_referralout_system_for_additional_care { get; set; }
        public cen_QuestionPropertyopd maintain_proper_coordination_between_medical_centres { get; set; }
    }

    public class cen_QuestionPropertyopd
    {
        public long ques_id { get; set; }
        public string ques_stndrd_code { get; set; }
        public string ques_text { get; set; }
        public string ques_help_text { get; set; }
        public string ques_selected_opt { get; set; }
        public string ques_doc_url { get; set; }
        public string old_ques_histry_opt { get; set; }
        public string old_ques_doc_url { get; set; }
        public string ques_text_value { get; set; }



    }

}
