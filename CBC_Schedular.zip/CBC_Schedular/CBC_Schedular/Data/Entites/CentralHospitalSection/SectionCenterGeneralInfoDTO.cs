﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CBC_Schedular.Data.Entites.HospitalSections
{
    public class SectionCenterGeneralInfoDTO
    {
        public SectionCenterGeneralInfoDTO()
        {
            this.basicCertification = new BasicCertification();
            this.generalInfo = new GeneralInfo();
            this.organizationInformation = new OrganizationInformation();
        }

        public BasicCertification basicCertification { get; set; }
        public GeneralInfo generalInfo { get; set; }
        public OrganizationInformation organizationInformation { get; set; }

    }


    public class BasicCenterCertification
    {
        public string organization_type { get; set; }
        public string ayush_system { get; set; }
    }

    public class CenterGeneralInfo
    {
        public CenterGeneralInfo()
        {
            this.location = new CenterLocation();
            this.organizationhead = new CenterOrganizationhead();
        }
        public string org_name { get; set; }
        public bool pat_stay_overnight { get; set; }
        public string build_name { get; set; }
        public string address { get; set; }
        public string street { get; set; }
        public string state { get; set; }
        public string district { get; set; }
        public string city { get; set; }
        public string pincode { get; set; }
        public string nearby_landmark { get; set; }

        public string org_website { get; set; }
        public string total_sanctioned_beds { get; set; }
        public string total_operational_beds { get; set; }
        public string no_beds { get; set; }
        public string landline { get; set; }
        public string spoc_name { get; set; }
        public string spoc_mob { get; set; }
        public string spoc_designtion { get; set; }
        public string spoc_email { get; set; }

        public CenterOrganizationhead organizationhead { get; set; }
        public CenterLocation location { get; set; }
    }

    public class CenterOrganizationhead
    {
        public bool? org_head_same_as_spoc { get; set; }
        public string spoc_name { get; set; }
        public string salutation { get; set; }
        public string spoc_mob { get; set; }
        public string spoc_desig { get; set; }
        public string spoc_email { get; set; }
    }

    public class CenterLocation
    {
        public CenterLocation()
        {
            this.splitLocation = new List<CenterSplitLocation>();
        }
        public string latitude { get; set; }
        public string longitude { get; set; }
        public string location_of_organization { get; set; }
        public bool does_org_hv_split_loc { get; set; }
        public long split_loc_nos { get; set; }
        public List<CenterSplitLocation> splitLocation { get; set; }
    }


    public class CenterSplitLocation
    {
        public string id { get; set; }
        public string split_build_name { get; set; }
        public string split_state { get; set; }
        public int? split_district { get; set; }
        public string split_city { get; set; }
        public string split_address { get; set; }
        public string split_pincode { get; set; }
        public string name_spoc_loc { get; set; }
        public string mob_spoc_loc { get; set; }
        public string email_spoc_loc { get; set; }
        public string dist_frm_main_loc { get; set; }
    }


    public class CenterOrganizationInformation
    {
        public CenterOrganizationInformation()
        {
            this.organization_is_already_empanelled_with = new CenterEmpanelledForOtherSchemes();
        }
        public string establishment_date_of_org { get; set; }
        public string organization_ownership_type { get; set; }
        public string month_year_setup { get; set; }
        
        public string mention_ownership_type { get; set; }
        public string organization_ownership_type_url { get; set; }
        public string mention_other_scheme_orgztn_linked { get; set; }
        public CenterEmpanelledForOtherSchemes organization_is_already_empanelled_with { get; set; }


    }


    public class CenterEmpanelledForOtherSchemes
    {
        public bool? cghs { get; set; }
        public string cghs_url { get; set; }
        public bool? railways { get; set; }
        public string railways_url { get; set; }
        public bool? ayushmanbharat { get; set; }
        public string ayushmanbharat_url { get; set; }
        public bool? publichealthinsuranceschemes { get; set; }
        public string publichealthinsuranceschemes_url { get; set; }
        public bool? echs { get; set; }
        public string echs_url { get; set; }
        public bool? stategovernmenthealthscheme { get; set; }
        public string stategovernmenthealthscheme_url { get; set; }
        public bool? others { get; set; }
        public string others_url { get; set; }
        public string other_scheme_organization_is_linked { get; set; }// if empanelledforotherschemes == other
        public string mentionothertypeofschemes_url { get; set; }
        public bool? none { get; set; }
    }



    public class SectionCenterGeneralInfoQuesBankDTO
    {
        public QuestionBankProperty type_of_organization { get; set; }
        public QuestionBankProperty ayush_systems_provided_by_the_organization { get; set; }
        public QuestionBankProperty name_of_the_organization { get; set; }
        public QuestionBankProperty do_patients_stay_overnight { get; set; }

        public QuestionBankProperty name_of_the_building { get; set; }
        public QuestionBankProperty address { get; set; }
        public QuestionBankProperty street { get; set; }
        public QuestionBankProperty state { get; set; }

        public QuestionBankProperty district { get; set; }
        public QuestionBankProperty city { get; set; }
        public QuestionBankProperty pin_code { get; set; }
        public QuestionBankProperty nearby_landmark { get; set; }

        public QuestionBankProperty organization_website { get; set; }
        public QuestionBankProperty total_number_of_sanctioned_beds { get; set; }
        public QuestionBankProperty total_number_of_operational_beds { get; set; }
        public QuestionBankProperty landline_number { get; set; }
        public QuestionBankProperty spoc_name { get; set; }
        public QuestionBankProperty spoc_mobile_number { get; set; }
        public QuestionBankProperty spoc_designation { get; set; }
        public QuestionBankProperty spoc_emailid { get; set; }
        public QuestionBankProperty latitude { get; set; }
        public QuestionBankProperty longitude { get; set; }
        public QuestionBankProperty location_of_organization { get; set; }
        public QuestionBankProperty organization_have_a_split_location { get; set; }
        public QuestionBankProperty split_locations_does_the_organization_have { get; set; }
        public QuestionBankProperty date_of_establishment { get; set; }
        public QuestionBankProperty month_and_year_of_clinical_service { get; set; }
        public QuestionBankProperty organization_ownership_type { get; set; }

        public QuestionBankProperty ownership_type { get; set; }
        public QuestionBankProperty organization_is_already_empanelled_with { get; set; }
        public QuestionBankProperty other_scheme_organization_is_linked_with { get; set; }

    }

    

}
