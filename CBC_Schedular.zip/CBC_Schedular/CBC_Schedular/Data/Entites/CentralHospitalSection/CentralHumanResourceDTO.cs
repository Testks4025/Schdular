﻿using CBC_Schedular.Data.Entites.HospitalSections;
using System;
using System.Collections.Generic;
using System.Text;

namespace CBC_Schedular.Data.Entites.CentralHospitalSection
{
    public class CentralHumanResourceDTO
    {

      public  CentralHumanResourceDTO()
        {
            group_list = new List<GroupList>();
            doctors_along_with_qualification_specialisation = new CentralHospDoctorDetailsQuestionProperty();
            list_of_all_the_nurses = new CentralHospStaffDetailsQuestionProperty();
            list_of_paricharika_therapist = new CentralHospStaffDetailsQuestionProperty();
            list_of_all_the_paramedic_staff = new CentralHospStaffDetailsQuestionProperty();
            administrative_and_support_staff = new CentralHospStaffDetailsQuestionProperty();
            doctors_masseurs_and_support_staff = new cen_QuestionProperty();
            specific_job_and_responsibilities_and_adherence = new cen_QuestionProperty();
            centre_allotted_specified_jobs_description = new cen_QuestionProperty();
            manpower_details = new cen_QuestionProperty();


        }

        public List<GroupList> group_list { get; set; }

        public CentralHospDoctorDetailsQuestionProperty doctors_along_with_qualification_specialisation { get; set; }
        public CentralHospStaffDetailsQuestionProperty list_of_all_the_nurses { get; set; }
        public CentralHospStaffDetailsQuestionProperty list_of_paricharika_therapist { get; set; }
        public CentralHospStaffDetailsQuestionProperty list_of_all_the_paramedic_staff { get; set; }
        public CentralHospStaffDetailsQuestionProperty administrative_and_support_staff { get; set; }
        public cen_QuestionProperty doctors_masseurs_and_support_staff { get; set; }
        public cen_QuestionProperty centre_allotted_specified_jobs_description { get; set; }
        public cen_QuestionProperty specific_job_and_responsibilities_and_adherence { get; set; }
        public cen_QuestionProperty manpower_details { get; set; }



    }
    public class CentralHospDoctorDetailsQuestionProperty : cen_QuestionProperty
    {

        public CentralHospDoctorDetailsQuestionProperty()
        {
            doctor_details = new List<StaffDetails>();

        }
        public List<StaffDetails> doctor_details { get; set; }



    }

    public class CentralHospStaffDetailsQuestionProperty : cen_QuestionProperty
    {

        public CentralHospStaffDetailsQuestionProperty()
        {
            staff_details = new List<StaffDetails>();

        }
        public List<StaffDetails> staff_details { get; set; }

    }

}
