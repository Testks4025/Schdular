﻿using CBC_Schedular.Data.Entites.HospitalSections;
using System;
using System.Collections.Generic;
using System.Text;

namespace CBC_Schedular.Data.Entites.CentralHospitalSection
{
    public class CentralStatutoryCompilanceDTO
    {
        public CentralStatutoryCompilanceDTO()
        {
            this.registration_license_list = new List<CentralRegistrationLicense>();
       //     this.others_license_list = new List<AddOtherLicense>();
            this.document_portraying_its_affiliations_and_accreditation = new cen_QuestionProperty();
            this.centre_have_a_certificate_of_incorporation = new cen_QuestionProperty();
            this.centre_comply_to_applicable_statutory_requirements = new cen_QuestionProperty();
            this.registration_license = new cen_QuestionProperty();
            //this.state_pollution_control_board = new cen_QuestionProperty();
            //this.bio_medical_waste_collecting_agency = new cen_QuestionProperty();
            //this.fire_department_noc = new cen_QuestionProperty();
            //this.sanction_of_lift = new cen_QuestionProperty();
            //this.license_to_store_compressed_gas = new cen_QuestionProperty();
            //this.canteen_food_beverage_license = new cen_QuestionProperty();
            this.details_of_licience = new List<CentralLicienceDetailsMou>();
            this.hospital_hv_mou_wt_bilogical_waste = new CentralMouBilogicalWaste();


        }
        public cen_QuestionProperty document_portraying_its_affiliations_and_accreditation { get; set; }
        public cen_QuestionProperty centre_have_a_certificate_of_incorporation { get; set; }
        public cen_QuestionProperty centre_comply_to_applicable_statutory_requirements { get; set; }
        public cen_QuestionProperty registration_license { get; set; }
        public List<CentralRegistrationLicense> registration_license_list { get; set; }
        //public cen_QuestionProperty state_pollution_control_board { get; set; }
        //public cen_QuestionProperty bio_medical_waste_collecting_agency { get; set; }
        //public cen_QuestionProperty fire_department_noc { get; set; }
        //public cen_QuestionProperty sanction_of_lift { get; set; }
        //public cen_QuestionProperty license_to_store_compressed_gas { get; set; }
        //public cen_QuestionProperty canteen_food_beverage_license { get; set; }
        //  public List<AddOtherLicense> others_license_list { get; set; }
        public List<CentralLicienceDetailsMou> details_of_licience { get; set; }
        public CentralMouBilogicalWaste hospital_hv_mou_wt_bilogical_waste { get; set; }

    }

    public class CentralMouBilogicalWaste : cen_QuestionProperty
    {
        public bool available  { get; set; }
        public String agency_name { get; set; }
        public DateStruct valid_from { get; set; }
        public DateStruct valid_till { get; set; }
      
    }

    public class CentralRegistrationLicense
    {
        public String name_of_lagislation { get; set; }
        public String other { get; set; }
        public String name_of_authority { get; set; }
        public String status { get; set; }
        public String application_number_renewal { get; set; }
        public String license_number { get; set; }
        public String valid_from { get; set; }
        public String valid_till { get; set; }
        public String license_url { get; set; }
      
    }

    //public class AddOtherLicense
    //{


    //    public String status { get; set; }
    //    public String application_number_renewal { get; set; }
    //    public String license_number { get; set; }
    //    public String valid_from { get; set; }
    //    public String valid_till { get; set; }
    //    public String license_url { get; set; }


    //}
    public class CentralLicienceDetailsMou
    {
        public int id { get; set; }
        public String lic_name { get; set; }
        public String isapplicable { get; set; }
        public CentralLicenseMouDetails lic_detail { get; set; }
       
    }


    public class CentralLicenseMouDetails
    {

        public String licience_name { get; set; }
        public String agent_licensing_name { get; set; }
        public String status { get; set; }
        public String application_number_renewal { get; set; }
        public String license_number { get; set; }
        public DateStruct valid_from { get; set; }
        public DateStruct valid_till { get; set; }
        public String license_url { get; set; }



    
}

}
