﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CBC_Schedular.Data.Entites.CentralHospitalSection
{
    public class cen_QuestionProperty
    {
        public long ques_id { get; set; }

        public String ques_stndrd_code { get; set; }
    public String ques_text { get; set; }
        public String ques_help_text { get; set; }
        public bool? ques_selected_opt { get; set; }
        public String answer_text { get; set; }
        public String ques_doc_url { get; set; }
        public bool is_ques_disabled { get; set; }
        public String old_ques_histry_opt { get; set; }


    }
  
}
