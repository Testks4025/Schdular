﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CBC_Schedular.Data.Entites.CentralHospitalSection
{
  public  class CentralQualityOfCareDTO
    {

        public CentralQualityOfCareDTO()
        {
            this.plan_of_care_including_preventive_aspects = new cen_QuestionProperty();
            this.applicable_laws_and_regulations = new cen_QuestionProperty();
            this.centre_ensure_that_the_care_of_patient = new cen_QuestionProperty();
            this.sop_policy_to_guide_the_provision_of_services = new cen_QuestionProperty();
            this.care_and_treatment_of_vulnerable_patients = new cen_QuestionProperty();
            this.special_precautions_for_the_vulnerable_patients = new cen_QuestionProperty();
            this.care_of_patients_undergoing_various_ayush_therapies = new cen_QuestionProperty();
            this.rehabilitative_services_and_commensurate = new cen_QuestionProperty();
            this.policy_to_guide_the_management_of_pain = new cen_QuestionProperty();
            this.the_paediatric_care_in_ayush_centre = new cen_QuestionProperty();
            this.data_has_specification_as_disease_age_group_and_gender_etc = new cen_QuestionProperty();
            this.procedure_notes_and_post_procedure_plan_of_care_of_the_patients = new cen_QuestionProperty();
            this.the_centre_to_meet_the_medication_needs_of_the_patient = new cen_QuestionProperty();
            this.sop_to_monitor_the_use_of_medication = new cen_QuestionProperty();
            this.procurement_process_storage_labelling_and_management_of_medications = new cen_QuestionProperty();
            this.policy_sop_to_guide_the_care_and_treatment = new cen_QuestionProperty();
            this.policies_and_procedures_for_the_safe_dispensing_of_medications = new cen_QuestionProperty();
            this.centre_emphasize_specifically_on_storage_of_lasa = new cen_QuestionProperty();
            this.sop_to_analyse_the_adverse_medication_effects_and_document = new cen_QuestionProperty();
            this.policy_to_report_analyse_and_implement_capa = new cen_QuestionProperty();
            this.the_timeframe_for_reporting_any_medication_error = new cen_QuestionProperty();
            this.clinical_practice_or_evidence_based_medicine_for_the_patient_care = new cen_QuestionProperty();
            this.sop_Policy_to_guide_the_basic_and_first_responder_emergency_care = new cen_QuestionProperty();
            this.sop_policy_to_meet_patient_care_needs = new cen_QuestionProperty();
            this.centre_have_documented_the_quality_management_programmes = new cen_QuestionProperty();
            this.quality_programmes_are_done_at_least_once_a_year = new cen_QuestionProperty();
            this.centre_conduct_periodic_audit_programmes = new cen_QuestionProperty();

        }
      public  cen_QuestionProperty plan_of_care_including_preventive_aspects { get; set; }
        public cen_QuestionProperty applicable_laws_and_regulations { get; set; }
        public cen_QuestionProperty centre_ensure_that_the_care_of_patient { get; set; }
        public cen_QuestionProperty sop_policy_to_guide_the_provision_of_services { get; set; }
        public cen_QuestionProperty care_and_treatment_of_vulnerable_patients { get; set; }
        public cen_QuestionProperty special_precautions_for_the_vulnerable_patients { get; set; }
        public cen_QuestionProperty care_of_patients_undergoing_various_ayush_therapies { get; set; }
        public cen_QuestionProperty rehabilitative_services_and_commensurate { get; set; }
        public cen_QuestionProperty policy_to_guide_the_management_of_pain { get; set; }
        public cen_QuestionProperty the_paediatric_care_in_ayush_centre { get; set; }
        public cen_QuestionProperty data_has_specification_as_disease_age_group_and_gender_etc { get; set; }
        public cen_QuestionProperty procedure_notes_and_post_procedure_plan_of_care_of_the_patients { get; set; }
        public cen_QuestionProperty the_centre_to_meet_the_medication_needs_of_the_patient { get; set; }
        public cen_QuestionProperty sop_to_monitor_the_use_of_medication { get; set; }
        public cen_QuestionProperty procurement_process_storage_labelling_and_management_of_medications { get; set; }
        public cen_QuestionProperty policy_sop_to_guide_the_care_and_treatment { get; set; }
        public cen_QuestionProperty policies_and_procedures_for_the_safe_dispensing_of_medications { get; set; }
        public cen_QuestionProperty centre_emphasize_specifically_on_storage_of_lasa { get; set; }
        public cen_QuestionProperty sop_to_analyse_the_adverse_medication_effects_and_document { get; set; }
        public cen_QuestionProperty policy_to_report_analyse_and_implement_capa { get; set; }
        public cen_QuestionProperty the_timeframe_for_reporting_any_medication_error { get; set; }
        public cen_QuestionProperty clinical_practice_or_evidence_based_medicine_for_the_patient_care { get; set; }
        public cen_QuestionProperty sop_Policy_to_guide_the_basic_and_first_responder_emergency_care { get; set; }
        public cen_QuestionProperty sop_policy_to_meet_patient_care_needs { get; set; }
        public cen_QuestionProperty centre_have_documented_the_quality_management_programmes { get; set; }
        public cen_QuestionProperty quality_programmes_are_done_at_least_once_a_year { get; set; }
        public cen_QuestionProperty centre_conduct_periodic_audit_programmes { get; set; }



    }
}
