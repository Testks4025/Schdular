﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CBC_Schedular.Data.Entites.CentralHospitalSection
{
   public class CentralPatientRecordDTO
    {

        public  CentralPatientRecordDTO()
        {
            this.preference_religious_and_cultural_needs = new cen_QuestionProperty();
            this.centre_educate_and_counsel_the_patient = new cen_QuestionProperty();
            this.policy_to_inform_patient_about_estimated_cost = new cen_QuestionProperty();
            this.available_options_and_allow_the_patient_to_make_an_informed_choice = new cen_QuestionProperty();
            this.policy_procedure_to_record_complaints_of_the_patients = new cen_QuestionProperty();
            this.patient_protection_rights_against_physical_abuse = new cen_QuestionProperty();
            this.cases_for_violation_of_patients_rights_and_responsibilities = new cen_QuestionProperty();
            this.system_for_documented_corrective_preventive_measures = new cen_QuestionProperty();
            this.sop_and_iec_to_educate_the_patients_and_family_members = new cen_QuestionProperty();
            this.safety_effectiveness_and_side_effects_of_medication = new cen_QuestionProperty();
            this.the_diet_and_nutrition_to_be_followed = new cen_QuestionProperty();
            this.consequences_of_refusal_of_treatment_and_document = new cen_QuestionProperty();
            this.specific_disease_process_prognosis_complications_and_prevention = new cen_QuestionProperty();
            this.policy_iec_to_inform_patient = new cen_QuestionProperty();
            this.centre_conduct_promotional_health_related = new cen_QuestionProperty();
            this.patients_information_is_kept_confidential = new cen_QuestionProperty();
            this.own_clinical_records = new cen_QuestionProperty();
            this.sop_to_prescribe_dispense_and_administer_the_medication = new cen_QuestionProperty();
            this.guidelines_of_good_clinical_practice = new GuidelinesofGoodClinicalPractice();
            this.medications_in_a_clear_legible_manner = new cen_QuestionProperty();
            this.patient_details_and_treatment = new cen_QuestionProperty();
            this.obtain_written_informed_consent_prior = new cen_QuestionProperty();
            this.list_of_procedures_and_treatment = new cen_QuestionProperty();
            this.information_of_risks_benefits_alternatives = new cen_QuestionProperty();
            this.language_understandable_by_the_patient = new cen_QuestionProperty();

            this.consent_forms_available_for_the_patient = new ConsentFormsAvailableforPatient();

            this.policy_to_choose_for_consent_authorization = new cen_QuestionProperty();
            this.patient_in_a_research = new cen_QuestionProperty();
            this.sop_policy_to_address_patients_informed_consent = new cen_QuestionProperty();
            this.hospital_maintain_the_patients_medical_records = new cen_QuestionPropertypatientrecord();
            this.patient_care_needs_and_regulatory_requirements = new NeedsRegulatoryRequirements();
            this.centre_record_the_written_summaries = new cen_QuestionProperty();
            this.centre_define_and_allow_only_authorised_personnels = new cen_QuestionProperty();
            this.retention_period_for_maintaining_and_disposing = new cen_QuestionProperty();

        }

        public cen_QuestionProperty preference_religious_and_cultural_needs { get; set; }
        public cen_QuestionProperty centre_educate_and_counsel_the_patient { get; set; }
        public cen_QuestionProperty policy_to_inform_patient_about_estimated_cost { get; set; }
        public cen_QuestionProperty available_options_and_allow_the_patient_to_make_an_informed_choice { get; set; }
        public cen_QuestionProperty policy_procedure_to_record_complaints_of_the_patients { get; set; }
        public cen_QuestionProperty patient_protection_rights_against_physical_abuse { get; set; }
        public cen_QuestionProperty cases_for_violation_of_patients_rights_and_responsibilities { get; set; }
        public cen_QuestionProperty system_for_documented_corrective_preventive_measures { get; set; }
        public cen_QuestionProperty sop_and_iec_to_educate_the_patients_and_family_members { get; set; }
        public cen_QuestionProperty safety_effectiveness_and_side_effects_of_medication { get; set; }
        public cen_QuestionProperty the_diet_and_nutrition_to_be_followed { get; set; }
        public cen_QuestionProperty consequences_of_refusal_of_treatment_and_document { get; set; }
        public cen_QuestionProperty specific_disease_process_prognosis_complications_and_prevention { get; set; }
        public cen_QuestionProperty policy_iec_to_inform_patient { get; set; }
        public cen_QuestionProperty centre_conduct_promotional_health_related { get; set; }
        public cen_QuestionProperty patients_information_is_kept_confidential { get; set; }
        public cen_QuestionProperty own_clinical_records { get; set; }
        public cen_QuestionProperty sop_to_prescribe_dispense_and_administer_the_medication { get; set; }
        public GuidelinesofGoodClinicalPractice guidelines_of_good_clinical_practice { get; set; }
        public cen_QuestionProperty medications_in_a_clear_legible_manner { get; set; }
        public cen_QuestionProperty patient_details_and_treatment { get; set; }
        public cen_QuestionProperty obtain_written_informed_consent_prior { get; set; }
        public cen_QuestionProperty list_of_procedures_and_treatment { get; set; }
        public cen_QuestionProperty information_of_risks_benefits_alternatives { get; set; }
        public cen_QuestionProperty language_understandable_by_the_patient { get; set; }
        public ConsentFormsAvailableforPatient consent_forms_available_for_the_patient { get; set; }
        public cen_QuestionProperty policy_to_choose_for_consent_authorization { get; set; }
        public cen_QuestionProperty patient_in_a_research { get; set; }
        public cen_QuestionProperty sop_policy_to_address_patients_informed_consent { get; set; }
        public cen_QuestionPropertypatientrecord hospital_maintain_the_patients_medical_records { get; set; }
        public NeedsRegulatoryRequirements patient_care_needs_and_regulatory_requirements { get; set; }
        public cen_QuestionProperty centre_record_the_written_summaries { get; set; }
        public cen_QuestionProperty centre_define_and_allow_only_authorised_personnels { get; set; }
        public cen_QuestionProperty retention_period_for_maintaining_and_disposing { get; set; }


    }
    public class GuidelinesofGoodClinicalPractice
    {

        public long ques_id { get; set; }
        public String ques_stndrd_code { get; set; }
          public String ques_text { get; set; }
        public String ques_help_text { get; set; }

        public String ques_doc_url { get; set; }
        public String old_ques_histry_opt { get; set; }
        public String ques_doc_url_1 { get; set; }
        public String ques_doc_url_2 { get; set; }
        public String ques_doc_url_3 { get; set; }

        
               public bool prescription_date { get; set; }
        public bool patient_name { get; set; }
        public bool uhid_number { get; set; }
        public bool name_of_drug { get; set; }
        public bool drug_dose { get; set; }
        public bool admin_of_medi { get; set; }
        public bool name_of_doct { get; set; }
        public bool sign_of_doctor { get; set; }
        public bool registration_no_doctor { get; set; }

    }

public class NeedsRegulatoryRequirements
    {
        public long ques_id { get; set; }
        public String ques_stndrd_code { get; set; }
        public String ques_text { get; set; }
        public String ques_help_text { get; set; }
       
        public String ques_doc_url_1 { get; set; }
        public String ques_doc_url_2 { get; set; }
        public String ques_doc_url_3 { get; set; }
        public String old_ques_histry_opt { get; set; }
        public String old_ques_doc_url { get; set; }

        public bool patient_name { get; set; }
        public bool uhid_number { get; set; }
        
        public bool name_of_doct { get; set; }
        public bool sign_of_doctor { get; set; }
        public bool registration_no_doctor { get; set; }

        public bool none { get; set; }
        


    }
    public class cen_QuestionPropertypatientrecord
    {
        public long ques_id { get; set; }
        public string ques_stndrd_code { get; set; }
        public string ques_text { get; set; }
        public string ques_help_text { get; set; }
        public string ques_selected_opt { get; set; }
        public string ques_doc_url { get; set; }
        public string old_ques_histry_opt { get; set; }
        public string old_ques_doc_url { get; set; }
        public string ques_text_value { get; set; }
    }
    public class ConsentFormsAvailableforPatient
    {
        public long ques_id { get; set; }
        public string ques_stndrd_code { get; set; }
        public bool? ques_selected_opt { get; set; }
        public string ques_text { get; set; }
        public string ques_help_text { get; set; }
        public string ques_doc_url_1 { get; set; }
        public string ques_doc_url_2 { get; set; }
        public string ques_doc_url_3 { get; set; }
        public string old_ques_doc_url { get; set; }
        public bool? old_ques_histry_opt { get; set; }
        
        

    }

}
