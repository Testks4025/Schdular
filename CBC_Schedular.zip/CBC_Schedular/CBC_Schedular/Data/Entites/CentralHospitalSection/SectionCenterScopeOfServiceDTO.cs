﻿using CBC_Schedular.Data.Entites.CentralHospitalSection;
using System;
using System.Collections.Generic;
using System.Text;

namespace CBC_Schedular.Data.Entites.HospitalSections
{
   public class SectionCenterScopeOfServiceDTO
    {
        public SectionCenterScopeOfServiceDTO()
        {
            this.scopeOfAyurvedaCertification = new CenterScopeOfAyurvedaCertification();
            this.sosHomeopathyCert = new CenterSosHomeopathyCert();
            this.opdSosProvidedDepartments = new CenterSOSprovidedDepartments();
           //this.ipdSosProvidedDepartments = new CenterSOSprovidedDepartments();
            this.providePatientvisitedOrganization = new CenterProvidePatientvisitedOrganization();
           // this.provideInpatientCareUnitOrWard = new CenterProvideInpatientCareUnitOrWard();
            this.provideAmbulatoryPatientsservice = new CenterProvideAmbulatoryPatientsservice();
            this.scopeOfNaturopathyCertification = new CenterScopeOfNaturopathyCertification();
            this.scopeOfYogaCertification = new CenterScopeOfYogaCertification();
            this.scopeOfUnaniCertification = new CenterScopeOfUnaniCertification();
            this.socSiddhaCertification = new CenterScopeOfShidaCertification();
        }

        public bool isAyurveda { get; set; }
        public bool isYoga { get; set; }
        public bool isNaturopathy { get; set; }
        public bool isUnani { get; set; }
        public bool isSiddha { get; set; }
        public bool isHomeopathy { get; set; }
        

        public CenterScopeOfAyurvedaCertification scopeOfAyurvedaCertification { get; set; }

        public CenterScopeOfNaturopathyCertification scopeOfNaturopathyCertification { get; set; }
        public CenterScopeOfYogaCertification scopeOfYogaCertification { get; set; }
        public CenterScopeOfUnaniCertification scopeOfUnaniCertification { get; set; }
               

        public CenterScopeOfShidaCertification socSiddhaCertification { get; set; }

        public CenterSosHomeopathyCert sosHomeopathyCert { get; set; }

        public CenterSOSprovidedDepartments opdSosProvidedDepartments { get; set; }
       // public CenterSOSprovidedDepartments ipdSosProvidedDepartments { get; set; }

        public CenterProvidePatientvisitedOrganization providePatientvisitedOrganization { get; set; }

        //public CenterProvideInpatientCareUnitOrWard provideInpatientCareUnitOrWard { get; set; }

        public CenterProvideAmbulatoryPatientsservice provideAmbulatoryPatientsservice { get; set; }

    }



    public class CenterClinicalServicesOptions
    {               
        public string service_name { get; set; }
        public string option { get; set; }
        public string remark { get; set; }
    }
   
    public class CenterScopeOfNaturopathyCertification
    {
        public CenterScopeOfNaturopathyCertification()
        {
            this.fixed_services = new List<CenterClinicalServicesOptions>();
            this.other_sos_service = new List<CenterClinicalServicesOptions>();
        }
        public List<CenterClinicalServicesOptions> fixed_services { get; set; }
        public List<CenterClinicalServicesOptions> other_sos_service { get; set; }
    }

    public class CenterScopeOfYogaCertification
    {
        public CenterScopeOfYogaCertification()
        {
            this.fixed_services = new List<CenterClinicalServicesOptions>();
            this.other_sos_service = new List<CenterClinicalServicesOptions>();
        }
        public List<CenterClinicalServicesOptions> fixed_services { get; set; }
        public List<CenterClinicalServicesOptions> other_sos_service { get; set; }
    }

    public class CenterScopeOfUnaniCertification
    {
        public CenterScopeOfUnaniCertification()
        {
            this.fixed_services = new List<CenterClinicalServicesOptions>();
            this.other_sos_service = new List<CenterClinicalServicesOptions>();
        }
        public List<CenterClinicalServicesOptions> fixed_services { get; set; }
        public List<CenterClinicalServicesOptions> other_sos_service { get; set; }
    }

    public class CenterScopeOfShidaCertification
    {
        public CenterScopeOfShidaCertification()
        {
            this.fixed_services = new List<CenterClinicalServicesOptions>();
            this.other_sos_service = new List<CenterClinicalServicesOptions>();
        }
        public List<CenterClinicalServicesOptions> fixed_services { get; set; }
        public List<CenterClinicalServicesOptions> other_sos_service { get; set; }
    }

    public class CenterScopeOfAyurvedaCertification
    {
       
        public CenterScopeOfAyurvedaCertification()
        {
            this.fixed_services = new List<CenterClinicalServicesOptions>();
           
        }
        public List<CenterClinicalServicesOptions> fixed_services { get; set; }
       
    }

    #region ScopeOfAyurvedaCertification Child   

    //public class CenterAyurvedaKayachikitsaServices
    //{
    //    public CenterAyurvedaKayachikitsaServices()
    //    {
    //        this.fixed_services = new List<CenterClinicalServicesOptions>();
    //        this.other_services = new List<CenterClinicalServicesOptions>();
    //    }
    //    public List<CenterClinicalServicesOptions> fixed_services { get; set; }
    //    public List<CenterClinicalServicesOptions> other_services { get; set; }
    //}

    //public class CenterAyurvedaShalakyaTantraServices
    //{
    //    public CenterAyurvedaShalakyaTantraServices()
    //    {
    //        this.fixed_services = new List<CenterClinicalServicesOptions>();
    //        this.other_services = new List<CenterClinicalServicesOptions>();
    //    }
    //    public List<CenterClinicalServicesOptions> fixed_services { get; set; }
    //    public List<CenterClinicalServicesOptions> other_services { get; set; }
    //}

    //public class CenterAyurvedaKaumarabhrithyaServices
    //{
    //    public CenterAyurvedaKaumarabhrithyaServices()
    //    {
    //        this.fixed_services = new List<CenterClinicalServicesOptions>();
    //        this.other_services = new List<CenterClinicalServicesOptions>();
    //    }
    //    public List<CenterClinicalServicesOptions> fixed_services { get; set; }
    //    public List<CenterClinicalServicesOptions> other_services { get; set; }
    //}

    //public class CenterAyurvedaAgadaTantraServices
    //{
    //    public CenterAyurvedaAgadaTantraServices()
    //    {
    //        this.fixed_services = new List<CenterClinicalServicesOptions>();
    //        this.other_services = new List<CenterClinicalServicesOptions>();
    //    }
    //    public List<CenterClinicalServicesOptions> fixed_services { get; set; }
    //    public List<CenterClinicalServicesOptions> other_services { get; set; }
    //}

    //public class CenterAyurvedaPrasootiTantraStreerogaServices
    //{
    //    public CenterAyurvedaPrasootiTantraStreerogaServices()
    //    {
    //        this.fixed_services = new List<CenterClinicalServicesOptions>();
    //        this.other_services = new List<CenterClinicalServicesOptions>();
    //    }
    //    public List<CenterClinicalServicesOptions> fixed_services { get; set; }
    //    public List<CenterClinicalServicesOptions> other_services { get; set; }
    //}

    //public class CenterAyurvedaShalyaTantraServices
    //{
    //    public CenterAyurvedaShalyaTantraServices()
    //    {
    //        this.fixed_services = new List<CenterClinicalServicesOptions>();
    //        this.other_services = new List<CenterClinicalServicesOptions>();
    //    }
    //    public List<CenterClinicalServicesOptions> fixed_services { get; set; }
    //    public List<CenterClinicalServicesOptions> other_services { get; set; }
    //}


    //public class CenterAyurvedaAnuShastraKarmasServices
    //{
    //    public CenterAyurvedaAnuShastraKarmasServices()
    //    {
    //        this.fixed_services = new List<CenterClinicalServicesOptions>();
    //        this.other_services = new List<CenterClinicalServicesOptions>();
    //    }
    //    public List<CenterClinicalServicesOptions> fixed_services { get; set; }
    //    public List<CenterClinicalServicesOptions> other_services { get; set; }
    //}


    #endregion  ScopeOfAyurvedaCertification Child



    public class CenterSosHomeopathyCert
    {
        public CenterSosHomeopathyCert()
        {
            this.fixed_services = new List<CenterClinicalServicesOptions>();
            this.other_sos_service = new List<CenterClinicalServicesOptions>();
        }
        public List<CenterClinicalServicesOptions> fixed_services { get; set; }       
        public List<CenterClinicalServicesOptions> other_sos_service { get; set; }
    }


    public class CenterSOSprovidedDepartments
    {
        public string dept_url { get; set; }
    }

    public class CenterProvidePatientvisitedOrganization
    {
        public CenterProvidePatientvisitedOrganization()
        {
            this.opdData = new CenterSosIPDData();
            this.ipdData = new CenterSosIPDData();
        }
        public CenterSosIPDData opdData { get; set; }
        public CenterSosIPDData ipdData { get; set; }
    }

    public class CenterSosIPDData
    {
        public string year { get; set; }
        public string no_of_patients { get; set; }
        public string year1 { get; set; }
        public string no_of_patients1 { get; set; }
    }

    //public class CenterProvideInpatientCareUnitOrWard
    //{
    //    public CenterProvideInpatientCareUnitOrWard()
    //    {
    //        this.inpatientCareUnitOrWard = new List<CenterInpatientCareUnitOrWardData>();
    //    }
    //   public List<CenterInpatientCareUnitOrWardData> inpatientCareUnitOrWard { get; set; }
    //}
    //public class CenterInpatientCareUnitOrWardData
    //{
    //    public string unit_or_ward_name { get; set; }
    //    public string number_of_beds { get; set; }
    //    public string type_of_care_given { get; set; }
    //    public string floor_or_location { get; set; }
    //    public string floor_plan_url { get; set; }
    //}


    public class CenterProvideAmbulatoryPatientsservice
    {
        public CenterProvideAmbulatoryPatientsservice()
        {
            this.ambulatoryPatientsservices = new List<CenterAmbulatoryPatientsserviceData>();
        }
        public string floor_plan_urll { get; set; }
        public List<CenterAmbulatoryPatientsserviceData> ambulatoryPatientsservices { get; set; }
    }


    
    public class CenterAmbulatoryPatientsserviceData
    {
        public string ambulatory_or_patient_name  { get; set; }
        public string average_visits_per_month { get; set; }
        public string type_of_service { get; set; }
        public string floor_location { get; set; }
        public string floor_plan_url { get; set; }
    }
    public class SectionCenterScopeOfServiceQuestionBankDTO
    {
        public SectionCenterScopeOfServiceQuestionBankDTO()
        {
            this.scope_services_provided_by_the_organization = new cen_QuestionProperty();
            this.lst_sop_per_dept = new cen_QuestionProperty();
            this.number_of_patients_for_last_two_years_visited_opd_and_ipd = new cen_QuestionProperty();
            this.list_of_ambulatory_or_out_patients_units_with_numberof_visits = new cen_QuestionProperty();
            
        }

        public cen_QuestionProperty scope_services_provided_by_the_organization { get; set; }
        public cen_QuestionProperty lst_sop_per_dept { get; set; }
        public cen_QuestionProperty number_of_patients_for_last_two_years_visited_opd_and_ipd { get; set; }
        public cen_QuestionProperty list_of_ambulatory_or_out_patients_units_with_numberof_visits { get; set; }
       
    }



}
