﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CBC_Schedular.Data.Entites.CentralHospitalSection
{
    public class cen_Training
    {
      
        public cen_Training()
        {
            this.communicate_disseminate_duties_jobs_responsibilities = new cen_QuestionProperty();
            this.inductin_trn_staff_orientation = new cenInductionTrainingStaff();
            this.training_employees_voluntary_worker_includes_orientation = new cen_QuestionProperty();
            this.responsibility_for_protecting_patients_right_responsibilities = new cen_QuestionProperty();
            this.occupational_risks_and_their_prevention = new cen_QuestionProperty();
            this.standard_precautions_of_hygiene_control_practices = new cen_QuestionProperty();
            this.regular_training_staff_for_infection_control = new cen_QuestionProperty();
            this.staff_for_identification_spill_management_training = new cen_QuestionProperty();
            this.continual_medical_education = new cen_QuestionProperty();
            this.staff_for_fighting_fire_nonfire_emergencies = new cen_QuestionProperty();
        }
        public cen_QuestionProperty communicate_disseminate_duties_jobs_responsibilities { get; set; }
        public cenInductionTrainingStaff inductin_trn_staff_orientation { get; set; }
        public cen_QuestionProperty training_employees_voluntary_worker_includes_orientation { get; set; }
        public cen_QuestionProperty responsibility_for_protecting_patients_right_responsibilities { get; set; }
        public cen_QuestionProperty occupational_risks_and_their_prevention { get; set; }
        public cen_QuestionProperty standard_precautions_of_hygiene_control_practices { get; set; }
        
        public cen_QuestionProperty regular_training_staff_for_infection_control { get; set; }
        public cen_QuestionProperty staff_for_identification_spill_management_training { get; set; }
        public cen_QuestionProperty continual_medical_education { get; set; }
        public cen_QuestionProperty staff_for_fighting_fire_nonfire_emergencies { get; set; }




    }
    public class cenInductionTrainingStaff
    {
        public bool vision_mission { get; set; }
        public bool employ_right { get; set; }
        public bool service_policies { get; set; }
        public String vision_mission_url { get; set; }
        public String employ_right_url { get; set; }
        public String service_policies_url { get; set; }
        public bool none { get; set; }


    }

}
