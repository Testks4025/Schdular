﻿using CBC_Schedular.Data.Entites.CentralHospitalSection;
using System;
using System.Collections.Generic;
using System.Text;

namespace CBC_Schedular.Data.Entites.HospitalSections
{
    public class HospitalSetionsQuestionBankDataDTO
    {
        public HospitalSetionsQuestionBankDataDTO()
        {
            this.infection_control = new SectionInfectioControlDTO();
            this.quality_care = new SectionQualityOfCareDTO();
            this.training = new SectionTrainingDTO();
            this.generalinfo = new SectionGeneralInfoQuesBankDTO();
            this.admsn_dischrge = new SectionAdmissionDischargeQuestionBankDTO();

            this.patient_record = new SectionPatientRecordDTO();
            this.admin_record = new SectionAdminRecordQuestionBankDTO();
            this.human_resource = new HumanResourceDTO();

            this.support_service = new SectionSupportServiceDTO();

            this.statutory_compliance = new SectionStatutaryComplianceDTO();
            this.scope_of_service = new SectionScopeOfServiceQuestionBankDTO();


        }

        public SectionInfectioControlDTO infection_control { get; set; }
        public SectionQualityOfCareDTO quality_care { get; set; }

        public SectionTrainingDTO training { get; set; }

        public SectionGeneralInfoQuesBankDTO generalinfo { get; set; }
        public SectionAdmissionDischargeQuestionBankDTO admsn_dischrge { get; set; }

        public SectionPatientRecordDTO patient_record { get; set; }
        public SectionAdminRecordQuestionBankDTO admin_record { get; set; }
        public HumanResourceDTO human_resource { get; set; }

        public SectionSupportServiceDTO support_service { get; set; }

        public SectionStatutaryComplianceDTO statutory_compliance { get; set; }

        public SectionScopeOfServiceQuestionBankDTO scope_of_service { get; set; }




    }
}
