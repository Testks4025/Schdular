﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CBC_Schedular.Data.Entites.HospitalSections
{
   public class SectionScopeOfServiceApp
    {
        public SectionScopeOfServiceApp()
        {
            this.scopeOfAyurvedaCertification = new ScopeOfAyurvedaCertification();
            this.sosHomeopathyCert = new SosHomeopathyCert();
           
           this.scopeOfNaturopathyCertification = new ScopeOfNaturopathyCertification();
            this.scopeOfYogaCertification = new ScopeOfYogaCertification();
            this.scopeOfUnaniCertification = new ScopeOfUnaniCertification();
        }

        public bool isAyurveda { get; set; }
        public bool isYoga { get; set; }
        public bool isNaturopathy { get; set; }
        public bool isUnani { get; set; }
        public bool isSiddha { get; set; }
        public bool isHomeopathy { get; set; }
        

        public ScopeOfAyurvedaCertification scopeOfAyurvedaCertification { get; set; }

        public ScopeOfNaturopathyCertification scopeOfNaturopathyCertification { get; set; }
        public ScopeOfYogaCertification scopeOfYogaCertification { get; set; }
        public ScopeOfUnaniCertification scopeOfUnaniCertification { get; set; }
               

        public List<ClinicalServicesOptions> socSiddhaCert { get; set; }

        public SosHomeopathyCert sosHomeopathyCert { get; set; }

 
    }



    #region ScopeOfAyurvedaCertification Child
    //public class AyurvedaClinicalServices
    //{
    //    public AyurvedaClinicalServices()
    //    {
    //       // this.panchakarma_therapies = new PanchakarmaTherapies();
    //        this.other_sos_service = new List<ClinicalServicesOptions>();
    //    }
    //    public List<ClinicalServicesOptions> ayurveda_clinical_services { get; set; }
    //  //  public PanchakarmaTherapies panchakarma_therapies { get; set; }
    //    public List<ClinicalServicesOptions> other_sos_service { get; set; }

    //}

    //public class PanchakarmaTherapies
    //{
    //    public PanchakarmaTherapies()
    //    {
    //        this.poorvakarma = new List<ClinicalServicesOptions>();
    //        this.pradhanakarma = new List<ClinicalServicesOptions>();
    //        this.paschatkarma = new List<ClinicalServicesOptions>();
           
    //    }
    //    public List<ClinicalServicesOptions> poorvakarma { get; set; }
    //    public List<ClinicalServicesOptions> pradhanakarma { get; set; }
    //    public List<ClinicalServicesOptions> paschatkarma { get; set; }
        
    //}  

    #endregion  ScopeOfAyurvedaCertification Child
   
   

   



    





 


   


}
