﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CBC_Schedular.Data.Entites.HospitalSections
{
    public class SectionStatutaryComplianceDTO
    {
        public SectionStatutaryComplianceDTO()
        {
            this.hospital_adheres_with_the_statutory_requirements = new QuestionProperty();
            this.conducts_its_functioning_as_a_duly_permitted_legal_entity = new QuestionProperty();
            this.regularly_updates_licenses_registrations_certifications = new QuestionProperty();
            this.discloses_the_documents_regarding_the_ownership = new QuestionProperty();
            this.registration_license = new QuestionProperty();
            //this.license_from_state_pollution_control_board = new QuestionProperty();
            //this.bio_medical_waste_collecting_agency = new QuestionProperty();
            //this.pollution_control_board_license_of_water = new QuestionProperty();
            //this.fire_department_noc = new QuestionProperty();
            //this.sanction_of_lift = new QuestionProperty();
            //this.license_to_store_compressed_gas = new QuestionProperty();
            //this.canteen_food_beverage_license = new QuestionProperty();
            this.registration_license_list = new List<RegistrationLicense>();
           // this.others_license_list = new List<AddOtherLicense>();
            this.hospital_hv_mou_wt_bilogical_waste = new MouBilogicalWaste();
            this.details_of_licience = new List<LicienceDetailsMou>();

        }

        public QuestionProperty hospital_adheres_with_the_statutory_requirements { get; set; }
        public QuestionProperty conducts_its_functioning_as_a_duly_permitted_legal_entity { get; set; }
        public QuestionProperty regularly_updates_licenses_registrations_certifications { get; set; }
        public QuestionProperty discloses_the_documents_regarding_the_ownership { get; set; }
        public QuestionProperty registration_license { get; set; }
        //public QuestionProperty license_from_state_pollution_control_board { get; set; }
        //public QuestionProperty bio_medical_waste_collecting_agency { get; set; }
        //public QuestionProperty pollution_control_board_license_of_water { get; set; }
        //public QuestionProperty fire_department_noc { get; set; }
        //public QuestionProperty sanction_of_lift { get; set; }
        //public QuestionProperty license_to_store_compressed_gas { get; set; }
        //public QuestionProperty canteen_food_beverage_license { get; set; }
        public List<LicienceDetailsMou> details_of_licience { get; set; }
        public List<RegistrationLicense> registration_license_list { get; set; }
        //public List<AddOtherLicense> others_license_list { get; set; }
        public MouBilogicalWaste hospital_hv_mou_wt_bilogical_waste { get; set; }

    }
    public class MouBilogicalWaste:QuestionProperty
    {
        public Boolean? available { get; set; }
        public string agency_name { get; set; }
        public DateStruct valid_from { get; set; }
        public DateStruct valid_till { get; set; }
    
   
    }

    public class RegistrationLicense
    {
        public string agency_name { get; set; }
        public string others { get; set; }
        public string status { get; set; }
        public string application_number_renewal { get; set; }
        public string license_number { get; set; }
        public string valid_from { get; set; }
        public string valid_till { get; set; }
        public string license_url { get; set; }
    }

    public class LicienceDetailsMou
    {
        public int id { get; set; }
        public string lic_name { get; set; }
        public int ques_id { get; set; }
        public string ques_text { get; set; }
        public string isapplicable { get; set; }
       public LicenseMouDetails lic_detail { get; set; }
    }
    public class LicenseMouDetails
    {
        public string licience_name { get; set; }
        
        public string agent_licensing_name { get; set; }       
        public string status { get; set; }
        public string application_number_renewal { get; set; }
        public string license_number { get; set; }
        public DateStruct valid_from { get; set; }
        public DateStruct valid_till { get; set; }
        public string license_url { get; set; }
    }
}
