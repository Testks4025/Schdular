﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CBC_Schedular.Data.Entites.HospitalSections
{
   public class SectionAdminRecordDTO
    {
        public SectionAdminRecordDTO()
        {


            this.hospital_maintains_the_documents_brochure =new QuestionProperty();
            this.lays_down_its_vision_and_mission_commensurate =new QuestionProperty();
            this.line_of_control_and_functions_at_various_level =new QuestionProperty();
            this.defines_patient_visitor_and_employees_related_risks =new QuestionProperty();
            this.standard_billing_tariff_for_its_services =new QuestionProperty();
            this.incident_identification_and_reporting_system =new QuestionProperty();
            this.incidents_preferably_by_identifying_route_cause =new QuestionProperty();
            this.hospital_documents_the_corrective_and_preventive =new QuestionProperty();
            this.document_the_list_of_sentinel_Events =new QuestionProperty();
            this.hospital_make_a_records_of_such_incidents =new QuestionProperty();
            this.identify_sentinel_events_within_working_hours =new QuestionProperty();
            this.injuries_and_pre_and_post_exposure_prophylaxis =new QuestionProperty();
            this.plan_for_detection_abatement_and_containment =new QuestionProperty();
            this.safe_exit_plan_for_both_fire_and_nonfire_emergencies =new QuestionProperty();
            this.mous_agreements_for_all_outsourced_activities =new QuestionProperty();
            this.potable_water_and_electricity_round_the_clock =new QuestionProperty();
            this.potable_water_and_electricity_round_the_clock =new QuestionProperty();
            this.alternate_sources_for_water_and_electricity =new QuestionProperty();
            this.accordance_with_its_services_and_future_requirements =new QuestionProperty();
            this.process_of_periodic_equipment_plan_review =new QuestionProperty();
            this.maintains_proper_logs_of_the_inventory =new QuestionProperty();
            this.maintains_relevant_quality_conformance_certificates =new QuestionProperty();
            this.availability_of_maintenance_staff_round_the_clock =new QuestionProperty();
            this.escalation_matrix_in_case_of_emergency_repair =new QuestionProperty();
            this.implementation_of_corrective_actions_by_maintenace_staff =new QuestionProperty();
            this.maintains_the_documented_operational_maintenance =new QuestionProperty();
            this.operators_properly_trained_in_handling_equipments =new QuestionProperty();
            this.hospital_have_check_list_for_facility_inspection =new QuestionProperty();
            this.plan_and_budget_for_replacing_the_findings =new QuestionProperty();
            this.hospital_maintains_inspection_and_calibration =new QuestionProperty();
            this.inspection_testing_functionality_preventive_breakdown =new QuestionProperty();
            this.statutory_recommendations_for_fire_equipments =new QuestionProperty();
            this.personal_file_of_staffs_containing_information =new QuestionProperty();
            this.hospital_ensures_that_the_staff_record_files =new QuestionProperty();
            this.confidentiality_and_controlled_personal_access =new QuestionProperty();
            this.documents_regarding_employee =new QuestionProperty();
            this.hospital_have_healthcare_policies_for_employees =new QuestionProperty();
            this.carries_out_health_check_up_of_employees =new HealthCheckupOfEmployee();
            this.hospital_have_multi_disciplinary_committee =new QuestionProperty();
            this.quality_safety_infection_control_pharmacy_therapeutics =new QuestionProperty();
            this.committee_members_drawn_from_different_categories =new QuestionProperty();
            this.membership_responsibility_and_periodicity =new QuestionProperty();
            this.identify_potential_safety_risks_by_members =new QuestionProperty();
            this.training_to_every_staff_disciplinary_grievance =new QuestionProperty();
            this.regard_to_disciplinary_and_grievance_handling_system =new QuestionProperty();
            this.appellate_authority_to_consider_appeals =new QuestionProperty();
            this.ppellate_authority_holds_higher_authority =new QuestionProperty();
            this.complaints_grievances_and_clinical_care_delivery =new QuestionProperty();
            this.follows_readressal_of_complaint_of_mechanism =new QuestionProperty();
            this.mous_agreements_for_all_outsourced_activities_list = new List<ListofMoUsmonitoringservice>();

        }
        public QuestionProperty hospital_maintains_the_documents_brochure { get; set; }
        public QuestionProperty lays_down_its_vision_and_mission_commensurate { get; set; }
        public QuestionProperty line_of_control_and_functions_at_various_level { get; set; }
        public QuestionProperty defines_patient_visitor_and_employees_related_risks { get; set; }
        public QuestionProperty standard_billing_tariff_for_its_services { get; set; }
        public QuestionProperty incident_identification_and_reporting_system { get; set; }
        public QuestionProperty incidents_preferably_by_identifying_route_cause { get; set; }
        public QuestionProperty hospital_documents_the_corrective_and_preventive { get; set; }
        public QuestionProperty document_the_list_of_sentinel_Events { get; set; }
        public QuestionProperty hospital_make_a_records_of_such_incidents { get; set; }
        public QuestionProperty identify_sentinel_events_within_working_hours { get; set; }
        public QuestionProperty injuries_and_pre_and_post_exposure_prophylaxis { get; set; }
        public QuestionProperty plan_for_detection_abatement_and_containment { get; set; }
        public QuestionProperty safe_exit_plan_for_both_fire_and_nonfire_emergencies { get; set; }
        public QuestionProperty mous_agreements_for_all_outsourced_activities { get; set; }
        public QuestionProperty potable_water_and_electricity_round_the_clock { get; set; }
        public QuestionProperty alternate_sources_for_water_and_electricity { get; set; }
        public QuestionProperty accordance_with_its_services_and_future_requirements { get; set; }
        public QuestionProperty process_of_periodic_equipment_plan_review { get; set; }
        public QuestionProperty maintains_proper_logs_of_the_inventory { get; set; }
        public QuestionProperty maintains_relevant_quality_conformance_certificates { get; set; }
        public QuestionProperty availability_of_maintenance_staff_round_the_clock { get; set; }
        public QuestionProperty escalation_matrix_in_case_of_emergency_repair { get; set; }
        public QuestionProperty implementation_of_corrective_actions_by_maintenace_staff { get; set; }
        public QuestionProperty maintains_the_documented_operational_maintenance { get; set; }
        public QuestionProperty operators_properly_trained_in_handling_equipments { get; set; }
        public QuestionProperty hospital_have_check_list_for_facility_inspection { get; set; }
        public QuestionProperty plan_and_budget_for_replacing_the_findings { get; set; }
        public QuestionProperty hospital_maintains_inspection_and_calibration { get; set; }
        public QuestionProperty inspection_testing_functionality_preventive_breakdown { get; set; }
        public QuestionProperty statutory_recommendations_for_fire_equipments { get; set; }
        public QuestionProperty personal_file_of_staffs_containing_information { get; set; }
        public QuestionProperty hospital_ensures_that_the_staff_record_files { get; set; }
        public QuestionProperty confidentiality_and_controlled_personal_access { get; set; }
        public QuestionProperty documents_regarding_employee { get; set; }
        public QuestionProperty hospital_have_healthcare_policies_for_employees { get; set; }
        public HealthCheckupOfEmployee carries_out_health_check_up_of_employees { get; set; }
        public QuestionProperty hospital_have_multi_disciplinary_committee { get; set; }
        public QuestionProperty quality_safety_infection_control_pharmacy_therapeutics { get; set; }
        public QuestionProperty committee_members_drawn_from_different_categories { get; set; }
        public QuestionProperty membership_responsibility_and_periodicity { get; set; }
        public QuestionProperty identify_potential_safety_risks_by_members { get; set; }
        public QuestionProperty training_to_every_staff_disciplinary_grievance { get; set; }
        public QuestionProperty regard_to_disciplinary_and_grievance_handling_system { get; set; }
        public QuestionProperty appellate_authority_to_consider_appeals { get; set; }
        public QuestionProperty ppellate_authority_holds_higher_authority { get; set; }
        public QuestionProperty complaints_grievances_and_clinical_care_delivery { get; set; }
        public QuestionProperty follows_readressal_of_complaint_of_mechanism { get; set; }
        public List<ListofMoUsmonitoringservice> mous_agreements_for_all_outsourced_activities_list { get; set; }
    }

    public class ListofMoUsmonitoringservice
    {
        public string serviceName { get; set; }
        public string agencyName { get; set; }
        public string available{ get; set; }
        public string validFrom{ get; set; }
        public string validTill { get; set; }
        public string mou_url { get; set; }
        
    }



    public class SectionAdminRecordQuestionBankDTO
    {

        public SectionAdminRecordQuestionBankDTO()
        {
            this.hospital_maintains_the_documents_brochure = new QuestionBankProperty();
            this.lays_down_its_vision_and_mission_commensurate = new QuestionBankProperty();
            this.line_of_control_and_functions_at_various_level = new QuestionBankProperty();
            this.defines_patient_visitor_and_employees_related_risks = new QuestionBankProperty();
            this.standard_billing_tariff_for_its_services = new QuestionBankProperty();
            this.incident_identification_and_reporting_system = new QuestionBankProperty();
            this.incidents_preferably_by_identifying_route_cause = new QuestionBankProperty();
            this.hospital_documents_the_corrective_and_preventive = new QuestionBankProperty();
            this.document_the_list_of_sentinel_Events = new QuestionBankProperty();
            this.hospital_make_a_records_of_such_incidents = new QuestionBankProperty();
            this.identify_sentinel_events_within_working_hours = new QuestionBankProperty();
            this.injuries_and_pre_and_post_exposure_prophylaxis = new QuestionBankProperty();
            this.plan_for_detection_abatement_and_containment = new QuestionBankProperty();
            this.safe_exit_plan_for_both_fire_and_nonfire_emergencies = new QuestionBankProperty();
            this.mous_agreements_for_all_outsourced_activities = new QuestionBankProperty();
            this.potable_water_and_electricity_round_the_clock = new QuestionBankProperty();
            this.alternate_sources_for_water_and_electricity = new QuestionBankProperty();
            this.accordance_with_its_services_and_future_requirements = new QuestionBankProperty();
            this.process_of_periodic_equipment_plan_review = new QuestionBankProperty();
            this.maintains_proper_logs_of_the_inventory = new QuestionBankProperty();
            this.maintains_relevant_quality_conformance_certificates = new QuestionBankProperty();
            this.availability_of_maintenance_staff_round_the_clock = new QuestionBankProperty();
            this.escalation_matrix_in_case_of_emergency_repair = new QuestionBankProperty();
            this.implementation_of_corrective_actions_by_maintenace_staff = new QuestionBankProperty();
            this.maintains_the_documented_operational_maintenance = new QuestionBankProperty();
            this.operators_properly_trained_in_handling_equipments = new QuestionBankProperty();
            this.hospital_have_check_list_for_facility_inspection = new QuestionBankProperty();
            this.plan_and_budget_for_replacing_the_findings = new QuestionBankProperty();
            this.hospital_maintains_inspection_and_calibration = new QuestionBankProperty();
            this.inspection_testing_functionality_preventive_breakdown = new QuestionBankProperty();
            this.statutory_recommendations_for_fire_equipments = new QuestionBankProperty();
            this.personal_file_of_staffs_containing_information = new QuestionBankProperty();
            this.hospital_ensures_that_the_staff_record_files = new QuestionBankProperty();
            this.confidentiality_and_controlled_personal_access = new QuestionBankProperty();
            this.documents_regarding_employee = new QuestionBankProperty();
            this.hospital_have_healthcare_policies_for_employees = new QuestionBankProperty();
            this.carries_out_health_check_up_of_employees = new HealthCheckupOfEmployee();
            this.hospital_have_multi_disciplinary_committee = new QuestionBankProperty();
            this.quality_safety_infection_control_pharmacy_therapeutics = new QuestionBankProperty();
            this.committee_members_drawn_from_different_categories = new QuestionBankProperty();
            this.membership_responsibility_and_periodicity = new QuestionBankProperty();
            this.identify_potential_safety_risks_by_members = new QuestionBankProperty();
            this.training_to_every_staff_disciplinary_grievance = new QuestionBankProperty();
            this.regard_to_disciplinary_and_grievance_handling_system = new QuestionBankProperty();
            this.appellate_authority_to_consider_appeals = new QuestionBankProperty();
            this.ppellate_authority_holds_higher_authority = new QuestionBankProperty();
            this.complaints_grievances_and_clinical_care_delivery = new QuestionBankProperty();
            this.follows_readressal_of_complaint_of_mechanism = new QuestionBankProperty();

        }
        public QuestionBankProperty hospital_maintains_the_documents_brochure { get; set; }
        public QuestionBankProperty lays_down_its_vision_and_mission_commensurate { get; set; }
        public QuestionBankProperty line_of_control_and_functions_at_various_level { get; set; }
        public QuestionBankProperty defines_patient_visitor_and_employees_related_risks { get; set; }
        public QuestionBankProperty standard_billing_tariff_for_its_services { get; set; }
        public QuestionBankProperty incident_identification_and_reporting_system { get; set; }
        public QuestionBankProperty incidents_preferably_by_identifying_route_cause { get; set; }
        public QuestionBankProperty hospital_documents_the_corrective_and_preventive { get; set; }
        public QuestionBankProperty document_the_list_of_sentinel_Events { get; set; }
        public QuestionBankProperty hospital_make_a_records_of_such_incidents { get; set; }
        public QuestionBankProperty identify_sentinel_events_within_working_hours { get; set; }
        public QuestionBankProperty injuries_and_pre_and_post_exposure_prophylaxis { get; set; }
        public QuestionBankProperty plan_for_detection_abatement_and_containment { get; set; }
        public QuestionBankProperty safe_exit_plan_for_both_fire_and_nonfire_emergencies { get; set; }
        public QuestionBankProperty mous_agreements_for_all_outsourced_activities { get; set; }
        public QuestionBankProperty potable_water_and_electricity_round_the_clock { get; set; }
        public QuestionBankProperty alternate_sources_for_water_and_electricity { get; set; }
        public QuestionBankProperty accordance_with_its_services_and_future_requirements { get; set; }
        public QuestionBankProperty process_of_periodic_equipment_plan_review { get; set; }
        public QuestionBankProperty maintains_proper_logs_of_the_inventory { get; set; }
        public QuestionBankProperty maintains_relevant_quality_conformance_certificates { get; set; }
        public QuestionBankProperty availability_of_maintenance_staff_round_the_clock { get; set; }
        public QuestionBankProperty escalation_matrix_in_case_of_emergency_repair { get; set; }
        public QuestionBankProperty implementation_of_corrective_actions_by_maintenace_staff { get; set; }
        public QuestionBankProperty maintains_the_documented_operational_maintenance { get; set; }
        public QuestionBankProperty operators_properly_trained_in_handling_equipments { get; set; }
        public QuestionBankProperty hospital_have_check_list_for_facility_inspection { get; set; }
        public QuestionBankProperty plan_and_budget_for_replacing_the_findings { get; set; }
        public QuestionBankProperty hospital_maintains_inspection_and_calibration { get; set; }
        public QuestionBankProperty inspection_testing_functionality_preventive_breakdown { get; set; }
        public QuestionBankProperty statutory_recommendations_for_fire_equipments { get; set; }
        public QuestionBankProperty personal_file_of_staffs_containing_information { get; set; }
        public QuestionBankProperty hospital_ensures_that_the_staff_record_files { get; set; }
        public QuestionBankProperty confidentiality_and_controlled_personal_access { get; set; }
        public QuestionBankProperty documents_regarding_employee { get; set; }
        public QuestionBankProperty hospital_have_healthcare_policies_for_employees { get; set; }
        public HealthCheckupOfEmployee carries_out_health_check_up_of_employees { get; set; }
        public QuestionBankProperty hospital_have_multi_disciplinary_committee { get; set; }
        public QuestionBankProperty quality_safety_infection_control_pharmacy_therapeutics { get; set; }
        public QuestionBankProperty committee_members_drawn_from_different_categories { get; set; }
        public QuestionBankProperty membership_responsibility_and_periodicity { get; set; }
        public QuestionBankProperty identify_potential_safety_risks_by_members { get; set; }
        public QuestionBankProperty training_to_every_staff_disciplinary_grievance { get; set; }
        public QuestionBankProperty regard_to_disciplinary_and_grievance_handling_system { get; set; }
        public QuestionBankProperty appellate_authority_to_consider_appeals { get; set; }
        public QuestionBankProperty ppellate_authority_holds_higher_authority { get; set; }
        public QuestionBankProperty complaints_grievances_and_clinical_care_delivery { get; set; }
        public QuestionBankProperty follows_readressal_of_complaint_of_mechanism { get; set; }

    }
    public class HealthCheckupOfEmployee
    {
        public long ques_id { get; set; }
        public string ques_text { get; set; }
        public string ques_help_text { get; set; }
        public string ques_stndrd_code { get; set; }
        public string ques_help_ { get; set; }
        public bool? ques_selected_opt { get; set; }

        public string staff_doc_url_1 { get; set; }
        public string staff_doc_url_2 { get; set; }
        public string staff_doc_url_3 { get; set; }
        public bool is_ques_disabled { get; set; }
        public string old_ques_histry_opt { get; set; }


    }

}
