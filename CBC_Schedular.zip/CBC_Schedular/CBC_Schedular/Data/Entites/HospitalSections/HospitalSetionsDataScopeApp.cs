﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CBC_Schedular.Data.Entites.HospitalSections
{
    public class HospitalSetionsDataScopeApp
    {
        public HospitalSetionsDataScopeApp()
        {            
            //this.generalInfo = new SectionGeneralInfoDTO();                
            this.scope_of_service = new SectionScopeOfServiceDTO();
       

        }
    

         public SectionScopeOfServiceDTO scope_of_service { get; set; }
    


    }

    public class CenterSetionsDataScopeApp
    {
        public CenterSetionsDataScopeApp()
        {
            //this.generalInfo = new SectionGeneralInfoDTO();                
            this.scope_of_service = new SectionCenterScopeOfServiceDTO();


        }


        public SectionCenterScopeOfServiceDTO scope_of_service { get; set; }



    }
}
