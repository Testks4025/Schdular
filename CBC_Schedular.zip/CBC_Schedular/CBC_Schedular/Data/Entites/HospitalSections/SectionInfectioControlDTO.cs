﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CBC_Schedular.Data.Entites.HospitalSections
{
   public class SectionInfectioControlDTO
    {

        public SectionInfectioControlDTO()
        {
            this.does_hosp_adheres_hand_hygne_gudeline = new QuestionProperty();
            this.does_hosp_thrpy_equpped_mnitrd_infctn_prcts = new QuestionProperty();
            this.does_hosp_mntns_adqute_invntry_strlsd_glvs_disnfctnt = new QuestionProperty();
            this.does_hosp_docmnt_infection_prvntn_mnitrng = new QuestionProperty();
            this.does_hosp_mantns_sop_hygne_dlution_methdlges = new QuestionProperty();
            this.does_hosp_mntn_trnng_rcrd_clnlness_hygiene_huskpng_polcs = new QuestionProperty();
            this.does_hosp_mntns_rcrd_audits_clenlnss_gnral_hygne_rglr_frqncy = new QuestionProperty();
            this.does_hosp_clning_dsnfctn_sterlztn_prctces_equipmnt_inwards_trtmnt_prcdrue = new QuestionProperty();
            this.does_hosp_plcy_ensure_infctn_prctcs_linen = new QuestionProperty();
            this.does_hosp_plcy_intrumnt_equpmnt_aprprt_mnnr_acrss_orgntn = new QuestionProperty();
        }
        public QuestionProperty does_hosp_adheres_hand_hygne_gudeline { get; set; }
        public QuestionProperty does_hosp_thrpy_equpped_mnitrd_infctn_prcts { get; set; }
        public QuestionProperty does_hosp_mntns_adqute_invntry_strlsd_glvs_disnfctnt { get; set; }
        public QuestionProperty does_hosp_docmnt_infection_prvntn_mnitrng { get; set; }
        public QuestionProperty does_hosp_mantns_sop_hygne_dlution_methdlges { get; set; }
        public QuestionProperty does_hosp_mntn_trnng_rcrd_clnlness_hygiene_huskpng_polcs { get; set; }
        public QuestionProperty does_hosp_mntns_rcrd_audits_clenlnss_gnral_hygne_rglr_frqncy { get; set; }
        public QuestionProperty does_hosp_clning_dsnfctn_sterlztn_prctces_equipmnt_inwards_trtmnt_prcdrue  { get; set; }
        public QuestionProperty does_hosp_plcy_ensure_infctn_prctcs_linen { get; set; }
        public QuestionProperty does_hosp_plcy_intrumnt_equpmnt_aprprt_mnnr_acrss_orgntn { get; set; }
    }

    public class QuestionProperty
    {

        public long ques_id { get; set; }
        public string ques_stndrd_code { get; set; }
        public string ques_text { get; set; }
        public string ques_help_text { get; set; }
        public bool? ques_selected_opt { get; set; }
        public string ques_doc_url { get; set; }
        public bool? old_ques_histry_opt { get; set; }
        public string old_ques_doc_url { get; set; }
    }

  

}
