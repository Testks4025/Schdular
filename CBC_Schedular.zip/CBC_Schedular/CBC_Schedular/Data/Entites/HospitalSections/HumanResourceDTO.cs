﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CBC_Schedular.Data.Entites.HospitalSections
{
    public class HumanResourceDTO
    {

        public HumanResourceDTO()  
       {

            group_list = new List<GroupList>();
            manpower_details = new QuestionProperty();
            doctors_along_with_qualification_and_specialisation = new DoctorDetailsQuestionProperty();
            list_of_all_the_nurses = new StaffDetailsQuestionProperty();
            list_of_paricharika_therapist = new StaffDetailsQuestionProperty();
            list_of_all_the_paramedic_staff = new StaffDetailsQuestionProperty();
            list_of_all_the_administrative_and_support_staff = new StaffDetailsQuestionProperty();
            hospital_maintains_the_adequate_number_and_mix_of_staff = new QuestionProperty();
            staffing_in_the_hospital_matches_the_strategic_operational = new QuestionProperty();
            take_care_of_the_patients_are_professionally_competent = new QuestionProperty();
            personnel_appropriately_trained_qualified_and_experienced = new QuestionProperty();
            personnel_competent_to_perform_the_interventions = new QuestionProperty();
            hospital_have_policy_sop_for_entire_recruitment_process = new QuestionProperty();

        }
        public List<GroupList> group_list { get; set; }

        public QuestionProperty manpower_details { get; set; }
        public DoctorDetailsQuestionProperty doctors_along_with_qualification_and_specialisation { get; set; }
        public StaffDetailsQuestionProperty list_of_all_the_nurses { get; set; }
        public StaffDetailsQuestionProperty list_of_paricharika_therapist { get; set; }
        public StaffDetailsQuestionProperty list_of_all_the_paramedic_staff { get; set; }
        public StaffDetailsQuestionProperty list_of_all_the_administrative_and_support_staff { get; set; }
        public QuestionProperty hospital_maintains_the_adequate_number_and_mix_of_staff { get; set; }
        public QuestionProperty staffing_in_the_hospital_matches_the_strategic_operational { get; set; }
        public QuestionProperty take_care_of_the_patients_are_professionally_competent { get; set; }
        public QuestionProperty personnel_appropriately_trained_qualified_and_experienced { get; set; }
        public QuestionProperty personnel_competent_to_perform_the_interventions { get; set; }
        public QuestionProperty hospital_have_policy_sop_for_entire_recruitment_process { get; set; }



    }
    //public class DoctorDetails
    //{
    //    public DoctorDetails()
    //    {
    //        date_of_join = new DateStruct();
    //    }
    //    public string dooctor_name { get; set; }
    //    public string designation { get; set; }
    //    public string qualification { get; set; }
    //    public string expirience { get; set; }
    //    public string council_of_reg { get; set; }
    //    public string registrataion_no { get; set; }
    //    public string dept_of_working { get; set; }
    //    public DateStruct date_of_join { get; set; }
    //}

    public class StaffDetails
    {
       public  StaffDetails()
        {
            date_of_join = new DateStruct();
        }
         
        public string staff_name { get; set; }
        public string designation { get; set; }
        public string qualification { get; set; }
        public string expirience { get; set; }
        public string council_of_reg { get; set; }
        public string specialization { get; set; }
        public string certific_body { get; set; }
       

        public string registrataion_no { get; set; }
        public string dept_of_working { get; set; }
        public DateStruct date_of_join { get; set; }
        public string type { get; set; }
        public string adhar { get; set; }
        public string pan { get; set; }

    }

    public class DoctorDetailsQuestionProperty:QuestionProperty
    {

      public  DoctorDetailsQuestionProperty()
        {
            doctor_details = new List<StaffDetails>();

        }
        public List<StaffDetails> doctor_details{get;set;}


       
    }

    public class StaffDetailsQuestionProperty : QuestionProperty
    {

        public StaffDetailsQuestionProperty()
        {
            staff_details = new List<StaffDetails>();

        }        
        public List<StaffDetails> staff_details { get; set; }

    }

    public class GroupList
    {
        public string group { get; set; }
        public string number { get; set; }
        public string remark { get; set; }
    }


   

}
