﻿using CBC_Schedular.Data.Entites.HospitalSections;
using System;
using System.Collections.Generic;
using System.Text;

namespace CBC_Schedular.Data.Entites.HospitalSections
{
    public class SectionAdmissionDischargeDTO
    {
        public SectionAdmissionDischargeDTO()
        {
            this.document_structured_clinical_handover_during_shift_change = new QuestionProperty();
            this.patient_is_leaving_hospital_against_medical_advice = new QuestionProperty();
            this.hospital_hand_over_the_discharge_summary_to_the_patient = new QuestionProperty();
            this.hospital_coordinate_between_all_concerned_departments = new QuestionProperty();
            this.discharge_summary_include_the_apparent_cause_of_death = new QuestionProperty();
            this.reassessment_includes_determining_the_response_to_the_treatment = new QuestionProperty();
            this.hospital_reassess_the_patients_at_least_once_a_day = new QuestionProperty();
            this.reassessment_of_patient_before_further_treatment_discharge = new QuestionProperty();
            this.discharge_summary_contains_the_following_relevant_information = new DischargeSummaryContainsRelevantInformation();
            this.incorporate_the_details_of_the_procedures_therapies_interventions = new QuestionProperty();
            this.maintain_the_register_about_patients_condition = new QuestionProperty();
            this.hospital_have_policy_for_the_referral_of_patients = new QuestionProperty();
            this.maintains_the_documentation_of_relevant_clinical_parameters = new QuestionProperty();
            this.initial_assessment_for_inpatients_are_getting_documented_within_hrs = new InitialAsssessment();
            this.are_all_the_admissions_authorized_by_ayush_doctors = new QuestionProperty();
            this.follow_the_standardized_sop_for_initial_assessment_of_patients = new QuestionProperty();
            this.patien_registered_with_unique_identification_number = new QuestionProperty();
            this.policy_for_patients_registration_and_admission = new QuestionProperty();
        }

        public QuestionProperty document_structured_clinical_handover_during_shift_change { get; set; }
        public QuestionProperty patient_is_leaving_hospital_against_medical_advice { get; set; }
        public QuestionProperty hospital_hand_over_the_discharge_summary_to_the_patient { get; set; }
        public QuestionProperty hospital_coordinate_between_all_concerned_departments { get; set; }
        public QuestionProperty discharge_summary_include_the_apparent_cause_of_death { get; set; }
        public QuestionProperty reassessment_includes_determining_the_response_to_the_treatment { get; set; }
        public QuestionProperty hospital_reassess_the_patients_at_least_once_a_day { get; set; }
        public QuestionProperty reassessment_of_patient_before_further_treatment_discharge { get; set; }
        public DischargeSummaryContainsRelevantInformation discharge_summary_contains_the_following_relevant_information { get; set; }
        public QuestionProperty incorporate_the_details_of_the_procedures_therapies_interventions { get; set; }
        public QuestionProperty maintain_the_register_about_patients_condition { get; set; }
        public QuestionProperty hospital_have_policy_for_the_referral_of_patients { get; set; }
        public QuestionProperty maintains_the_documentation_of_relevant_clinical_parameters { get; set; }
        public InitialAsssessment initial_assessment_for_inpatients_are_getting_documented_within_hrs { get; set; }
        public QuestionProperty are_all_the_admissions_authorized_by_ayush_doctors { get; set; }
        public QuestionProperty follow_the_standardized_sop_for_initial_assessment_of_patients { get; set; }
        public QuestionProperty patien_registered_with_unique_identification_number { get; set; }
        public QuestionProperty policy_for_patients_registration_and_admission { get; set; }
    }



    public class SectionAdmissionDischargeQuestionBankDTO
    {
        public SectionAdmissionDischargeQuestionBankDTO()
        {
            this.document_structured_clinical_handover_during_shift_change = new QuestionBankProperty();
            this.patient_is_leaving_hospital_against_medical_advice = new QuestionBankProperty();
            this.hospital_hand_over_the_discharge_summary_to_the_patient = new QuestionBankProperty();
            this.hospital_coordinate_between_all_concerned_departments = new QuestionBankProperty();
            this.discharge_summary_include_the_apparent_cause_of_death = new QuestionBankProperty();
            this.reassessment_includes_determining_the_response_to_the_treatment = new QuestionBankProperty();
            this.hospital_reassess_the_patients_at_least_once_a_day = new QuestionBankProperty();
            this.reassessment_of_patient_before_further_treatment_discharge = new QuestionBankProperty();
            this.discharge_summary_contains_the_following_relevant_information = new DischargeSummaryContainsRelevantInformation();
            this.incorporate_the_details_of_the_procedures_therapies_interventions = new QuestionBankProperty();
            this.maintain_the_register_about_patients_condition = new QuestionBankProperty();
            this.hospital_have_policy_for_the_referral_of_patients = new QuestionBankProperty();
            this.maintains_the_documentation_of_relevant_clinical_parameters = new QuestionBankProperty();
            this.initial_assessment_for_inpatients_are_getting_documented_within_hrs = new QuestionBankProperty();
            this.are_all_the_admissions_authorized_by_ayush_doctors = new QuestionBankProperty();
            this.follow_the_standardized_sop_for_initial_assessment_of_patients = new QuestionBankProperty();
            this.patien_registered_with_unique_identification_number = new QuestionBankProperty();
            this.policy_for_patients_registration_and_admission = new QuestionBankProperty();
        }

        public QuestionBankProperty document_structured_clinical_handover_during_shift_change { get; set; }
        public QuestionBankProperty patient_is_leaving_hospital_against_medical_advice { get; set; }
        public QuestionBankProperty hospital_hand_over_the_discharge_summary_to_the_patient { get; set; }
        public QuestionBankProperty hospital_coordinate_between_all_concerned_departments { get; set; }
        public QuestionBankProperty discharge_summary_include_the_apparent_cause_of_death { get; set; }
        public QuestionBankProperty reassessment_includes_determining_the_response_to_the_treatment { get; set; }
        public QuestionBankProperty hospital_reassess_the_patients_at_least_once_a_day { get; set; }
        public QuestionBankProperty reassessment_of_patient_before_further_treatment_discharge { get; set; }
        public DischargeSummaryContainsRelevantInformation discharge_summary_contains_the_following_relevant_information { get; set; }
        public QuestionBankProperty incorporate_the_details_of_the_procedures_therapies_interventions { get; set; }
        public QuestionBankProperty maintain_the_register_about_patients_condition { get; set; }
        public QuestionBankProperty hospital_have_policy_for_the_referral_of_patients { get; set; }
        public QuestionBankProperty maintains_the_documentation_of_relevant_clinical_parameters { get; set; }
        public QuestionBankProperty initial_assessment_for_inpatients_are_getting_documented_within_hrs { get; set; }
        public QuestionBankProperty are_all_the_admissions_authorized_by_ayush_doctors { get; set; }
        public QuestionBankProperty follow_the_standardized_sop_for_initial_assessment_of_patients { get; set; }
        public QuestionBankProperty patien_registered_with_unique_identification_number { get; set; }
        public QuestionBankProperty policy_for_patients_registration_and_admission { get; set; }
    }

public class DischargeSummaryContainsRelevantInformation
    {
        public long ques_id { get; set; }
        public String ques_stndrd_code { get; set; }
        public String ques_text { get; set; }
        public String ques_help_text { get; set; }

        public String ques_doc_url_1 { get; set; }
        public String ques_doc_url_2 { get; set; }
        public String ques_doc_url_3 { get; set; }
        public bool old_ques_histry_opt { get; set; }
        public String old_ques_doc_url { get; set; }
        public bool ques_selected_opt { get; set; }
        public bool admsn_patname { get; set; }
        public bool admsn_regisnumber { get; set; }
        public bool admsn_datetimeadmsn { get; set; }
        public bool admsn_datetimedis { get; set; }
        public bool admsn_resonofadmsn { get; set; }
        public bool admsn_signifindings { get; set; }
        public bool admsn_investigation { get; set; }
        public bool admsn_diagnosis { get; set; }
        public bool admsn_procedrperformd { get; set; }
        public bool admsn_treatment { get; set; }
        public bool admsn_patientcondtion { get; set; }
        public bool admsn_prescrption { get; set; }
        public bool admsn_urgentcare { get; set; }
    }
}
public class InitialAsssessment : QuestionProperty
{
    
  public String initial_assessment_url_1 { get; set; }
    public String initial_assessment_url_2 { get; set; }
    public String initial_assessment_url_3 { get; set; }
   
}
