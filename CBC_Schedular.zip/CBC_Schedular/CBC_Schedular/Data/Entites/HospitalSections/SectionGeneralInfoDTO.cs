﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CBC_Schedular.Data.Entites.HospitalSections
{
    public class SectionGeneralInfoDTO
    {

        //public SectionGeneralInfoDTO()
        //{
        //    this.splitLocation = new List<SplitLocation>();
        //}

        //public string org_type { get; set; }
        //public string ayush_sys { get; set; }
        //public string org_name { get; set; }
        //public bool pat_stay_overnight { get; set; }
        //public string build_name { get; set; }
        //public string address { get; set; }
        //public string street { get; set; }
        //public string state { get; set; }
        //public string district { get; set; }
        //public string city { get; set; }
        //public string pincode { get; set; }
        //public string nearby_landmark { get; set; }

        //public string org_website { get; set; }
        //public string no_beds { get; set; }
        //public string landline { get; set; }
        //public string spoc_name { get; set; }
        //public string spoc_mob { get; set; }
        //public string spoc_desig { get; set; }
        //public string spoc_email { get; set; }

        //public bool cert_officer_same_as_spoc { get; set; }
        //public string cert_officer_salutation { get; set; }
        //public string cert_officer_name { get; set; }
        //public string cert_officer_no { get; set; }
        //public string cert_officer_desig { get; set; }
        //public string cert_officer_email { get; set; }

        //public bool org_head_same_as_spoc { get; set; }
        //public string org_head_salutation { get; set; }
        //public string org_head_name { get; set; }
        //public string org_head_no { get; set; }
        //public string org_head_desig { get; set; }
        //public string org_head_email { get; set; }

        //public bool does_org_hv_split_loc { get; set; }
        //public long split_loc_nos { get; set; }

        //public List<SplitLocation> splitLocation { get; set; }

        //public string est_date { get; set; }
        //public string is_org_reg { get; set; }
        //public string under_which_org_reg { get; set; }
        //public string mention_name_body_reg { get; set; }
        //public string reg_no { get; set; }
        //public DateTime date_of_reg_cert { get; set; }
        //public DateTime exp_date { get; set; }
        //public string upload_reg { get; set; }
        //public DateTime month_year_setup { get; set; }
        //public string ownership_type { get; set; }
        //public string mention_ownership_type { get; set; }
        //public string schemes_org_already_empanalled { get; set; }
        //public string other_schemes { get; set; }

        public SectionGeneralInfoDTO()
        {
            this.basicCertification = new BasicCertification();
            this.generalInfo = new GeneralInfo();
            this.organizationInformation = new OrganizationInformation();
        }

        public BasicCertification basicCertification { get; set; }
        public GeneralInfo generalInfo { get; set; }
        public OrganizationInformation organizationInformation { get; set; }

    }


    public class BasicCertification
    {
        public string organization_type { get; set; }
        public string ayush_system { get; set; }
    }

    public class GeneralInfo
    {
        public GeneralInfo()
        {
            this.location = new Location();
            this.organizationhead = new Organizationhead();
            this.certificationcoordinator = new Certificationcoordinator();
        }
        
        public string org_name { get; set; }
        public bool? pat_stay_overnight { get; set; }
        public string build_name { get; set; }
        public string address { get; set; }
        public string street { get; set; }
        public string state { get; set; }
        public string district { get; set; }
        public string city { get; set; }
        public string pincode { get; set; }
        public string nearby_landmark { get; set; }

        public string org_website { get; set; }
        public string total_sanctioned_beds { get; set; }
        public string total_operational_beds { get; set; }
        public string no_beds { get; set; }
        public string landline { get; set; }
        public string spoc_name { get; set; }
        public string spoc_mob { get; set; }
        public string spoc_designtion { get; set; }
        public string spoc_email { get; set; }

        public Organizationhead organizationhead { get; set; }
        public Location location { get; set; }

       public Certificationcoordinator certificationcoordinator { get; set; }
    }

    public class Organizationhead
    {
        public bool? org_head_same_as_spoc { get; set; }
        public string spoc_name { get; set; }
        public string salutation { get; set; }
        public string spoc_mob { get; set; }
        public string spoc_desig { get; set; }
        public string spoc_email { get; set; }
    }

    public class Certificationcoordinator
    {
        public string cerco_org_spoc_name { get; set; }
        public string cerco_org_head_desig { get; set; }
        public string cerco_org_head_email { get; set; }
        public string cerco_org_head_no { get; set; }
      
    }
    public class Location
    {
        public Location()
        {
           this.splitLocation = new List<SplitLocation>();
        }
        public string latitude { get; set; }
        public string longitude { get; set; }
        public string location_of_organization { get; set; }
        public bool? does_org_hv_split_loc { get; set; }
        public string split_loc_nos { get; set; }
        public List<SplitLocation> splitLocation { get; set; }
    }


    public class SplitLocation
    {
       // public long id { get; set; }
        public string split_build_name { get; set; }
        public string split_state { get; set; }
        public int? split_district { get; set; }
        public string split_city { get; set; }
        public string split_address { get; set; }
        public string split_pincode { get; set; }
        public string name_spoc_loc { get; set; }
        public string mob_spoc_loc { get; set; }
        public string email_spoc_loc { get; set; }
        public string dist_frm_main_loc { get; set; }

    
    }


    public class OrganizationInformation
    {
        public OrganizationInformation()
        {
            this.organization_is_already_empanelled_with = new EmpanelledForOtherSchemes();
        }
        public string establishment_date_of_org { get; set; }
        public string organization_ownership_type { get; set; }
        public string month_year_setup { get; set; }
        
        public string mention_ownership_type { get; set; }
        public string organization_ownership_type_url { get; set; }
        public string mention_other_scheme_orgztn_linked { get; set; }
        public EmpanelledForOtherSchemes organization_is_already_empanelled_with { get; set; }


    }


    public class EmpanelledForOtherSchemes
    {
        public bool? cghs { get; set; }
        public string cghs_url { get; set; }
        public bool? railways { get; set; }
        public string railways_url { get; set; }
        public bool? ayushmanbharat { get; set; }
        public string ayushmanbharat_url { get; set; }
        public bool? publichealthinsuranceschemes { get; set; }
        public string publichealthinsuranceschemes_url { get; set; }
        public bool? echs { get; set; }
        public string echs_url { get; set; }
        public bool? stategovernmenthealthscheme { get; set; }
        public string stategovernmenthealthscheme_url { get; set; }
        public bool? others { get; set; }
        public string others_url { get; set; }
        public string other_scheme_organization_is_linked { get; set; }// if empanelledforotherschemes == other
        public string mentionothertypeofschemes_url { get; set; }
        public bool? none { get; set; }
    }



    public class SectionGeneralInfoQuesBankDTO
    {
        public QuestionBankProperty type_of_organization { get; set; }
        public QuestionBankProperty ayush_systems_provided_by_the_organization { get; set; }
        public QuestionBankProperty name_of_the_organization { get; set; }
        public QuestionBankProperty do_patients_stay_overnight { get; set; }

        public QuestionBankProperty name_of_the_building { get; set; }
        public QuestionBankProperty address { get; set; }
        public QuestionBankProperty street { get; set; }
        public QuestionBankProperty state { get; set; }

        public QuestionBankProperty district { get; set; }
        public QuestionBankProperty city { get; set; }
        public QuestionBankProperty pin_code { get; set; }
        public QuestionBankProperty nearby_landmark { get; set; }

        public QuestionBankProperty organization_website { get; set; }
        public QuestionBankProperty total_number_of_sanctioned_beds { get; set; }
        public QuestionBankProperty total_number_of_operational_beds { get; set; }
        public QuestionBankProperty landline_number { get; set; }
        public QuestionBankProperty spoc_name { get; set; }
        public QuestionBankProperty spoc_mobile_number { get; set; }
        public QuestionBankProperty spoc_designation { get; set; }
        public QuestionBankProperty spoc_emailid { get; set; }
        public QuestionBankProperty latitude { get; set; }
        public QuestionBankProperty longitude { get; set; }
        public QuestionBankProperty location_of_organization { get; set; }
        public QuestionBankProperty organization_have_a_split_location { get; set; }
        public QuestionBankProperty split_locations_does_the_organization_have { get; set; }
        public QuestionBankProperty date_of_establishment { get; set; }
        public QuestionBankProperty month_and_year_of_clinical_service { get; set; }
        public QuestionBankProperty organization_ownership_type { get; set; }

        public QuestionBankProperty ownership_type { get; set; }
        public QuestionBankProperty organization_is_already_empanelled_with { get; set; }
        public QuestionBankProperty other_scheme_organization_is_linked_with { get; set; }

    }

    public class QuestionBankProperty
    {
        public long ques_id { get; set; }
        public string ques_stndrd_code { get; set; }
        public string ques_text { get; set; }
        public string ques_help_text { get; set; }
    }

}
