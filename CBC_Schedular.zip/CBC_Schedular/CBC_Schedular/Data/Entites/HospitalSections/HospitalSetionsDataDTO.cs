﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CBC_Schedular.Data.Entites.HospitalSections
{
    public class HospitalSetionsDataDTO
    {
        public HospitalSetionsDataDTO()
        {
            this.generalInfo = new SectionGeneralInfoDTO();
            this.infection_control = new SectionInfectioControlDTO();
            this.quality_care = new SectionQualityOfCareDTO();
            this.training = new SectionTrainingDTO();
            this.patient_record = new SectionPatientRecordDTO();
            this.admsn_dischrge = new SectionAdmissionDischargeDTO();
            this.admin_record = new SectionAdminRecordDTO();

            this.scope_of_service = new SectionScopeOfServiceDTO();
            this.human_resource = new HumanResourceDTO();

            this.support_service = new SectionSupportServiceDTO();

            this.statutory_compliance = new SectionStatutaryComplianceDTO();

        }
        public long id { get; set; }
        public long hospital_id { get; set; }

        public String application_no { get; set; }
        public int saveType { get; set; } //1 for save as draft and 2 for final submit
        public long stage_id { get; set; }
        public bool isFinalSubmit { get; set; }

        public bool isDaCompleted{ get; set; }
        public bool isDaAccepted { get; set; }
        public String daRemark { get; set; }

        public String org_name { get; set; } // added for asr by vk
        public String ref_id { get; set; } // added for asr by vk

        public String state { get; set; } // added for asr by vk

        public DateTime? asmt_date { get; set; } // added for asr by vk

        public String type { get; set; } // added for asr by vk

        public String asr_name { get; set; } // added for asr by vk
        public String senction_bed { get; set; }
        public String sepeciality { get; set; }

        public bool status { get; set; }
        public int? hosp_progress { get; set; } // rrc

        public SectionGeneralInfoDTO generalInfo { get; set; }

        public SectionInfectioControlDTO infection_control { get; set; }
        public SectionQualityOfCareDTO quality_care { get; set; }
        public SectionTrainingDTO training { get; set; }
        public SectionPatientRecordDTO patient_record { get; set; }

        public SectionAdmissionDischargeDTO admsn_dischrge { get; set; }

        public SectionAdminRecordDTO admin_record { get; set; }


        public SectionScopeOfServiceDTO scope_of_service { get; set; }

        public HumanResourceDTO human_resource { get; set; }

        public SectionSupportServiceDTO support_service { get; set; }


        public SectionStatutaryComplianceDTO statutory_compliance { get; set; }

    }
}
