﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CBC_Schedular.Data.Entites.HospitalSections
{
   public class SectionPatientRecordDTO
    {

        public SectionPatientRecordDTO()
        {
            cost_of_treatment_at_the_time_of_admission = new QuestionProperty();


            packages_doctor_fees_medicines_investigations = new QuestionProperty();
            maintains_confidentiality_while_treating_with_patient = new QuestionProperty();
            printed_material_or_audio_visual_aids = new QuestionProperty();
            use_of_medication_yoga_naturopathy_interventions = new QuestionProperty();
            ensure_the_patients_privacy_and_dignity = new QuestionProperty();
            ensures_that_the_ayush_therapists_is_of_same_gender = new QuestionProperty();
            patient_go_for_second_opinion_from_outside_hospital = new QuestionProperty();
            access_to_all_relevant_information_to_the_patient = new QuestionProperty();
            ensures_that_patient_has_access_to_clinical_records = new QuestionProperty();
            ayush_doctors_are_properly_trained_sensitised = new QuestionProperty();
            doctors_prescribe_printed_prescriptions = new QuestionProperty();

            prescriptions_adhere_to_national_international_guidelines = new QuestionProperty();
            prescription_include_the_following_relevant_information = new DoctorPrescribePrecaution();
            medication_orders_clear_legible = new QuestionProperty();
            doctors_prescribe_prescriptions_in_capital_letters = new QuestionProperty();
            hospital_ascertain_about_the_drug_allergies = new HospAcertainDrug();
            proceeding_with_photographing_recording = new QuestionProperty();
            diagnostic_and_therapeutic_intervention_procedure = new QuestionProperty();
            hospital_takes_a_prior_written_consent = new QuestionProperty();
            obtain_written_informed_consent_prior_to_procedures = new QuestionProperty();
            family_about_the_decision_regarding_their_care = new QuestionProperty();
            performa_of_the_consent_in_the_language = new PerformanceConsent();
            name_of_ayush_doctor_performing_the_procedure = new QuestionProperty();
            hospital_identified_the_legal_age_giving_consent = new QuestionProperty();
            when_patient_is_incapable_of_giving_consent = new QuestionProperty();
            hospital_maintains_the_patient_medical_records = new QuestionProperty();
            hospital_ensures_medical_records_electronic_systems = new QuestionProperty();
            correct_overwrite_the_entries_in_patient_record = new QuestionProperty();
            complete_accurate_medical_record_of_each_patient = new QuestionProperty();
            every_medical_record_has_a_unique_identifier = new QuestionProperty();
            national_laws_and_regulations_of_respective_state = new QuestionProperty();
            hospital_have_access_control_mechanism = new QuestionProperty();
            hospital_identifies_documents_needed_for_medical_records = new QuestionProperty();
            sample_from_discharged_and_death_cases = new QuestionProperty();
            focuses_on_timeliness_legibility_and_completeness = new QuestionProperty();
            hospital_maintains_uniformity_in_the_personnel = new QuestionProperty();
            hospital_documented_clinician_nurse_pharmacist = new QuestionProperty();
            defines_the_retention_period_for_each_category = new RetentionPeriodDept();
            hospital_destroys_records_after_retention_period = new QuestionProperty();
            maintained_in_the_retention_or_discarding_process = new QuestionProperty();
            hospital_takes_the_approval_of_the_concerned_authority = new QuestionProperty();
        }
        public QuestionProperty     cost_of_treatment_at_the_time_of_admission{get;set;}
      
         
        public QuestionProperty packages_doctor_fees_medicines_investigations {get;set;}
        public QuestionProperty maintains_confidentiality_while_treating_with_patient { get;set;}
        public QuestionProperty printed_material_or_audio_visual_aids { get;set;}
        public QuestionProperty use_of_medication_yoga_naturopathy_interventions { get;set;}
        public QuestionProperty ensure_the_patients_privacy_and_dignity { get;set;}
        public QuestionProperty ensures_that_the_ayush_therapists_is_of_same_gender { get;set;}
        public QuestionProperty patient_go_for_second_opinion_from_outside_hospital { get;set;}
        public QuestionProperty access_to_all_relevant_information_to_the_patient { get;set;}
        public QuestionProperty ensures_that_patient_has_access_to_clinical_records { get;set;}
        public QuestionProperty ayush_doctors_are_properly_trained_sensitised { get;set;}

        public QuestionProperty doctors_prescribe_printed_prescriptions { get;set;}
        public QuestionProperty prescriptions_adhere_to_national_international_guidelines { get;set;}
        public DoctorPrescribePrecaution prescription_include_the_following_relevant_information { get;set;}
        public QuestionProperty medication_orders_clear_legible { get;set;}
        public QuestionProperty doctors_prescribe_prescriptions_in_capital_letters { get;set;}
        public HospAcertainDrug hospital_ascertain_about_the_drug_allergies { get;set;}
        public QuestionProperty proceeding_with_photographing_recording { get;set;}
        public QuestionProperty diagnostic_and_therapeutic_intervention_procedure { get;set;}
        public QuestionProperty hospital_takes_a_prior_written_consent { get;set;}
        public QuestionProperty obtain_written_informed_consent_prior_to_procedures { get;set;}
        public QuestionProperty family_about_the_decision_regarding_their_care { get;set;}
        public PerformanceConsent performa_of_the_consent_in_the_language { get;set;}
        public QuestionProperty name_of_ayush_doctor_performing_the_procedure { get;set;}
        public QuestionProperty hospital_identified_the_legal_age_giving_consent { get;set;}
        public QuestionProperty when_patient_is_incapable_of_giving_consent { get;set;}
        public QuestionProperty hospital_maintains_the_patient_medical_records { get;set;}
        public QuestionProperty hospital_ensures_medical_records_electronic_systems { get;set;}
        public QuestionProperty correct_overwrite_the_entries_in_patient_record { get;set;}
        public QuestionProperty complete_accurate_medical_record_of_each_patient { get;set;}
        public QuestionProperty every_medical_record_has_a_unique_identifier { get;set;}
        public QuestionProperty national_laws_and_regulations_of_respective_state { get;set;}
        public QuestionProperty hospital_have_access_control_mechanism { get;set;}
        public QuestionProperty hospital_identifies_documents_needed_for_medical_records { get;set;}
        public QuestionProperty sample_from_discharged_and_death_cases { get;set;}
        public QuestionProperty focuses_on_timeliness_legibility_and_completeness { get;set;}
        public QuestionProperty hospital_maintains_uniformity_in_the_personnel { get;set;}
        public QuestionProperty hospital_documented_clinician_nurse_pharmacist { get;set;}
        public RetentionPeriodDept defines_the_retention_period_for_each_category { get;set;}
        public QuestionProperty hospital_destroys_records_after_retention_period { get;set;}
        public QuestionProperty maintained_in_the_retention_or_discarding_process { get;set;}
        public QuestionProperty hospital_takes_the_approval_of_the_concerned_authority { get;set;}






    }
    public class HospAcertainDrug: QuestionProperty
    {
        public string ipd_doc_url { get; set; }
        public string opd_doc_url { get; set; }
    }
    public class RetentionPeriodDept: QuestionProperty
    {
      
        public string out_patiend_dept { get; set; }
        public string in_patiend_dept { get; set; }
        public string medicos_legal_case { get; set; }
    }
    public class DoctorPrescribePrecaution
    {
        public long ques_id { get; set; }
        public string ques_stndrd_code { get; set; }
        public string ques_text { get; set; }
        public string ques_help_text { get; set; }
    //    public bool? ques_selected_opt { get; set; }
        public string ques_doc_url_1 { get; set; }
        public string ques_doc_url_2 { get; set; }
        public string ques_doc_url_3 { get; set; }
        public bool? old_ques_histry_opt { get; set; }
        public string old_ques_doc_url { get; set; }

        
              public bool date_of_prescription { get; set; }
        public bool patient_name { get; set; }
        public bool uhid_number { get; set; }
        public bool name_of_drug { get; set; }
        public bool drug_dose { get; set; }
        public bool admin_of_medi { get; set; }
        public bool name_of_doct { get; set; }
        public bool sign_of_doctor { get; set; }
        public bool registration_no_doctor { get; set; }

    }
    public class PerformanceConsent : QuestionProperty
    {
      public String consent_form_doc_url_1 { get; set; }
        public String consent_form_doc_url_2 { get; set; }
        public String consent_form_doc_url_3 { get; set; }
     
   
}
}
