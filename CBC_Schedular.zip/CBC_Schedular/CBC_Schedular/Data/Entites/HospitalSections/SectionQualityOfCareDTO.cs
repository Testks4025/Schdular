﻿using CBC_Schedular.Data.Entites.CentralHospitalSection;
using System;
using System.Collections.Generic;
using System.Text;

namespace CBC_Schedular.Data.Entites.HospitalSections
{
   public class SectionQualityOfCareDTO
    {

        public SectionQualityOfCareDTO()
        {
            this.non_clinic_services_provided_by_the_organization = new QuestionProperty();
            this.qoc_nonclncl_service = new List<qocNonTechService>();
            this.does_hospital_provide_obstetrical_services = new QuestionProperty();
            this.security_surveillance_system_at_pre_defined_interval = new QuestionProperty();
            this.performs_invasive_procedures_operative_procedures = new QuestionProperty();
            this.follows_the_defined_process_rapid_response = new QuestionProperty();
            this.adequate_security_system_to_prevent_such_issues = new QuestionProperty();
            this.maintains_the_child_abduction_prevention_protocols = new QuestionProperty();
            this.nutritional_growth_and_immunization_assessment = new QuestionProperty();
            this.take_care_of_new_born_and_paediatric_patients = new QuestionProperty();
            this.obstetric_patients_getting_diet_counselling_qualified = new QuestionProperty();
            this.care_of_obstetric_patient_at_regular_interval = new QuestionProperty();
            this.maintains_the_ante_natal_card_for_obstetric_patient_qualified = new QuestionProperty();
            this.hand_over_separate_discharge_summary_note_newborn = new QuestionProperty();
            this.pre_natal_peri_natal_and_post_natal_monitoring = new QuestionProperty();
            this.applicable_for_both_emergency_and_routine_cases = new QuestionProperty();
            this.who_conducts_the_pre_operative_diagnosis = new PreoperativeDiagnostic();
            this.pre_operative_diagnosis_performing_invasive_procedure = new QuestionProperty();
            this.operative_notes_procedure_notes_and_post_operative = new QuestionProperty();
            this.process_for_periodic_review_of_safety_plans = new QuestionProperty();
            this.plans_and_policies_to_provide_a_safe_and_secure = new QuestionProperty();
            this.upper_limit_for_different_services_being_provided = new QuestionProperty();
            this.periodically_inspect_patient_safety_devices = new QuestionProperty();
            this.quality_improvement_and_patient_safety_programme = new QuestionProperty();
            this.provided_for_quality_improvement_and_patient = new QuestionProperty();
            this.manpower_material_consumable_financial_resources = new QuestionProperty();
            this.coordinate_with_quality_improvement_and_patient_safety = new QuestionProperty();
            this.document_quality_improvement_patient_safety_program = new QuestionProperty();
            this.updates_quality_improvement_patient_safety_program = new QuestionProperty();
            this.use_medication_yoga_naturopathy_interventions = new QuestionProperty();
            this.reduce_the_medication_errors_and_adverse_drug_reaction = new QuestionProperty();
            this.medicatio_error_and_adverse_drug_reactions = new QuestionProperty();
            this.mechanism_to_verify_the_adverse_drug_reaction = new QuestionProperty();
            this.mechanism_to_identify_medication_error = new QuestionProperty();
            this.name_dosage_route_and_timing = new QuestionProperty();
            this.preparation_of_the_second_drug = new QuestionProperty();
            this.prepared_in_a_designated_and_well_equipped_place = new QuestionProperty();
            this.administered_only_by_competent_personnel = new QuestionProperty();
            this.salient_steps_key_findings_and_post_procedure_care = new PainAssessment();
            this.protocol_of_screening_examination_of_food_handler = new QuestionProperty();
            this.nursing_care_provided_based_on_clinical_requirements = new QuestionProperty();
            this.standard_nursing_services_practices_relevant_regulations = new QuestionProperty();
            this.patients_monitored_at_least_twice_a_day = new QuestionProperty();
            this.identify_clinically_vulnerable_patients_and_staff = new QuestionProperty();
            this.intensity_character_frequency_location_duration = new QuestionProperty();
            this.flw_pain_asssment_rssmnt_including_mitigation_technique = new PainAssessment();
        }

        public QuestionProperty non_clinic_services_provided_by_the_organization { get; set; }
        public List<qocNonTechService> qoc_nonclncl_service { get; set; }
        public QuestionProperty does_hospital_provide_obstetrical_services { get; set; }
        public QuestionProperty security_surveillance_system_at_pre_defined_interval { get; set; }
        public QuestionProperty performs_invasive_procedures_operative_procedures { get; set; }
        public QuestionProperty follows_the_defined_process_rapid_response { get; set; }
        public QuestionProperty adequate_security_system_to_prevent_such_issues { get; set; }
        public QuestionProperty maintains_the_child_abduction_prevention_protocols { get; set; }
        public QuestionProperty nutritional_growth_and_immunization_assessment { get; set; }
        public QuestionProperty take_care_of_new_born_and_paediatric_patients { get; set; }
        public QuestionProperty obstetric_patients_getting_diet_counselling_qualified { get; set; }
        public QuestionProperty care_of_obstetric_patient_at_regular_interval { get; set; }
        public QuestionProperty maintains_the_ante_natal_card_for_obstetric_patient_qualified { get; set; }
        public QuestionProperty hand_over_separate_discharge_summary_note_newborn { get; set; }
        public QuestionProperty pre_natal_peri_natal_and_post_natal_monitoring { get; set; }
        public QuestionProperty applicable_for_both_emergency_and_routine_cases { get; set; }
        public PreoperativeDiagnostic who_conducts_the_pre_operative_diagnosis { get; set; }
        public QuestionProperty pre_operative_diagnosis_performing_invasive_procedure { get; set; }
        public QuestionProperty operative_notes_procedure_notes_and_post_operative { get; set; }
        public QuestionProperty process_for_periodic_review_of_safety_plans { get; set; }
        public QuestionProperty plans_and_policies_to_provide_a_safe_and_secure { get; set; }
        public QuestionProperty upper_limit_for_different_services_being_provided { get; set; }
        public QuestionProperty periodically_inspect_patient_safety_devices { get; set; }
        public QuestionProperty quality_improvement_and_patient_safety_programme { get; set; }
        public QuestionProperty provided_for_quality_improvement_and_patient { get; set; }
        public QuestionProperty manpower_material_consumable_financial_resources { get; set; }
        public QuestionProperty coordinate_with_quality_improvement_and_patient_safety { get; set; }
        public QuestionProperty document_quality_improvement_patient_safety_program { get; set; }
        public QuestionProperty updates_quality_improvement_patient_safety_program { get; set; }
        public QuestionProperty use_medication_yoga_naturopathy_interventions { get; set; }
        public QuestionProperty reduce_the_medication_errors_and_adverse_drug_reaction { get; set; }
        public QuestionProperty medicatio_error_and_adverse_drug_reactions { get; set; }
        public QuestionProperty mechanism_to_verify_the_adverse_drug_reaction { get; set; }
        public QuestionProperty mechanism_to_identify_medication_error { get; set; }
        public QuestionProperty name_dosage_route_and_timing { get; set; }
        public QuestionProperty preparation_of_the_second_drug { get; set; }
        public QuestionProperty prepared_in_a_designated_and_well_equipped_place { get; set; }
        public QuestionProperty administered_only_by_competent_personnel { get; set; }
        public PainAssessment salient_steps_key_findings_and_post_procedure_care { get; set; }
        public QuestionProperty protocol_of_screening_examination_of_food_handler { get; set; }
        public QuestionProperty nursing_care_provided_based_on_clinical_requirements { get; set; }
        public QuestionProperty standard_nursing_services_practices_relevant_regulations { get; set; }
        public QuestionProperty patients_monitored_at_least_twice_a_day { get; set; }
        public QuestionProperty identify_clinically_vulnerable_patients_and_staff { get; set; }
        public QuestionProperty intensity_character_frequency_location_duration { get; set; }
        public PainAssessment flw_pain_asssment_rssmnt_including_mitigation_technique { get; set; }



    }
    public class PreoperativeDiagnostic : QuestionProperty
    {

        public bool ayush_doctor { get; set; }
        public String ayush_doctor_url { get; set; }
        public bool member_of_team { get; set; }
        public String member_of_team_url { get; set; }
        public bool someoneelse { get; set; }
        public String someoneelse_url { get; set; }


    }
    public class PainAssessment : QuestionProperty
    {
       
        public String record_doc_url_1 { get; set; }
    
        public String record_doc_url_2 { get; set; }
     
        public String record_doc_url_3 { get; set; }


    }
    public class qocNonTechService
    {
        public string service { get; set; }
        public bool inhouse { get; set; }
        public bool outsource { get; set; }
        public bool not_applicable { get; set; }
    }

}
