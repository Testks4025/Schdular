﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CBC_Schedular.Data.Entites.HospitalSections
{
    public class SectionSupportServiceDTO
    {


        public SectionSupportServiceDTO()
        {

            non_clinical_and_administrative_departments_of_the_organization = new NonClinicalServiceList();
            hospital_provide_emergency_services = new QuestionProperty();
            condition_of_patient_in_his_her_admission_discharge_transfer = new QuestionProperty();
            established_procedure_to_inform_police_in_mlc_cases = new QuestionProperty();
            emergency_cases_in_line_with_the_statutory_requirements = new QuestionProperty();
            hospital_have_laboratory_services = new QuestionPropertySupportServc();
            mou_for_out_sourced_laboratory_service = new MouOutsourcedQuestionProperty();
            service_list = new List<LaboratoryService>();
            hospital_list_out_the_outsourced_laboratory_tests = new QuestionPropertySupportServc();
            hospital_hold_a_mou_with_party_for_outsourced_lab_tests = new QuestionPropertySupportServc();
            commensurating_to_the_services_provided_by_the_hospital = new QuestionProperty();
            follow_the_policy_sop_manual_for_the_identification = new QuestionProperty();
            lab_technicians_qualified_to_perform_supervise_and_interpret = new QuestionProperty();
            lab_technisian_list = new StaffDetailsQuestionProperty();
            hospital_defined_turn_around_time_for_all_laboratory_tests = new QuestionProperty();
            hospital_defined_biological_reference_interval_different_tests = new QuestionProperty();
            hospital_defined_the_critical_limits_for_different_tests = new QuestionProperty();
            critical_test_results_communicated_concerned_personnel_documented = new QuestionProperty();
            laboratory_staffs_properly_trained_in_safe_practices = new QuestionProperty();
            hospital_has_imaging_services = new QuestionPropertySupportServc();
            hospital_procure_pc_pndt_act_certificate = new MouOutsourcedQuestionProperty();
            upload_mou_for_out_sourced_imaging_service = new MouOutsourcedQuestionProperty();
            imaging_service_list = new List<ImgdiagnosticService>();
            hospital_hold_a_mou_with_party_for_outsourced_imaging_tests = new QuestionPropertySupportServc();
            hospital_have_the_imaging_services_commensurating = new QuestionProperty();
            hospital_according_to_aerb_pcpndt_guidelines = new ImagesSignasesDiaplay();
            qualified_to_perform_supervise_and_interpret_investigations = new QuestionProperty();
            list_of_all_imaging_technicians = new StaffDetailsQuestionProperty();
            hospital_defined_turn_around_time_for_all_imaging_services = new QuestionProperty();
            the_hospital_defined_the_critical_test_results = new QuestionProperty();
            communicated_to_the_concerned_personnel = new QuestionProperty();
            the_imaging_and_ancillary_staff_properly_trained = new QuestionProperty();
            hospital_have_ambulance_services = new QuestionPropertySupportServc();
            number_of_ambulance = new QuestionPropertySupportServc();
            daily_check_list_of_ambulance = new DailyCheckAmbulance();
            upload_mou_for_out_sourced_ambulance_service = new MouOutsourcedQuestionProperty();
            ambulance_appropriately_equipped_have_basic_life_support = new QuestionProperty();
            concerned_personnel_trained_basic_cardiopulmonary_resuscitation = new QuestionProperty();
            hospital_have_laundry_and_lenin_services = new QuestionPropertySupportServc();
            hospital_have_laundry_and_linen_management = new QuestionProperty();
            hospital_policy_defines_change_of_different_categories_of_linen = new QuestionProperty();
            hospital_has_pharmacy_medical_store_facility = new QuestionProperty();
            pharmacy_licence = new PharmacyLicience();
            pharmacy_service_list = new List<PharmacyService>();
            documented_procedure_to_procure_licensed_medicines = new QuestionProperty();
            control_of_exposure_to_light_humidity_ventilation_preventing = new QuestionProperty();
            hospital_identify_look_alike_and_sound_alike_medicines = new QuestionProperty();
            hospital_has_separate_and_alphabet_wise_storage_system = new QuestionProperty();
            hospital_define_what_constitutes_near_expiry_medication = new QuestionProperty();
            store_near_expired_expired_drugs_with_non_expired_drugs = new QuestionProperty();
            hospital_follow_a_procedure_to_withdraw_near_expiry_drugs = new QuestionProperty();
            hospital_define_the_list_of_emergency_medications = new QuestionProperty();
            the_hospital_stocks_emergency_medicines = new QuestionProperty();
            timely_replenishment_of_emergency_medicines = new QuestionProperty();
            hospital_have_clear_policies_to_be_laid_down_for_dispensing = new QuestionProperty();
            the_hospital_ensures_that_the_High_risk_medications = new QuestionProperty();
            medications_asu_drugs_containing_schedule_e_ingredients = new QuestionProperty();
            hospital_have_a_defined_procedure_to_proceed_with_verbal_orders = new QuestionProperty();
            procedure_specifies_the_personnel_who_can_place = new QuestionProperty();
            hospital_specify_situations_in_which_verbal_orders_can_be_given = new QuestionProperty();
            the_procedure_ensures_the_practice_of_repeat = new QuestionProperty();
            hospital_ensures_that_the_ayush_doctors_countersigns_the_order = new QuestionProperty();
            hosp_assure_qty_outsrc_img_srvc = new QuestionPropertySupportServc();




        }
        public NonClinicalServiceList non_clinical_and_administrative_departments_of_the_organization { get; set; }
        public QuestionProperty hospital_provide_emergency_services { get; set; }
        public QuestionProperty condition_of_patient_in_his_her_admission_discharge_transfer { get; set; }
        public QuestionProperty established_procedure_to_inform_police_in_mlc_cases { get; set; }
        public QuestionProperty emergency_cases_in_line_with_the_statutory_requirements { get; set; }


        public QuestionPropertySupportServc hospital_have_laboratory_services { get; set; }
        public MouOutsourcedQuestionProperty mou_for_out_sourced_laboratory_service { get; set; }
        public List<LaboratoryService> service_list { get; set; }
        public QuestionPropertySupportServc hospital_list_out_the_outsourced_laboratory_tests { get; set; }
        public QuestionPropertySupportServc hospital_hold_a_mou_with_party_for_outsourced_lab_tests { get; set; }
        public QuestionProperty commensurating_to_the_services_provided_by_the_hospital { get; set; }
        public QuestionProperty follow_the_policy_sop_manual_for_the_identification { get; set; }
        public QuestionProperty lab_technicians_qualified_to_perform_supervise_and_interpret { get; set; }
        public StaffDetailsQuestionProperty lab_technisian_list { get; set; }
        public QuestionProperty hospital_defined_turn_around_time_for_all_laboratory_tests { get; set; }
        public QuestionProperty hospital_defined_biological_reference_interval_different_tests { get; set; }
        public QuestionProperty hospital_defined_the_critical_limits_for_different_tests { get; set; }
        public QuestionProperty critical_test_results_communicated_concerned_personnel_documented { get; set; }
        public QuestionProperty laboratory_staffs_properly_trained_in_safe_practices { get; set; }




        public QuestionPropertySupportServc hospital_has_imaging_services { get; set; }
        public MouOutsourcedQuestionProperty hospital_procure_pc_pndt_act_certificate { get; set; }
        public MouOutsourcedQuestionProperty upload_mou_for_out_sourced_imaging_service { get; set; }
        public List<ImgdiagnosticService> imaging_service_list { get; set; }

        public QuestionPropertySupportServc hospital_hold_a_mou_with_party_for_outsourced_imaging_tests { get; set; }
        public QuestionProperty hospital_have_the_imaging_services_commensurating { get; set; }
        public ImagesSignasesDiaplay hospital_according_to_aerb_pcpndt_guidelines { get; set; }
        public QuestionProperty qualified_to_perform_supervise_and_interpret_investigations { get; set; }

        public StaffDetailsQuestionProperty list_of_all_imaging_technicians { get; set; }
        public QuestionProperty hospital_defined_turn_around_time_for_all_imaging_services { get; set; }
        public QuestionProperty the_hospital_defined_the_critical_test_results { get; set; }
        public QuestionProperty communicated_to_the_concerned_personnel { get; set; }
        public QuestionProperty the_imaging_and_ancillary_staff_properly_trained { get; set; }
        public QuestionPropertySupportServc hospital_have_ambulance_services { get; set; }
        public QuestionPropertySupportServc number_of_ambulance { get; set; }
        public DailyCheckAmbulance daily_check_list_of_ambulance { get; set; }

        public MouOutsourcedQuestionProperty upload_mou_for_out_sourced_ambulance_service { get; set; }
        public QuestionProperty ambulance_appropriately_equipped_have_basic_life_support { get; set; }
        public QuestionProperty concerned_personnel_trained_basic_cardiopulmonary_resuscitation { get; set; }
        public QuestionPropertySupportServc hospital_have_laundry_and_lenin_services { get; set; }

        public QuestionProperty hospital_have_laundry_and_linen_management { get; set; }
        public QuestionProperty hospital_policy_defines_change_of_different_categories_of_linen { get; set; }
        public QuestionProperty hospital_has_pharmacy_medical_store_facility { get; set; }
        public PharmacyLicience pharmacy_licence { get; set; }

        public List<PharmacyService> pharmacy_service_list { get; set; }


        public QuestionProperty documented_procedure_to_procure_licensed_medicines { get; set; }
        public QuestionProperty control_of_exposure_to_light_humidity_ventilation_preventing { get; set; }
        public QuestionProperty hospital_identify_look_alike_and_sound_alike_medicines { get; set; }
        public QuestionProperty hospital_has_separate_and_alphabet_wise_storage_system { get; set; }
        public QuestionProperty hospital_define_what_constitutes_near_expiry_medication { get; set; }
        public QuestionProperty store_near_expired_expired_drugs_with_non_expired_drugs { get; set; }
        public QuestionProperty hospital_follow_a_procedure_to_withdraw_near_expiry_drugs { get; set; }
        public QuestionProperty hospital_define_the_list_of_emergency_medications { get; set; }
        public QuestionProperty the_hospital_stocks_emergency_medicines { get; set; }
        public QuestionProperty timely_replenishment_of_emergency_medicines { get; set; }
        public QuestionProperty hospital_have_clear_policies_to_be_laid_down_for_dispensing { get; set; }
        //need to update   the_hospital_ensures_that_the_High-risk_medications
        public QuestionProperty the_hospital_ensures_that_the_High_risk_medications { get; set; }
        public QuestionProperty medications_asu_drugs_containing_schedule_e_ingredients { get; set; }
        public QuestionProperty hospital_have_a_defined_procedure_to_proceed_with_verbal_orders { get; set; }
        public QuestionProperty procedure_specifies_the_personnel_who_can_place { get; set; }
        public QuestionProperty hospital_specify_situations_in_which_verbal_orders_can_be_given { get; set; }
        public QuestionProperty the_procedure_ensures_the_practice_of_repeat { get; set; }
        public QuestionProperty hospital_ensures_that_the_ayush_doctors_countersigns_the_order { get; set; }
        public QuestionProperty hospital_declaration { get; set; }
        public QuestionPropertySupportServc hosp_assure_qty_outsrc_img_srvc { get; set; }

        



    }
    public class MouOutsourcedQuestionProperty : QuestionProperty
    {


        public String agency_name { get; set; }
        public DateStruct valid_from { get; set; }
        public DateStruct valid_till { get; set; }
        public Boolean? available { get; set; }


    }
    public class PharmacyLicience : QuestionProperty
    {


        public bool valid { get; set; }
        public string pharmacy_lic_url { get; set; }
        public DateStruct valid_from { get; set; }
        public DateStruct valid_till { get; set; }
        public string licience_no { get; set; }
        public string status { get; set; }
        public string appln_no_renewal_appln { get; set; }


    }
    public class ServiceList
    {
        public string service { get; set; }
        public bool inhouse { get; set; }
        public bool outsource { get; set; }
        public bool serves_other_org { get; set; }
    }
    public class NonClinicalServiceList : QuestionProperty
    {
        public NonClinicalServiceList()
        {
            this.non_clinicalsrvc = new List<NonClinicalService>();
        }
        public List<NonClinicalService> non_clinicalsrvc { get; set; }

    }
    public class NonClinicalService
    {
        public string service { get; set; }
        public bool inhouse { get; set; }
        public bool outsource { get; set; }
        public bool not_applicable { get; set; }
    }

    public class QuestionPropertySupportServc
    {
        public long ques_id { get; set; }
        public string ques_stndrd_code { get; set; }
        public string ques_text { get; set; }
        public string ques_help_text { get; set; }
        public string ques_selected_opt { get; set; }

        public string ques_text_value { get; set; }
        public string ques_doc_url { get; set; }
        public bool? old_ques_histry_opt { get; set; }
        public string old_ques_doc_url { get; set; }
    }

    public class DailyCheckAmbulance : QuestionProperty
    {
        public string document_url { get; set; }

    }

    public class DateStruct
    {
        public int year { get; set; }
        public int month { get; set; }
        public int day { get; set; }

        //public static implicit operator DateStruct(CBC_Schedular.Core.Repository.DateStruct v)
        //{
        //    throw new NotImplementedException();
        //}
    }

    public class ImgdiagnosticService : ServiceList
    {
        public ImgdiagnosticService()
        {
            dishnosticservc_mou_lic_details = new MouOutsourcedSlctedSrvcs();
            dishnosticservc_aerb_lic_details = new AerbOutsourcedSlctedSrvcs();

        }
        public MouOutsourcedSlctedSrvcs dishnosticservc_mou_lic_details { get; set; }
        public AerbOutsourcedSlctedSrvcs dishnosticservc_aerb_lic_details { get; set; }


    }

    public class LaboratoryService : ServiceList
    {
        public LaboratoryService()
        {
            labservc_mou_lic_details = new MouOutsourcedSlctedSrvcs();
        }
        public MouOutsourcedSlctedSrvcs labservc_mou_lic_details { get; set; }

    }
    public class PharmacyService : ServiceList
    {
        public PharmacyService()
        {
            pharmacyservc_mou_lic_details = new MouOutsourcedSlctedSrvcs();
        }
        public MouOutsourcedSlctedSrvcs pharmacyservc_mou_lic_details { get; set; }

    }



    public class MouOutsourcedSlctedSrvcs
    {
        public String agent_name { get; set; }
        public Boolean? available { get; set; }
        public DateStruct valid_from { get; set; }
        public DateStruct valid_till { get; set; }
        public String license_url { get; set; }

    }
    public class AerbOutsourcedSlctedSrvcs
    {


        public String agent_name { get; set; }
        public String status { get; set; }
        public String application_no { get; set; }
        public String lic_no { get; set; }
        public DateStruct valid_from { get; set; }
        public DateStruct valid_till { get; set; }
        public String license_url { get; set; }
    }
    public class ImagesSignasesDiaplay:QuestionProperty
        {
        public String doc_url_1 { get; set; }
        public String doc_url_2 { get; set; }
        public String doc_url_3 { get; set; }
       
    }

}
