﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CBC_Schedular.Data.Entites.HospitalSections
{
   public class SectionScopeOfServiceDTO
    {
        public SectionScopeOfServiceDTO()
        {
            this.scopeOfAyurvedaCertification = new ScopeOfAyurvedaCertification();
            this.sosHomeopathyCert = new SosHomeopathyCert();
            this.opdSosProvidedDepartments = new SOSprovidedDepartments();
            this.ipdSosProvidedDepartments = new SOSprovidedDepartments();
            this.providePatientvisitedOrganization = new ProvidePatientvisitedOrganization();
            this.provideInpatientCareUnitOrWard = new ProvideInpatientCareUnitOrWard();
            this.provideAmbulatoryPatientsservice = new ProvideAmbulatoryPatientsservice();
            this.scopeOfNaturopathyCertification = new ScopeOfNaturopathyCertification();
            this.scopeOfYogaCertification = new ScopeOfYogaCertification();
            this.scopeOfUnaniCertification = new ScopeOfUnaniCertification();
        }

        public bool isAyurveda { get; set; }
        public bool isYoga { get; set; }
        public bool isNaturopathy { get; set; }
        public bool isUnani { get; set; }
        public bool isSiddha { get; set; }
        public bool isHomeopathy { get; set; }
        

        public ScopeOfAyurvedaCertification scopeOfAyurvedaCertification { get; set; }

        public ScopeOfNaturopathyCertification scopeOfNaturopathyCertification { get; set; }
        public ScopeOfYogaCertification scopeOfYogaCertification { get; set; }
        public ScopeOfUnaniCertification scopeOfUnaniCertification { get; set; }
               

        public List<ClinicalServicesOptions> socSiddhaCert { get; set; }

        public SosHomeopathyCert sosHomeopathyCert { get; set; }

        public SOSprovidedDepartments opdSosProvidedDepartments { get; set; }
        public SOSprovidedDepartments ipdSosProvidedDepartments { get; set; }

        public ProvidePatientvisitedOrganization providePatientvisitedOrganization { get; set; }

        public ProvideInpatientCareUnitOrWard provideInpatientCareUnitOrWard { get; set; }

        public ProvideAmbulatoryPatientsservice provideAmbulatoryPatientsservice { get; set; }

    }



    public class ClinicalServicesOptions
    {               
        public string service_name { get; set; }
        public string option { get; set; }
        public string remark { get; set; }
    }
   
    public class ScopeOfNaturopathyCertification
    {
        public ScopeOfNaturopathyCertification()
        {
            this.other_sos_service = new List<ClinicalServicesOptions>();
            this.socNaturopathyCert = new List<ClinicalServicesOptions>();
        }
        public List<ClinicalServicesOptions> socNaturopathyCert { get; set; }
        public List<ClinicalServicesOptions> other_sos_service { get; set; }
    }

    public class ScopeOfYogaCertification
    {
        public ScopeOfYogaCertification()
        {
            this.socYogaCert = new List<ClinicalServicesOptions>();
            this.other_sos_service = new List<ClinicalServicesOptions>();
        }
        public List<ClinicalServicesOptions> socYogaCert { get; set; }
        public List<ClinicalServicesOptions> other_sos_service { get; set; }
    }

    public class ScopeOfUnaniCertification
    {
        public ScopeOfUnaniCertification()
        {
            this.socUnaniCert = new List<ClinicalServicesOptions>();
            this.other_sos_service = new List<ClinicalServicesOptions>();
        }
        public List<ClinicalServicesOptions> socUnaniCert { get; set; }
        public List<ClinicalServicesOptions> other_sos_service { get; set; }
    }

    public class ScopeOfAyurvedaCertification
    {
        public ScopeOfAyurvedaCertification()
        {
              this.socAyurvedaCert = new List<ClinicalServicesOptions>();
            this.other_sos_service = new List<ClinicalServicesOptions>();
        }
        public List<ClinicalServicesOptions> socAyurvedaCert { get; set; }
        public List<ClinicalServicesOptions> other_sos_service { get; set; }
       
    }

    #region ScopeOfAyurvedaCertification Child
    //public class AyurvedaClinicalServices
    //{
    //    public AyurvedaClinicalServices()
    //    {
    //       // this.panchakarma_therapies = new PanchakarmaTherapies();
    //        this.other_sos_service = new List<ClinicalServicesOptions>();
    //    }
    //    public List<ClinicalServicesOptions> ayurveda_clinical_services { get; set; }
    //  //  public PanchakarmaTherapies panchakarma_therapies { get; set; }
    //    public List<ClinicalServicesOptions> other_sos_service { get; set; }

    //}

    //public class PanchakarmaTherapies
    //{
    //    public PanchakarmaTherapies()
    //    {
    //        this.poorvakarma = new List<ClinicalServicesOptions>();
    //        this.pradhanakarma = new List<ClinicalServicesOptions>();
    //        this.paschatkarma = new List<ClinicalServicesOptions>();
           
    //    }
    //    public List<ClinicalServicesOptions> poorvakarma { get; set; }
    //    public List<ClinicalServicesOptions> pradhanakarma { get; set; }
    //    public List<ClinicalServicesOptions> paschatkarma { get; set; }
        
    //}  

    #endregion  ScopeOfAyurvedaCertification Child
   
   

    public class SosHomeopathyCert
    {
        public List<ClinicalServicesOptions> socHomeoCert { get; set; }
        public List<ClinicalServicesOptions> sochomeoSpecialCert { get; set; }
        public List<ClinicalServicesOptions> other_sos_service { get; set; }
    }


    public class SOSprovidedDepartments
    {
        public string dept_url { get; set; }
    }

    public class ProvidePatientvisitedOrganization
    {
        public ProvidePatientvisitedOrganization()
        {
            this.opdData = new SosIPDData();
            this.ipdData = new SosIPDData();
        }
        public SosIPDData opdData { get; set; }
        public SosIPDData ipdData { get; set; }
    }

    public class SosIPDData
    {
        public string year { get; set; }
        public string no_of_patients { get; set; }
        public string year1 { get; set; }
        public string no_of_patients1 { get; set; }
    }

    public class ProvideInpatientCareUnitOrWard
    {
        public ProvideInpatientCareUnitOrWard()
        {
            this.inpatientCareUnitOrWard = new List<InpatientCareUnitOrWardData>();
        }
        public string floor_plan_urll { get; set; }
        public List<InpatientCareUnitOrWardData> inpatientCareUnitOrWard { get; set; }
    }

    public class ProvideAmbulatoryPatientsservice
    {
        public ProvideAmbulatoryPatientsservice()
        {
            this.ambulatoryPatientsservices = new List<AmbulatoryPatientsserviceData>();
        }
        public List<AmbulatoryPatientsserviceData> ambulatoryPatientsservices { get; set; }
    }


    public class InpatientCareUnitOrWardData
    {
        public string unit_or_ward_name { get; set; }
        public string number_of_beds { get; set; }
        public string type_of_care_given { get; set; }
        public string floor_or_location { get; set; }
        public string floor_plan_url { get; set; }
    }

    public class AmbulatoryPatientsserviceData
    {
        public string ambulatory_or_patient_name  { get; set; }
        public string average_visits_per_month { get; set; }
        public string type_of_service { get; set; }       
    }




    public class SectionScopeOfServiceQuestionBankDTO
    {
        public SectionScopeOfServiceQuestionBankDTO()
        {
            this.scope_services_provided_by_the_organization = new QuestionBankProperty();
            this.sos_opd = new QuestionBankProperty();
            this.sos_ipd = new QuestionBankProperty();
            this.number_of_patients_for_last_two_years_visited_opd_and_ipd = new QuestionBankProperty();
            this.opd_data = new QuestionBankProperty();
            this.ipd_data = new QuestionBankProperty();
            this.list_of_Inpatient_care_units_or_wards_number_type_of_care = new QuestionBankProperty();
            this.list_of_ambulatory_or_out_patients_units_with_numberof_visits = new QuestionBankProperty();
            this.lst_sop_per_dept = new QuestionBankProperty();
        }

        public QuestionBankProperty scope_services_provided_by_the_organization { get; set; }
        public QuestionBankProperty sos_opd { get; set; }
        public QuestionBankProperty sos_ipd { get; set; }
        public QuestionBankProperty number_of_patients_for_last_two_years_visited_opd_and_ipd { get; set; }
        public QuestionBankProperty opd_data { get; set; }
        public QuestionBankProperty ipd_data { get; set; }
        public QuestionBankProperty list_of_Inpatient_care_units_or_wards_number_type_of_care { get; set; }
        public QuestionBankProperty list_of_ambulatory_or_out_patients_units_with_numberof_visits { get; set; }

        public QuestionBankProperty lst_sop_per_dept { get; set; }
    }






    public static class AyushOrganization
    {       
        public static string Ayurveda = "Ayurveda";
        public static string Yoga = "Yoga";
        public static string Naturopathy = "Naturopathy";
        public static string Unani = "Unani";
        public static string Siddha = "Siddha";
        public static string Homeopathy = "Homeopathy";
        public static string SowaRigpa = "Sowa-Rigpa";
    }


   


}
