﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CBC_Schedular.Data.Entites.HospitalSections
{
    public class SectionTrainingDTO
    {

        public SectionTrainingDTO()
        {
            mock_drill_tests_all_the_components_of_the_plan = new QuestionProperty();
            fire_and_important_non_fire_emergencies = new QuestionProperty();
            doctors_rehabilitation_staff_and_nursing = new QuestionProperty();

            spills_mngment_mdiction_errors_fire_non_fire_emrgncies = new QuestionProperty();
            prevention_and_control_practices_at_predefined_intervals = new QuestionProperty();
            protective_eqpment_prevent_occupational_health_hazards = new QuestionProperty();
            change_injob_responsibilities_equipment_technology = new QuestionProperty();
            hospital_provides_training_for_soft_skills = new QuestionProperty();
            induction_training_of_staff_includes_orientation = new QuestionProperty();
            training_for_the_new_staff_members_within_days = new QuestionProperty();
            inductin_trn_staff_orientation = new InductionTrainingStaff();


        }
        public QuestionProperty mock_drill_tests_all_the_components_of_the_plan { get; set; }
        public QuestionProperty fire_and_important_non_fire_emergencies { get; set; }

        public InductionTrainingStaff inductin_trn_staff_orientation { get; set; }
        public QuestionProperty doctors_rehabilitation_staff_and_nursing { get; set; }
        //  doctors_rehabilitation_staff_and_nursing)
        public QuestionProperty spills_mngment_mdiction_errors_fire_non_fire_emrgncies { get; set; }
        public QuestionProperty prevention_and_control_practices_at_predefined_intervals { get; set; }
        public QuestionProperty protective_eqpment_prevent_occupational_health_hazards { get; set; }
        public QuestionProperty change_injob_responsibilities_equipment_technology { get; set; }
        public QuestionProperty hospital_provides_training_for_soft_skills { get; set; }
        public QuestionProperty induction_training_of_staff_includes_orientation { get; set; }
        public QuestionProperty training_for_the_new_staff_members_within_days { get; set; }

    }
    public class InductionTrainingStaff
    {
        public Boolean vision_mission { get; set; }
        public String vision_mission_doc { get; set; }
       
        public Boolean employ_right { get; set; }
        public String employ_right_doc { get; set; }
        
        public Boolean patient_right { get; set; }
        public String patient_right_doc { get; set; }
       
        public Boolean servc_standard { get; set; }
        public String servc_standard_doc { get; set; }
        public Boolean none { get; set; }



    }
}
