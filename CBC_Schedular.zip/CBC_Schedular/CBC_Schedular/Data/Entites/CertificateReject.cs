﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CBC_Schedular.Data.Entites
{
    public class CertificateReject
    {
        public long institute_id { get; set; }
        public String remark { get; set; }
    }
}
