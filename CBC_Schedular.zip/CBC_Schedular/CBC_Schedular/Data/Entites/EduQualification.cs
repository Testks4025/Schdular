﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CBC_Schedular.Data.Entites
{
    public class EduQualificationDTO
    {
        public long id { get; set; }        
        public string qualification { get; set; }
        public string details { get; set; }
    }    

}
