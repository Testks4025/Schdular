﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CBC_Schedular.Data.Entites
{
    public class AdminDashboardData
    {
        public AdminDashboardData()
        {
            this.Admindashboard_data = new List<AdminDashboardDto>();
        }
        public List<AdminDashboardDto> Admindashboard_data { get; set; }

    }
    public class AdminDashboardDto
    {
        public AdminDashboardDto()
        {
            this.application_status = new barChartData();
            this.desktop_assment_status = new barChartData();
            this.onsite_assment_status = new barChartData();
            this.certificate_commiittee = new barChartData();
        }
        public int institute_application_submitted_count { get; set; }

        public int institute_application_in_progress_count { get; set; }

        public int institute_part_a_count { get; set; }
        public int institute_da_count { get; set; }
        public int institute_registration_rej_count { get; set; }
        public int institute_registration_accepted_count { get; set; }
        public int institute_registration_count { get; set; }
        public int institute_field_assessment_count { get; set; }
        public int certified_institute_count { get; set; }
        //public int certified_hosp_count { get; set; }
        //public int centre_hosp_application_count { get; set; }
        //public int centre_certified_hosp_count { get; set; }

        public barChartData application_status { get; set; }
        public barChartData desktop_assment_status { get; set; }
        public barChartData onsite_assment_status { get; set; }
        public barChartData certificate_commiittee { get; set; }

        public int pendency_count { get; set; }
        public string Name { get; set; }

    }

    public class CbcAgencyDashboardData
    {
        public CbcAgencyDashboardData()
        {
            this.dashboard_data = new List<DashboardDto>();
        }
        public List<DashboardDto> dashboard_data { get; set; }

    }

    public class DashboardDto
    {
        public DashboardDto()
        {

        }

        public int role_id { get; set; }
        public String user_name { get; set; }
        public int institute_application_submitted_count { get; set; }

        public int institute_application_in_progress_count { get; set; }

        public int institute_part_a_count { get; set; }
        public int institute_da_count { get; set; }
        public int institute_registration_rej_count { get; set; }
        public int institute_registration_count { get; set; }
        public int institute_registration_accepted_count { get; set; }
        public int institute_field_assessment_count { get; set; }
        public int certified_institute_count { get; set; }

        public int pendency_count { get; set; }
    }

    public class barChartData

       
    {

        public barChartData()
        {
            this.organisation = new List<int>();
            this.hospital = new List<int>();
            this.center = new List<int>();
        }
        public List<int> organisation { get; set; }
        public List<int> hospital { get; set; }
        public List<int> center { get; set; }

        public int total { get; set; }
    }
}
