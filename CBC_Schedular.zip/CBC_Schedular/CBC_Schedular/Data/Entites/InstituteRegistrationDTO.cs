﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CBC_Schedular.Data.Entites
{
    public class InstituteRegistrationDTO
    {
        public long id { get; set; }
        public long userid { get; set; }
        public string org_name { get; set; }
        public string nodal_officer { get; set; }
       
        public string email { get; set; }
        public string mobile { get; set; }
      
        public DateTime creationdate { get; set; }
        public DateTime? updatedate { get; set; }
        public bool isactive { get; set; }

        public long? department_id { get; set; }
        public long? ministry_id { get; set; }
        public String state_central { get; set; }

        public String state { get; set; }
        public int? district { get; set; }
        public String city { get; set; }
        public String designation { get; set; }

        public String institute_type { get; set; }
        public bool is_cbc_institute { get; set; }

        
        public BasicCertificationDTO BasicCertificationDTO { get; set; }        

    }
}
