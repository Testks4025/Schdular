﻿using System;
using System.Collections.Generic;
using System.Text;
using CBC_Schedular.Data.Entites.HospitalSections;

namespace CBC_Schedular.Data.Entites
{
    public class AssesorDTO
    {
        public AssesorDTO()
        {            
        }
        public long id { get; set; }
        public long? userid { get; set; }
        public string asrname { get; set; }
        public string email { get; set; }
        public string mobileno1 { get; set; }
        public string mobileno2 { get; set; }
        public DateTime? dob { get; set; }
        public Int32? dob_day { get; set; }
        public Int32? dob_month { get; set; }
        public Int32? dob_year { get; set; }
        public string aadharnumber { get; set; }
        public long? qualificationid { get; set; }
        public string otherqualification { get; set; }
        public string specialitiesids { get; set; } // coma separated ids
        public decimal? totalworkexp { get; set; }
        public string currentorg { get; set; }
        public string designation { get; set; }
        public string orgaddress { get; set; }
        public long? stateid { get; set; }   
        public string state_code { get; set; }
        public long? districtid { get; set; }
        public string statename { get; set; }
        public string districtname { get; set; }
        public string city { get; set; }
        public string residentialaddress { get; set; }
        public string pin { get; set; }
        public decimal? latitude { get; set; }
        public decimal? longitude { get; set; }

        public string bankname { get; set; }
        public string bankbranchname { get; set; }
        public string bankaccountnumber { get; set; }
        public string accountholdername { get; set; }
        public string ifsc_code { get; set; }
        public string pannumber { get; set; }

        public string photourl { get; set; }
        public string cv_url { get; set; }
        public string cheque_url { get; set; }
        public string domain { get; set; }
       
        public long? createdby { get; set; }
        public DateTime? createdon { get; set; }
        public bool? isactive { get; set; }
        //public Int32? capacity { get; set; } 
        //public string capacityname
        //{
        //    get
        //    {
        //        string ret = "";

        //        if (capacity != null)
        //        {
        //            if (capacity == 1) ret = "Principal Assessor";
        //            if (capacity == 2) ret = "Assessor";
        //        }

        //        return ret;
        //    }
        //}

        public string specialityname { get; set; }

        public string qualification { get; set; }


        public bool is_profile_submitted { get; set; }

        public bool? isdeleted { get; set; } // rrc
        //public List<WorkExperienceDTO> workExperience { get; set; }

        //public string address { get; set; }
        //public string adhar_number { get; set; }
        //public string pan_no { get; set; }
        //public string native_location { get; set; }
        //public string current_location { get; set; }
        //public string Declaration { get; set; }

        //public string profile_image { get; set; }
        //public DateTime created_date { get; set; }
        //public DateTime updated_date { get; set; }

    }

    public class AsrDateStruct
    {
        public int? year { get; set; }
        public int? month { get; set; }
        public int? day { get; set; }
    }

    public class AsrFilter
    {
        public int? limit { get; set; }
        public int? offset { get; set; }
        public string sort { get; set; }
        public string searchtext { get; set; }
        public long? stateid { get; set; }
        public long? districtid { get; set; }
        public string city { get; set; }
        public Int32? capacity { get; set; } // rrc Principal Assessor (1), Assessor (2) 
        public bool? profile { get; set; }
        //public SearchDatee searchdate { get; set; }
    }

    public class SearchDatee
    {
        public Data.Entites.HospitalSections.DateStruct from_date { get; set; }
        public Data.Entites.HospitalSections.DateStruct to_date { get; set; }
    }

    public class AsrSearchResponse
    {
        public long total { get; set; }
        public int rowCount { get; set; }
        public int current { get; set; }
        public List<AssesorDTO> rows { get; set; }
    }    

    //public class WorkExperienceDTO
    //{
    //    public string experience_years { get; set; }
    //    public string last_org_work { get; set; }
    //}

}
