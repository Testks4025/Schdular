﻿using CBC_Schedular.Data.Entites.FormBuilder;
using System;
using System.Collections.Generic;
using System.Text;

namespace CBC_Schedular.Data.Entites.OnsiteAssessment
{
   public class InstituteDataForOnsiteAssessmentDTO
    {
        public InstituteDataForOnsiteAssessmentDTO()
        {
            this.section = new List<InstituteSectionOnsite>();
        }
        public long institute_id { get; set; }
        public String institute_name { get; set; }
        public String mobile_no { get; set; }
        public long stage_id { get; set; }
        public long assessment_id { get; set; }

      public List<InstituteSectionOnsite> section { get; set; }
}

    public class saveInstituteDataForOnsiteAssessmentDTO
    {
        public saveInstituteDataForOnsiteAssessmentDTO()
        {
            this.section =new InstituteSectionOnsite();
        }
        public long institute_id { get; set; }
        public long assessment_id { get; set; }

        public InstituteSectionOnsite section { get; set; }
    }

    public class InstituteSectionOnsite
    {
        public long id { get; set; }
        public string section_name { get; set; }
        public int section_order { get; set; }
        public bool is_sync { get; set; }
        public int status { get; set; }
        public List<InstituteQuestionOnsite> Questions { get; set; }

    }
    public class InstituteQuestionOnsite
    {
        public InstituteQuestionOnsite()
        {
            this.imageList = new List<ImageData>();
        }
        public long ques_no { get; set; }
        public long ques_id { get; set; }
        public String ques_text { get; set; }
        public String ques_source_id { get; set; }
        public long ques_type_id { get; set; }
        public String ques_type { get; set; }
        public String ques_ans { get; set; }
        public String ques_image_url { get; set; }
        public String remark { get; set; }
        public String oa_image_url { get; set; }
        public List<Option> option { get; set; }

        public List<ImageData> imageList { get; set; }
        public string ques_serial_tag_no { get; set; }


    }
    public class ImageData
    {
       public String localPath { get; set; }
        public String serverPath{ get; set; }
        public bool? isSynced{ get; set; }
      
  
    }

}
