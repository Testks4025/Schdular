﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CBC_Schedular.Data.Entites.OnsiteAssessment
{
     public class AllocatedInstituteListOnsite
    {

       public long institute_id { get; set; }
        public String institute_name { get; set; }
      public String agency_name { get; set; }
        public long stage_id { get; set; }
        public String stage { get; set; }
        public long assessor_id { get; set; }
        public long? principle_assr_id { get; set; }
        public long? secondary_assr_id { get; set; }
        public String assessor_name { get; set; }
        public long assessment_id { get; set; }
        public String assessment_date { get; set; }
        public DateTime? assmt_date { get; set; }
        public String ismultipleAsr { get; set; }
        public String state { get; set; }
        public String district { get; set; }

    }
    public class OnsiteAllocationInstitute
    {
        public OnsiteAllocationInstitute()
        {
            this.row = new List<AllocatedInstituteListOnsite>();
        }
        public bool isSuccess { get; set; }
        public string message { get; set; }
        public List<AllocatedInstituteListOnsite> row { get; set; }
    }

}
