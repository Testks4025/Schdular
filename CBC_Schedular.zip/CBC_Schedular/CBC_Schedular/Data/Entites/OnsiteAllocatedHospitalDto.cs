﻿using CBC_Schedular.Data.Entites.HospitalSections;
using System;
using System.Collections.Generic;
using System.Text;

namespace CBC_Schedular.Data.Entites
{
    public class OnsiteAllocatedHospitalDto
    {
        public OnsiteAllocatedHospitalDto()
        {
            
        }
        public long hospital_id { get; set; }
        public String hospital_name { get; set; }
        public String organization_type { get; set; }
        public String city { get; set; }
        public String citycode { get; set; } // distcode
        public String state { get; set; }
        public String district { get; set; }
        public long? capacity { get; set; }

        public string capacityname
        {
            get
            {
                string ret = "";

                if (capacity == null || (capacity != null && capacity <= 0))
                    ret = "";

                if ((capacity != null && capacity > 0))
                    if (capacity == 1)
                        ret = "Principal Assessor";

                if (capacity == 2)
                    ret = "Assessor";

                return ret;
            }
        }
        public DateTime? assessment_date { get; set; }
        public string asmt_date { get; set; }
        public long? asrid { get; set; }
        public String asrname { get; set; }

        public long? stage_id { get; set; }
        public string stage { get; set; }
        public long? assessment_id { get; set; }
        public long form_id { get; set; }

        public string asmttype { get; set; }
        public string ismultipleAsr { get; set; }

        //public String tablist { get; set; }

        //public String assesment_type { get; set; }

        //public bool isEmpanelled { get; set; }
        //public List<SoSData> sosData { get; set; }
        //public string scope { get; set; }
    }


    public class OaAllocation
    {
        public long hospital_id { get; set; }
        public long? oaid_1 { get; set; }
        public long desktop_assessor_id { get; set; }
        
        public Int32? capacity_1 { get; set; }
        public long? oaid_2 { get; set; }
        public Int32? capacity_2 { get; set; }
        public DateStruct asmt_date { get; set; }
        public DateStruct asmt_date_to { get; set; }

        public Int32? asmt_type { get; set; }
        public String certificate_url { get; set; }
    }

    public class CcAllocation
    {
        public long hospital_id { get; set; }
        public long? cc_id { get; set; }  // committe member id
        public DateStruct Committe_date { get; set; }
    }


    //public class SoSData
    //{
    //    public string service_name { get; set; }
    //    public bool isHcoSelected { get; set; }
    //    //public bool isAsrSelected { get; set; }
    //}

    //public class ScopeSelected
    //{
    //    public string service_name { get; set; }
    

    //}
}
