﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CBC_Schedular.Data.Entites
{
    public class PayemntTrackerList
    {
        public long id { get; set; }
        public long? hosp_id { get; set; }
        public String reference_id { get; set; }
        public String org_name { get; set; }
        public long state_id { get; set; }
        public String state { get; set; }
        public String application_type { get; set; }
        public String type { get; set; }

        public String application_no { get; set; }
        public DateTime registration_date { get; set; }
        public String stage { get; set; }
        public long stage_id { get; set; }
        public Boolean status { get; set; }

        public String city { get; set; }
        public String district { get; set; }

        public string gstin { get; set; }
        public string pan { get; set; }
        public String tds { get; set; }

        public string tan { get; set; }
        public string gstcertificate { get; set; }
        public string gststatus { get; set; }

        public string payment_mode { get; set; }
        //Mode of payment used by the customer
        //Credit Card
        //Net banking
        //Debit Card
        //Cash Card
        //Mobile Payment
        //Alphabets

        // and unique id provided by ccavent account
        public string order_id { get; set; }
        //Unique ID sent by the merchant at the time of initiating the transaction.
        //Alphanumeric(30)
        public string tracking_id { get; set; }

        //public decimal? amount { get; set; }
        public string amount { get; set; }
        public DateTime? payment_date { get; set; }


    }
    public class PayemntTracker
    {
        public int current { get; set; }
        public long total { get; set; }
        public int rowcount { get; set; }
        public List<PayemntTrackerList> rows { get; set; }

        
    }

}
