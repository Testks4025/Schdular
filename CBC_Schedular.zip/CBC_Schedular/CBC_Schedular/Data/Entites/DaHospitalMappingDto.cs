﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CBC_Schedular.Data.Entites
{
   public class DaHospitalMappingDto
    {
        public long id { get; set; }
        public long hospid { get; set; }
        public long dauser_id { get; set; }
        public Boolean isactive { get; set; }

        public DateTime? created_on { get; set; }
    }
}
