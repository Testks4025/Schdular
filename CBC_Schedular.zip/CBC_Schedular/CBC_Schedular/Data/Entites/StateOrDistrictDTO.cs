﻿
using System.Text;

namespace CBC_Schedular.Data.Entites
{    
    public class StateDTO
    {      
        public long id { get; set; }
        public string statename { get; set; }
        public string statecode { get; set; }
        public string gstcode { get; set; }
    }
    
    public class DistrictDTO
    {      
        public long id { get; set; }
        public string districtname { get; set; }
        public string statecode { get; set; }
        public string gstcode { get; set; }
    }
}

