﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CBC_Schedular.Data.Entites
{
   public class UnDeliveredMailDTO
    {
        public long id { get; set; }
        public string mail_subject { get; set; }
        public string mail_to { get; set; }
        public string mail_cc { get; set; }
        public string mail_body { get; set; }
        public DateTime? mail_date { get; set; }
        public bool? mail_sent { get; set; }
        public Int64? mail_trycount { get; set; }
        public string trymail_errlog { get; set; }
        public string mailtemplatepath { get; set; }
    }
}
