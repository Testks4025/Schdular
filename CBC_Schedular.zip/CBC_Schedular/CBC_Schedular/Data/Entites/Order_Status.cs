﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CBC_Schedular.Data.Entites
{
    public class Order_Status
    {
        public Order_Status()
        {
            Order_Status_Result = new Order_Status_Result();
        }
        public Order_Status_Result Order_Status_Result { get; set; }
    }
    public class Order_Status_Result
    {
        public String order_gtw_id { get; set; }
        public String order_no { get; set; }
        //public long order_ship_zip { get; set; }
        public String order_ship_zip { get; set; }
        public String order_ship_address { get; set; }
        public String order_bill_email { get; set; }
        public String order_notes { get; set; }
        //public long order_capt_amt { get; set; }
        //public long order_ship_tel { get; set; }
        public String order_capt_amt { get; set; }
        public String order_ship_tel { get; set; }
        public String order_ship_name { get; set; }
        public String order_bill_country { get; set; }
        public String order_card_name { get; set; }
        public String order_status { get; set; }
        public String order_bill_state { get; set; }
        //public decimal order_tax { get; set; }
        public String order_tax { get; set; }
        public String order_bill_city { get; set; }
        public String order_ship_state { get; set; }

        //public long order_discount { get; set; }
        //public long order_TDS { get; set; }
        public String order_discount { get; set; }
        public String order_TDS { get; set; }

        public String order_date_time { get; set; }
        public String order_ship_country { get; set; }
        public String order_bill_address { get; set; }
        //public long order_fee_perc_value { get; set; }
        public String order_fee_perc_value { get; set; }
        public String order_ip { get; set; }
        public String order_option_type { get; set; }

        public String order_bank_ref_no { get; set; }
        public String order_currncy { get; set; }
        //public long order_fee_flat { get; set; }
        public String order_fee_flat { get; set; }
        public String order_ship_city { get; set; }
        //public long order_bill_tel { get; set; }
        public String order_bill_tel { get; set; }

        public String order_device_type { get; set; }
        //public long order_gross_amt { get; set; }
        //public long order_amt { get; set; }
        public String order_gross_amt { get; set; }
        public String order_amt { get; set; }
        public String order_fraud_status { get; set; }
        public String order_status_date_time { get; set; }
        //public int status { get; set; }
        public String status { get; set; }

    }

}
