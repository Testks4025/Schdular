﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CBC_Schedular.Data.Entites
{
   public class NabetDaAllocatedDto
    {
        public long institute_id { get; set; }
        public String reference_id { get; set; }
        public String org_name { get; set; }
        public String state_id { get; set; }
        public String state { get; set; }

        public String application_no { get; set; }
        public DateTime registration_date { get; set; }
        public DateTime? updated_date { get; set; }

        public String stage { get; set; }
        public long stage_id { get; set; }
        public Boolean status { get; set; }
        public Boolean isactive { get; set; }
        
        public long da_user_id { get; set; }
        public String da_name { get; set; }

        public long da_user_id_onsite { get; set; }
        public String da_name_onsite { get; set; }
    }

    public class DA_Nabet_AllocationList
    {
        public int current { get; set; }
        public long total { get; set; }
        public int rowcount { get; set; }
        public List<NabetDaAllocatedDto> rows { get; set; }


    }
}
