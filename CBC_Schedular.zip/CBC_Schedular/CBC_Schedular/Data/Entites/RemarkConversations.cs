﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CBC_Schedular.Data.Entites
{
   public class RemarkConversations
    {

        public String message_text { get; set; }
        public String document_list { get; set; }

        public DateTime created_date { get; set; }

        public long role_id { get; set; }

        public String user_name { get; set; }

        public long user_id { get; set; }
    }
    public class AdminRemarkConversations : RemarkConversations
    {


        public long remark_id { get; set; }
        public long unread_msg_count { get; set; }

        public DateTime updated_date { get; set; }

        public String application_no { get; set; }
        public String reference_no { get; set; }


    }

}
