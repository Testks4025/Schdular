﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CBC_Schedular.Data.Entites
{
    public class CertificateItems
    {
        public long id { get; set; }
        public string certificateNumber { get; set; }
        public string hospitalName { get; set; }
        public string address { get; set; }
        public string validFrom { get; set; }
        public string validTo { get; set; }
        public List<string> SocpeOfService { get; set; }
        public string certType { get; set; }
        public string grade { get; set; }

        public string sereialNo { get; set; }

        public string qr_code { get; set; }
        public bool old_certificate_pattern { get; set; }

        public string secretary { get; set; }
        public string chair_person { get; set; }

        public int star { get; set; }

    }
    
}
