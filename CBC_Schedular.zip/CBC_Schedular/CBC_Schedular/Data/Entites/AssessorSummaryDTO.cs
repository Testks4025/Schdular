﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CBC_Schedular.Data.Entites
{

    public class AssessorSummaryDTO
    {
        public AssessorSummaryDTO()
        {
            this.feedbackbyAsr = new SecondAssessorfeedbackSumm();
           
        }
       
        public SecondAssessorfeedbackSumm feedbackbyAsr { get; set; }
        public long hospital_id { get; set; }
        public long? pasr_id { get; set; }
        public long? sasr_id { get; set; }
        public string pasr_name { get; set; }
        public string sasr_name { get; set; }
        public long asmtid { get; set; }
        public string summary { get; set; }

        public DateTime? asmtdate { get; set; }

    }
    public class SecondAssessorfeedbackSumm
    {
        public SecondAssessorfeedbackSumm()
        {
            this.assmnt_conduct_professnl_mannr = new QuesOption();
            this.knowldge_nbh_requrmnt_hco_crtificat = new QuesOption();
            this.assmnt_findng_approtly_presntd = new QuesOption();
            this.assessd_witht_bis_convd = new QuesOption();
            this.lookd_facts_objctv = new QuesOption();
            this.effctve_communitn_informntn = new QuesOption();
            this.maturty_open_mindns = new QuesOption();
            this.approprt_prsnl = new QuesOption();
            this.ethcl_practc = new QuesOption();
          
        }
        public long? sasr_id { get; set; }
        public QuesOption assmnt_conduct_professnl_mannr { get; set; }
        public QuesOption knowldge_nbh_requrmnt_hco_crtificat { get; set; }
        public QuesOption assmnt_findng_approtly_presntd { get; set; }
        public QuesOption assessd_witht_bis_convd { get; set; }
        public QuesOption lookd_facts_objctv { get; set; }
        public QuesOption effctve_communitn_informntn { get; set; }
        public QuesOption maturty_open_mindns { get; set; }
        public QuesOption approprt_prsnl { get; set; }

        public QuesOption ethcl_practc { get; set; }
        public string generl_commnts_specfc { get; set; }

        

}


    public class QuesOption
    {
        public bool? ques_rating { get; set; }
        public string ques_comment { get; set; }
     
 
    }


}
