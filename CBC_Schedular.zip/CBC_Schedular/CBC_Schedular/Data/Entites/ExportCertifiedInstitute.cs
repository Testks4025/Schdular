﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CBC_Schedular.Data.Entites
{
    public class ExportCertifiedInstitute
    {
        public long agency_id { get; set; }
        public long agency_id_onsite { get; set; }
        public String application_no { get; set; }
        public long da_user_id { get; set; }
        public long da_user_id_onsite { get; set; }

        
        public String institute_name { get; set; }
        public DateTime? assmt_start_date { get; set; }
        public DateTime? assmt_end_date { get; set; }
        public String primary_assessor { get; set; }
        public String secondary_assessor { get; set; }
        public decimal self_assmt_score { get; set; }
        public decimal onsite_assmt_score { get; set; }
        public String grade { get; set; }
        public String final_remark { get; set; }

        public String desktop_assessor { get; set; }
        public DateTime oa_or_qc__complete_date_filter { get; set; }

        public String desktop_assr_onsite { get; set; }
        public String agency_desktop { get; set; }
        public String agency_onsite { get; set; }
        public String agency_qip { get; set; }
    }
}
