﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CBC_Schedular.Data.Entites
{
   public class CommitteDecisionDTO
    {

       public String da_advisiory { get; set; }
        public String oa_advisiory { get; set; }
    }
}
