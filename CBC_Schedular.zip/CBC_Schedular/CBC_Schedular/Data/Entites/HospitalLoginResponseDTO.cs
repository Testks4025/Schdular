﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CBC_Schedular.Data.Entites
{
    public class HospitalLoginResponseDTO
    {       
        public long hospital_id { get; set; }
    
        public bool isactive { get; set; }
        public long stage_id { get; set; }
        public string organization_type { get; set; } //Hospital or Centre

        public string organization_name { get; set; } 

        public bool isfirsttime_login { get; set; }

       

        public String workkingdays { get; set; }
        public DateTime? registrationDate { get; set; }

        public Int32? stage_timeline_workingdays { get; set; }
        public DateTime? stageid_enddate { get; set; }

        public DateTime? extension_Date { get; set; }
        public long? onsite_assmt_id { get; set; }

    }
}
