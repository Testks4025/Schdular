﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CBC_Schedular.Data.Entites.FormBuilder
{
    // mobile response save section wise data 
   public class FormBuilderMobileResponseData
    {
        public long hospital_id { get; set; }
        public long assessment_id { get; set; }
        public long section_id { get; set; }        
        public string section_name { get; set; }
        public string form_guid { get; set; }
        public List<Question> questions { get; set; }
    }

    public class FormBuilderMobileResponseDataWeb
    {
        public long? hospital_id { get; set; }
        public long assessment_id { get; set; }
        public string refrence_id { get; set; }

        public string application_no { get; set; }

        public DateTime? assessment_Date { get; set; }
        public DateTime? to_assessment_Date { get; set; }

        public string assessor1 { get; set; }

        public string assessor2 { get; set; }
        public long? assessor2_id { get; set; }

        public string org_name { get; set; }

        public string type { get; set; }

        public string org_type { get; set; }
        public string state { get; set; }
        public string sepeciality { get; set; }
        public string senction_bed { get; set; }

        public List<GetSectionWeb> getSectionWebs { get; set; }
    }

    public class GetSectionWeb
    {
        public long section_id { get; set; }
        public string section_name { get; set; }

        public string section_guid { get; set; }

        public long? ncCount { get; set; }
        public List<Question> questions { get; set; }
    }
}

