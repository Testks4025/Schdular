﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CBC_Schedular.Data.Entites.FormBuilder
{ // rrc
    public class fb_asmtData
    {
        public fb_asmtData()
        {
            this.asmt_response = new List<asmtData_formbuldr_assessments_response>();
            this.asmt_section_completed = new List<asmtData_formbuldr_assessments_section_completed>();
        }
        public FormBuilderGetJsonRoot fb_getjsonroot { get; set; }
        public asmtData_onsite_assessment onsite_asmt { get; set; }
        public List<asmtData_formbuldr_assessments_response> asmt_response { get; set; }
        public List<asmtData_formbuldr_assessments_section_completed> asmt_section_completed { get; set; }
    }

    #region rrc Asmt Data

    public class asmtData_onsite_assessment
    {
        public long id { get; set; }
        public long? hospid { get; set; }
        public long? oa_user_id { get; set; }
        public string oa_suggestion_remark { get; set; }
        public string oa_reject_remark { get; set; }
        public DateTime? oa_complete_date { get; set; }
        public DateTime? assessment_date { get; set; }
        public DateTime? created_on { get; set; }
        public DateTime? updated_on { get; set; }
    }

    public class asmtData_formbuldr_assessments_response
    {
        public long id { get; set; }
        public string guid { get; set; }
        public long? assessment_id { get; set; }
        public long? hospital_id { get; set; }
        public long? section_id { get; set; }
        public long? ques_id { get; set; }
        public string ques_gui_id { get; set; }
        public string ques_ans { get; set; }
        public string ques_nc_remark { get; set; }
        public string ques_image_url { get; set; }
        public bool? isactive { get; set; }
    }

    public class asmtData_formbuldr_assessments_section_completed
    {
        public long id { get; set; }
        public string guid { get; set; }
        public long? assessment_id { get; set; }
        public long? hospital_id { get; set; }
        public long? section_id { get; set; }
        public DateTime? section_create_date { get; set; }
        public DateTime? section_update_date { get; set; }
        public bool? isactive { get; set; }
    }

    #endregion


}
