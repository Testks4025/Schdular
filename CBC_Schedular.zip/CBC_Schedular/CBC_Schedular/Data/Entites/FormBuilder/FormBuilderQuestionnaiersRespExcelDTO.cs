﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CBC_Schedular.Data.Entites.FormBuilder
{


    public class FormBuilderQuestionnaiersRespExcelListDTO
    {

        public FormBuilderQuestionnaiersRespExcelListDTO()
        {

            FormBuilderList = new List<FormBuilderQuestionnaiersRespExcelDTO>();

        }

        public List<FormBuilderQuestionnaiersRespExcelDTO> FormBuilderList { get; set; }

    }
    public class FormBuilderQuestionnaiersRespExcelDTO
    {
        public FormBuilderQuestionnaiersRespExcelDTO()
        {

            sectionData = new List<SectionData>();

        }

        public long form_id { get; set; }
        public string form_name { get; set; }

        public List<SectionData> sectionData { get; set; }
        
    }

    public class SectionData
    {
        public SectionData()
        {

            questionHeaderName = new List<QustionHeaderName>();
            questionRespAnswer = new List<QuestionRespAnswer>();
            questionRespAnswer2 = new List<QuestionRespAnswer>();

        }
        public long section_id { get; set; }
        public string section_name { get; set; }
        public List<QustionHeaderName> questionHeaderName { get; set; }
        public List<QuestionRespAnswer> questionRespAnswer { get; set; }
        public List<QuestionRespAnswer> questionRespAnswer2 { get; set; }


    }
    public class vendorSavedResponse
    {
        public String question_text { get; set; }
        public String question_response { get; set; }


    }
    //public class QuestionHeaderWithResp
    //{
    //    public List<QustionHeaderName> qustionHeaderName { get; set; }
    //}

    public class QustionHeaderName
    {
        public long ques_type_id;

        public long ques_id { get; set; }
        public string ques_text { get; set; }       

    }

    public class QuestionRespAnswer
    {
        public long ques_id { get; set; }
        public long inst_id { get; set; }
        public string ques_ans { get; set; }
        public string inst_name { get; set; }
        public string inst_appno { get; set; }
    }
}
