﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CBC_Schedular.Data.Entites.FormBuilder
{
   public class FormBuilderHospitalList
    {

      
        public String hospname { get; set; }
        public long? hospid { get; set; }
        public String form_guid { get; set; }
        public long? assmt_id { get; set; }

        public int total_section { get; set; }
        public int section_synced { get; set; }

        


    }
}
