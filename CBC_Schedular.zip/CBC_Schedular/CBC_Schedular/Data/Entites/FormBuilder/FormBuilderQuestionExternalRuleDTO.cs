﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CBC_Schedular.Data.Entites.FormBuilder
{
    public class FormBuilderQuestionExternalRuleDTO
    {
        public long id { get; set; }
        public long form_id { get; set; }
        public long section_id { get; set; }
        public long source_ques_id { get; set; }
        public long rule_dependent_ques_id { get; set; }
        public long option_id { get; set; }
        public string rule_category_type { get; set; }
        public bool is_show_image { get; set; }
        public bool is_show_remark { get; set; }
        public string rule_condition { get; set; }
        public List<FormBuilderQuestionInfoDTO> ruleDepentQuestions { get; set; }



        public FormBuilderQuestionExternalRuleDTO()
        {
            this.ruleDepentQuestions = new List<FormBuilderQuestionInfoDTO>();
        }
        ////public long id { get; set; }
        ////public long form_id { get; set; }
        ////public long section_id { get; set; }
        //public long question_type_id { get; set; }
        //public string question_text { get; set; }
        //public string question_description { get; set; }
        //public string ques_keyowrd { get; set; }
        //public string help_text { get; set; }
        //public bool mandatory_question { get; set; }
        //public Int64 maximum_number_of_characters { get; set; }
        //public Int64 minimum_value { get; set; }
        //public Int64 maximum_value { get; set; }
        //public Int64 min_no_of_options { get; set; }
        //public bool is_capture_image { get; set; }
        //public Int64 number_of_images { get; set; }
        //public bool is_capture_nc { get; set; }
        //public bool is_capture_remark { get; set; }
        //public Int64 ques_order { get; set; }
        //public bool isactive { get; set; }
        //public bool ques_status { get; set; }

        //public string question_type { get; set; }

        //public List<FormBuilderQuestionInfoOptionDTO> questionOption { get; set; }


    }

    public class RuleDepentQuestions
    {
        public long rule_dependent_ques_id { get; set; }
        public string question_text { get; set; }
    }
}
