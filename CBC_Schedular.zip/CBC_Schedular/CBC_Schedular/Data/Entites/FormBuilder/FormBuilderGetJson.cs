﻿using CBC_Schedular.Data.Entites.InstituteSections;
using System;
using System.Collections.Generic;
using System.Text;

namespace CBC_Schedular.Data.Entites.FormBuilder
{


    public class FormBuilderGetJson
    {
        public long id { get; set; }
        public string ques_id { get; set; }
        public string ques_text { get; set; }
        public string ques_type { get; set; }
    }
    // Root myDeserializedClass = JsonConvert.DeserializeObject<Root>(myJsonResponse); 

    public class FormBuilderGetJsonRoot
    {
        public FormBuilderGetJsonRoot()
        {
            this.institute_data = new InstituteSetionsDataDTO();
        }
        public long id { get; set; }
        public string form_guid { get; set; }
        public string form_name { get; set; }
        public string form_type { get; set; }

        public InstituteSetionsDataDTO institute_data { get; set; }
        public List<Section> sections { get; set; }


    }


    public class OnsiteViewGetJsonRoot : FormBuilderGetJsonRoot
    {
        public OnsiteViewGetJsonRoot()
        {

        }

        public List<Section> onsite_data_sections { get; set; }

    }


    public class documentupdateModel
    {
        public long current_ques_id { get; set; }
        public String doc_string { get; set; }
    }
    public class Option
    {
        public string guid { get; set; }
        public string value { get; set; }
        public long option_order { get; set; }
        public int score { get; set; }
        public bool? is_selected { get; set; }
        public long? group_id { get; set; }
        public String intervention_stage { get; set; }
        public String intervention_description { get; set; }
    }

    public class OptionRule
    {
        public string guid { get; set; }
        public string value { get; set; }
        public bool is_image_show { get; set; }
    }

    public class InternalRule
    {
        public long max_number_of_char_allow { get; set; } //prev int
        public long? min_limit_number { get; set; }
        public long? max_limit_number { get; set; }
        public long? capture_number_of_image { get; set; }
        public bool? is_nc_capture { get; set; }
        public bool? is_image_capture { get; set; }
        public List<OptionRule> option_rule { get; set; }
    }

    public class QuesRef
    {
        public string ques_ref_id { get; set; }
    }

    public class OptionRule2
    {
        public List<QuesRef> ques_ref { get; set; }
        public string guid { get; set; }
        public string value { get; set; }
        public bool is_ques_show { get; set; }
    }

    public class ExternalRule
    {
        //public List<QuesRef> ques_ref { get; set; }
        public List<OptionRule2> option_rule { get; set; }
    }

    public class Question
    {

        public Question()
        {
            this.isvisible = true;
            this.isvisible_group = false;
        }
        public long ques_id { get; set; }  //prev it was int
        public string ques_source_id { get; set; }
        public string ques_text { get; set; }
        public long ques_order { get; set; } //prev it was int
        public string ques_help_text { get; set; }
        public string ques_type { get; set; }
        public long ques_type_id { get; set; } //new added by vk

        public string description { get; set; }
        public bool is_mandatory { get; set; }
        public string keyword { get; set; }
        public string ques_ans { get; set; }
        public string ques_nc_remark { get; set; }
        public string remark { get; set; }
        public string oa_image_url { get; set; }
        public bool? isnc { get; set; }

        public string form_guid { get; set; }



        public string ques_image_url { get; set; }

        public List<UrlItem> ques_image_url_list { get; set; }

        public List<Option> option { get; set; }
        public InternalRule internal_rule { get; set; }
        public ExternalRule external_rule { get; set; }

        public bool isvisible { get; set; }

        public bool isvisible_group { get; set; }

        public long? ques_group_id { get; set; }
        public string ques_group_name { get; set; }
        public string ques_serial_tag_no { get; set; }

        //below added as per svacode
        public long max_number_of_char_allow { get; set; } //prev int
        public long? min_limit_number { get; set; }
        public long? max_limit_number { get; set; }
        public long? capture_number_of_image { get; set; }
        public bool? is_nc_capture { get; set; }
        public bool? is_image_capture { get; set; }
        public bool is_apply_external_rule_source_ques { get; set; }
        public string nc_cycle_count { get; set; } /// new added 23-Mar-21

        public DaNcInstituteDetailsDTO nc_details { get; set; }
        public List<DaNcInstituteDetailsDTO> nc_list { get; set; }

        public int da_score { get; set; }
        public int oa_score { get; set; }
    }

    public class Section
    {
        public long id { get; set; }
        public string section_name { get; set; }
        public int section_order { get; set; } //vk add
        public List<Question> Questions { get; set; }
        public int open_nc_count { get; set; }
        public string pillar_desc { get; set; }
    }
    //new added 05 - mar-21

    //public class FormBuilderGetJsonRootHco
    //{
    //    public long id { get; set; }
    //    public string form_guid { get; set; }
    //    public string form_name { get; set; }
    //    public string form_type { get; set; }
    //    public List<SectionHco> Sections { get; set; }

    //}
    //public class SectionHco
    //{
    //    public long id { get; set; }
    //    public string section_name { get; set; }
    //    public int section_order { get; set; } //vk add
    //    public List<QuestionHco> Questions { get; set; }
    //}

    //public class QuestionHco
    //{

    //    public QuestionHco()
    //    {
    //        this.isvisible = true;
    //        this.isvisible_group = false;
    //    }
    //    public long ques_id { get; set; }  //prev it was int
    //    public string ques_source_id { get; set; }
    //    public string ques_text { get; set; }
    //    public long ques_order { get; set; } //prev it was int
    //    public string ques_help_text { get; set; }
    //    public string ques_type { get; set; }
    //    public long ques_type_id { get; set; } //new added by vk

    //    public string description { get; set; }
    //    public bool is_mandatory { get; set; }
    //    public string keyword { get; set; }
    //    public string ques_ans { get; set; }
    //    public string ques_nc_remark { get; set; }
    //    public string remark { get; set; }
    //    public bool? isnc { get; set; }

    //    public string form_guid { get; set; }



    //    public string ques_image_url { get; set; }

    //    public List<UrlItem> ques_image_url_list { get; set; }

    //    public List<Option> option { get; set; }
    //    public InternalRule internal_rule { get; set; }
    //    public ExternalRule external_rule { get; set; }

    //    public bool isvisible { get; set; }

    //    public bool isvisible_group { get; set; }

    //    public long? ques_group_id { get; set; }
    //    public string ques_group_name { get; set; }
    //    public string ques_serial_tag_no { get; set; }

    //    //below added as per svacode
    //    public long max_number_of_char_allow { get; set; } //prev int
    //    public long? min_limit_number { get; set; }
    //    public long? max_limit_number { get; set; }
    //    public long? capture_number_of_image { get; set; }
    //    public bool? is_nc_capture { get; set; }
    //    public bool? is_image_capture { get; set; }
    //    public bool is_apply_external_rule_source_ques { get; set; }
    //}
    public class InstituteResponseDto
    {
        public bool IsHistory { get; set; }
        public long id { get; set; }
        public string Message { get; set; }
        public FormBuilderGetJsonRoot response { get; set; }
    }

}
