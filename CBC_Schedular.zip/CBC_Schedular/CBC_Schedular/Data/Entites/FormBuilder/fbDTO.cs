﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CBC_Schedular.Data.Entites.FormBuilder
{
    public class fbDTO
    {
        public long id { get; set; }
        public string ques_id { get; set; }
        public string ques_text { get; set; }
        public string ques_type { get; set; }
    }
    // Root myDeserializedClass = JsonConvert.DeserializeObject<Root>(myJsonResponse); 

    public class fbDtoRoot
    {
        public long id { get; set; }
        public string form_guid { get; set; }
        public string form_name { get; set; }
        public string form_type { get; set; }
        public List<fbDto_Section> Sections { get; set; }
    }

    public class fbDto_Option
    {
        public string guid { get; set; }
        public string value { get; set; }
        public bool is_selected { get; set; }        
        public string question_guid { get; set; }
        public bool? is_selected_ans { get; set; }        
    }

    public class fbDto_OptionRule
    {
        public string guid { get; set; }
        public string value { get; set; }
        public bool is_image_show { get; set; }        
        public long id { get; set; }
        public long ques_id { get; set; }
        public string option_text { get; set; }        
        public bool is_image_internal_rule { get; set; }        
        public bool is_image_external_rule { get; set; }
        public Int64 option_order { get; set; }        
        public string question_guid { get; set; }
        public bool? is_selected_ans { get; set; }        
    }

    public class fbDto_InternalRule
    {
        public long max_number_of_char_allow { get; set; } //prev int
        public long? min_limit_number { get; set; }
        public long? max_limit_number { get; set; }
        public long? capture_number_of_image { get; set; }
        public bool? is_nc_capture { get; set; }
        public bool? is_image_capture { get; set; }
        public List<fbDto_OptionRule> option_rule { get; set; }
    }

    public class fbDto_QuesRef
    {
        public string ques_ref_id { get; set; }
    }

    public class fbDto_OptionRule2
    {
        public string guid { get; set; }
        public string value { get; set; }
        public bool is_ques_show { get; set; }
    }

    public class fbDto_ExternalRule
    {
        public List<fbDto_QuesRef> ques_ref { get; set; }
        public List<fbDto_OptionRule2> option_rule { get; set; }
    }

    public class fbDto_Question
    {
        public long ques_id { get; set; }  //prev it was int
        public string ques_source_id { get; set; }
        public string ques_text { get; set; }
        public long ques_order { get; set; } //prev it was int
        public string ques_help_text { get; set; }
        public string ques_type { get; set; }
        public long ques_type_id { get; set; } //new added by vk

        public string description { get; set; }
        public bool is_mandatory { get; set; }
        public string keyword { get; set; }
        public string ques_ans { get; set; }
        public string ques_nc_remark { get; set; }
        public string ques_image_url { get; set; }        
        public string guid { get; set; }
        public string form_guid { get; set; }
        public string section_guid { get; set; }
        public string question_type_guid { get; set; }
        public List<fbDto_Option> option { get; set; }
        public fbDto_InternalRule internal_rule { get; set; }
        public fbDto_ExternalRule external_rule { get; set; }
    }

    public class fbDto_Section
    {
        public long id { get; set; }
        public string section_name { get; set; }
        public long form_id { get; set; }        
        public int section_order { get; set; }        
        public bool status { get; set; } // false= draft or true= live
        public string guid { get; set; }
        public string form_guid { get; set; }
        public List<fbDto_Question> Questions { get; set; }
    }


}