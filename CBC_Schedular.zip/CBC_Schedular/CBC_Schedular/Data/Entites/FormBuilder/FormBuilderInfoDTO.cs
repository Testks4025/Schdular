﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CBC_Schedular.Data.Entites.FormBuilder
{
    public class FormBuilderInfoDTO
    {
        public long id { get; set; }
        public string form_name { get; set; }
        public string form_category { get; set; } //hospital or center
        public string platform { get; set; } // web or mobile
        public DateTime create_date { get; set; }
        public DateTime? published_date { get; set; }
        public bool status { get; set; } // false= draft or true= live

        public string status_str
        {
            get
            {
                if (status)
                {
                    return "live";
                }
                else
                {
                    return "Draft";
                }
            }

        }
    }


    public class FormBuilderSectionDTO
    {
       
        public long id { get; set; }
        public long form_id { get; set; }
        public string section_name { get; set; }
        public int section_order { get; set; }        
        public bool status { get; set; } // false= draft or true= live

        public string status_str
        { 
            get
            {
                if (status)
                {
                    return "live";
                }
                else
                {
                    return "Draft";
                }
            }
        }

        public long number_total_questions { get; set; }

        public long number_of_published_qtns { get; set; }
        public bool array_type_section  { get; set; }
}


    public class FormBuilderQuestionTypeDTO
    {
        public long id { get; set; }
        public string question_type { get; set; }       
        public bool status { get; set; } // false= draft or true= live
        public string icon { get; set; }
    }
}
