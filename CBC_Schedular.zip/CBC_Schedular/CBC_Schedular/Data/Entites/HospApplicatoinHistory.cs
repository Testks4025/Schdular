﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CBC_Schedular.Data.Entites
{
   public class HospApplicatoinHistory
    {

       public long id { get; set; }
        public String hosp_type { get; set; }
        public String app_no { get; set; }
        public String app_type { get; set; }
        public String stage { get; set; }
        public DateTime reg_date { get; set; }


      
    }
}
