﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CBC_Schedular.Data.Entites
{
    public class InstituteRevisitRequestDto
    {
        public long institute_id { get; set; }
    }
}
