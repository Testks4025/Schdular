﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CBC_Schedular.Data.Entites.Common
{
    public class EntityOperationResult
    {
        public long id { get; set; }
        public bool isSuccess { get; set; }
        public string Message { get; set; }
       public Int32? count { get; set; }
        public long? pasrid { get; set; }
        public long? asrid { get; set; }

        public long? asrid2 { get; set; }

        public DateTime? asmtdate { get; set; }

    }

    public class ChangeDestopAssessorResponseModel:EntityOperationResult
    {
        
            public bool IsSameAssessor { get; set; }
    }
    public class CertificateGenerateEntityOperationResult:EntityOperationResult
    {
        public long? primary_assessor { get; set; }
        public long? secondary_assessor { get; set; }

    }
   

    public class OnsiteAssessmentResult: EntityOperationResult
    {
        public bool can_genrate_certificate { get; set; }
        public long institute_id { get; set; }
        public long? primary_assessor { get; set; }
        public long? secondary_assessor { get; set; }
    }

    public class QcUpdateResult : EntityOperationResult
    {
        
        //public String oa_image_url { get; set; }
        public List<UrlItem> ques_image_url_list { get; set; }
    }
    public class CertifiedHospForNabh: EntityOperationResult
    {
        public CertifiedHospForNabh()
        {
            this.certified_hospital_list = new List<CertifiedHospitalListDto>();
        }

      public  List<CertifiedHospitalListDto> certified_hospital_list { get; set; }
    }
    public class EntityOperationResultRemark : EntityOperationResult
    {
        public long remark_id { get; set; }
    }


    public class UserSearchResponse
    {
        public long total { get; set; }
        public int rowCount { get; set; }
        public int current { get; set; }
        public List<UserMasterDTO> rows { get; set; }
    }

    public class UserFilter
    {
        public int? limit { get; set; }
        public int? offset { get; set; }
        public string sort { get; set; }
        public string searchtext { get; set; }
        public long? selectedrole { get; set; }
        public string searchstatus { get; set; }
        public SearchDatee searchdate { get; set; }        
    }

    public class SearchDatee
    {
        public Data.Entites.HospitalSections.DateStruct from_date { get; set; }
        public Data.Entites.HospitalSections.DateStruct to_date { get; set; }
    }


    public class EntityimplementationOperationResult
    {
        public bool isSuccess { get; set; }
        public long instituteid { get; set; }
        public string Message { get; set; }
        public object Data { get; set; }  // Optional: for returning list or object
    }
}

