﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CBC_Schedular.Data.Entites.Common
{
    public class TokenRequest
    {
        public string UserName { get; set; }
        public string Password { get; set; } 
        public string grant_type { get; set; } 
        public string RefreshToken { get; set; } // can be 'password' or 'refresh_token'
    }


    public class TokenResponse
    {
        public TokenResponse()
        {
           this.navigation = new List<NavigationMenuDTO>();
        }

       public long? onsite_assmt_id { get; set; }
        public string accessToken { get; set; }
        public string refreshToken { get; set; }
        public string userName { get; set; }       
        public long userId { get; set; }
        public string email { get; set; }
        public string roleName { get; set; }
        public long roleId { get; set; }
        public bool isactive { get; set; }
        public bool elegible_for_certification { get; set; }
        public string message { get; set; }
        public List<NavigationMenuDTO> navigation { get; set; }
        public long hospital_id { get; set; }
        public bool is_basic_cert_applied { get; set; }
        public string org_type { get; set; }
        public string org_name { get; set; }
        public long stage_id { get; set; }

        public int usercount { get; set; }

        public bool isfirsttime_login { get; set; }

        public String workkingdays { get; set; }
        public DateTime? registrationDate { get; set; }

        public Int32? stage_timeline_workingdays { get; set; }
        public DateTime? stageid_enddate { get; set; }

        public string mobile { get; set; }
        public bool is_eleg_for_renew { get; set; }

        public bool is_eleg_for_qip { get; set; }
        public bool is_qip_accepted { get; set; }
        public int not_of_days_to_expire { get; set; }

        public long  unread_msg_count { get; set; }
        public String version_code { get; set; }
        public String version_name { get; set; }


    }

}

