﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CBC_Schedular.Data.Entites
{
    public class InstituteList_AllocationDto
    {
        public long hosp_id { get; set; }
        public String reference_id { get; set; }
        public String org_name { get; set; }
        public String agency_name { get; set; }
        public long agency_id { get; set; }
        
        public long state_id { get; set; }
        public String state { get; set; }
        public long da_asr_id { get; set; }
        public long da_asr_id_onsite{ get; set; }

        public String city { get; set; }
        public String speciality { get; set; }

        public String application_type { get; set; }
        public String type { get; set; }

        public String application_no { get; set; }
        public DateTime registration_date { get; set; }

        public DateTime? da_asmtdate { get; set; }
        public String stage { get; set; }
        public long? stage_id { get; set; }
        public Boolean status { get; set; }
        public long hospital_apply_for { get; set; }

        public List<HospitalStage> stage_history { get; set; }

        public String current_da { get; set; }
        public long current_da_id { get; set; }

        public long? asmtid { get; set; }
        public DateTime? oa_asmtdate { get; set; }
        public DateTime? to_oa_asmtdate { get; set; }
        //public String oa_asmtdate_struct 
        //{

        //    get
        //    {
        //        String date = null;

        //        if (oa_asmtdate == null || oa_asmtdate.HasValue == false|| to_oa_asmtdate == null || to_oa_asmtdate.HasValue == false)
        //        {
        //            return null;

        //        }
        //        else 
        //        {
        //            date = oa_asmtdate.Value.Day + "/" + oa_asmtdate.Value.Month + "/" + oa_asmtdate.Value.Year + "-" + to_oa_asmtdate.Value.Day + "/" + to_oa_asmtdate.Value.Month + "/" + to_oa_asmtdate.Value.Year;
        //        }




        //        return date;
        //    }
        //}


        public AsrDateStruct oa_asmtdate_struct
        {
            get
            {
                AsrDateStruct ds = new AsrDateStruct();

                if (oa_asmtdate == null || oa_asmtdate.HasValue == false)
                    return null;

                if (oa_asmtdate != null && oa_asmtdate.HasValue == true)
                {
                    ds.day = oa_asmtdate.Value.Day;
                    ds.month = oa_asmtdate.Value.Month;
                    ds.year = oa_asmtdate.Value.Year;
                }

                return ds;
            }

        }

        public AsrDateStruct oa_asmtdate_to_struct
        {
            get
            {
                AsrDateStruct ds = new AsrDateStruct();

                if (to_oa_asmtdate == null || to_oa_asmtdate.HasValue == false)
                    return null;

                if (to_oa_asmtdate != null && to_oa_asmtdate.HasValue == true)
                {
                    ds.day = to_oa_asmtdate.Value.Day;
                    ds.month = to_oa_asmtdate.Value.Month;
                    ds.year = to_oa_asmtdate.Value.Year;
                }

                return ds;
            }

        }


        public long? oaid { get; set; }
        public string oa { get; set; }

        public long? principaloaid { get; set; }
        public string principaloa { get; set; }


        public DateTime? committeedate { get; set; }
        public long? cometemember_id { get; set; }
        public string cometemember { get; set; }
        public string total_bed_strength { get; set; }
        public long? districtid { get; set; }
        public string district { get; set; }

        public String assmt_type { get; set; }
        public long assessorid { get; set; }
        public Int32? oa_asmt_type { get; set; } // rrc Physical/Virtual
        public Int32? capacity_1 { get; set; } // rrc Principal Asr/Asr
        public Int32? capacity_2 { get; set; } // rrc Principal Asr/Asr
        public bool isactive { get; set; }

       public String agency_name_onsite { get; set; }

    }

    public class OA_AllocationList
    {
        public int current { get; set; }
        public long total { get; set; }
        public int rowcount { get; set; }
        public List<InstituteList_AllocationDto> rows { get; set; }
    }

    public class CC_AllocationList
    {
        public int current { get; set; }
        public long total { get; set; }
        public int rowcount { get; set; }
        public List<InstituteList_AllocationDto> rows { get; set; }
    }

}
