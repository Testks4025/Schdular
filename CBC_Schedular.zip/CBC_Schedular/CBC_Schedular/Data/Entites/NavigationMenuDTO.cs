﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CBC_Schedular.Data.Entites
{
    public class NavigationMenuDTO
    {        
        public long id { get; set; }
        public string name { get; set; }
        public string url { get; set; }
        public string icon { get; set; }
        public Badge badge { get; set; }
        public List<NavigationMenuDTO> children { get; set; }
        public NavigationMenuDTO()
        {
            this.children = new List<NavigationMenuDTO>();
        }
    }

    public class Badge
    {
        public string badge { get; set; }
        public string text { get; set; }
    }
}
