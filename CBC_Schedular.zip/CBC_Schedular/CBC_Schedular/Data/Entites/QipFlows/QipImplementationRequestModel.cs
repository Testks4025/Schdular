﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace CBC_Schedular.Data.Entites.QipFlows
{

    public class QipImplementationFlowRequest
    {
        public int InstituteId { get; set; }
        public List<QipMetricRequest> Metrics { get; set; }
    }

    public class QipImplementationMetricRequest
    { 
        [Required]
        public string MetricNo { get; set; }
    }

    public class QipImplementationRequestModel
    {
        public int instituteid { get; set; }

        public List<QipImplementationMetrics> qipImplementationMetrics { get; set; }

    }

    public class QipImplementationMetrics
    {
        public string MetricNo { get; set; }
        public string[] imgurl { get; set; }
        public string status { get; set; }
    }

    public class agencyRemarksRequestModel
    {
        public int instituteid { get; set; }

        public List<agencyRemarksRequest> agencyRemarksRequests { get; set; }

    }

    public class agencyRemarksRequest
    {
        public string MetricNo { get; set; }
        
        public string agencyRemarks { get; set; }
    }
    public class MentorRemarksRequestModel
    {
        public int instituteid { get; set; }

        public List<MentorRemarksRequest> mentorRemarksRequests  { get; set; }

    }

    public class MentorRemarksRequest
    {
        public string MetricNo { get; set; }

        public string mentorRemarks { get; set; }
    }

    public class adminRemarksRequestModel
    {
        public int instituteid { get; set; }

        public List<adminRemarksRequest> adminRemarksRequests { get; set; }

    }

    public class adminRemarksRequest
    {
        public string MetricNo { get; set; }

        public string adminRemarks { get; set; }
    }

    public class QipConsentRequestModel
    {
        public int instituteid {  get; set; }
        public string Name { get; set; }

        public string Email { get; set; } 

        public string Contact { get; set; }

        public string Remarks { get; set; }
    }

}
