﻿using CBC_Schedular.Data.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace CBC_Schedular.Data.Entites.QipFlows
{
    public class AdminfileuploadReuqestModel
    {
        public string AdminMDORemark { get; set; }
        public long institute_id { get; set; }
        public string imageurl { get; set; }
    }

    public class QipFlow
    {
        public int application_type { get; set; }
        public long userId { get; set; }
        public string imageurl { get; set; }
    }

    public class QipFlow_accepted
    {
        public long instituteId { get; set; }
        [DefaultValue("false")]
        public bool is_qip_accepted { get; set; }
    }
    public class TaskForceMemberRequest
    {
        public string Role { get; set; } // Director, Faculty, Mentor
        public string Name { get; set; }
        public string Designation { get; set; }
        public string EmailId { get; set; }
        public string ContactNumber { get; set; }
        public int InstituteId { get; set; } // FK to Institute
        public DateTime CreatedDate { get; set; } = DateTime.UtcNow;
    }
    public class SaveTaskForceResponse
    {
        public bool isSuccess { get; set; }
        public string Message { get; set; }
        public int id { get; set; } = 0;
        public List<TaskForceMember> Members { get; set; }
    }

    public class QipPotentialScoreResponse
    {
        public double CurrentTotalScore { get; set; }
        public double AspiredTotalScore { get; set; }
        public int CurrentStar { get; set; }
        public int AspiredStar { get; set; }
        public bool IsStarImproved { get; set; }
        public string Message { get; set; }
    }

}
