﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CBC_Schedular.Data.Entites.QipFlows
{
    public class SaveRemarksResponse
    {
        public bool isSuccess { get; set; }           // Overall success
        public string message { get; set; }           // Success/failure message
        public int InstituteId { get; set; } = 0;     // Institute Id
        public List<MetricRemarksStatus> Metrics { get; set; } // Metric-wise status
    }

    public class MetricRemarksStatus
    {
        public string MetricId { get; set; }          // MetricNo or SrNo
        public bool IsApproved { get; set; }          // Approval status
        public bool IsRejected { get; set; }          // Rejection status
        public int? Stage { get; set; }                // Stage after update
    }

}
