﻿using CBC_Schedular.Data.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace CBC_Schedular.Data.Entites.QipFlows
{
    public class QipImplementationResponseModel
    {
        public int Id { get; set; }
        public long InstituteId { get; set; }
        public string MetricNo { get; set; }
        public List<string> FileUrls { get; set; }  // Easier for JSON serialization
        public string Status { get; set; }          // "Pending", "Ongoing", "Completed", "Unable to Achieve"

        public double? simulated_score { get; set; }
        public double? aspire_Score { get; set; }
        public string ActionPoints { get; set; }
        public string timelines { get; set; }
        public string pillerNo { get; set; }
        public string Appilcation_AgencyRemarks { get; set; }
        public string Application_MentorRemarks { get; set; }
        public string Application_AdminRemarks { get; set; }
        public string AgencyRemarks { get; set; }
        public string MentorRemarks { get; set; }
        public string AdminRemarks { get; set; }
        public DateTime CreatedDate { get; set; }
        public DateTime? UpdatedDate { get; set; }
    }

    // Nested model to represent each file item cleanly
    //public class FileDetailModel
    //{
    //    public string FileName { get; set; } = string.Empty;
    //    public string FileUrl { get; set; } = string.Empty;
    //    public string Description { get; set; } = string.Empty;
    //}
    public class QipConsentResponse
        {
            public int Id { get; set; }
            public long instituteid { get; set; }

            public string Name { get; set; } = string.Empty;

            public string Email { get; set; } = string.Empty;

            public string? Contact { get; set; }

            public string? Remarks { get; set; }

            public DateTime? CreatedDate { get; set; }

            public DateTime? UpdatedDate { get; set; }
        }
    

}
