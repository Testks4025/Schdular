﻿using CBC_Schedular.Data.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace CBC_Schedular.Data.Entites.QipFlows
{
    public class QipProcessFlowResponseDTO
    {
        // 🆕 Added property
        public long institute_stageid { get; set; }

        public List<QipProcessFlowResponse> process_flow_response { get; set; }

    }   
        public class QipProcessFlowResponse
    {
        public int id { get; set; }
        public long instituteId { get; set; }
        public string Pillar { get; set; }
        public decimal PillarWeightage { get; set; }
        public string MetricNo { get; set; }
        public int MaximumStage { get; set; }
        public double SimulatedScore { get; set; }
        public double Score { get; set; }
        public double PotentialGain { get; set; }
        public double AspiredScore_PotentialGain { get; set; }
        public double aspiredScore_score { get; set; }
        public string HealthStatus { get; set; }
        public decimal? PillarAverage { get; set; }
        public int? AspiringStageScore { get; set; }
        public string ActionPoints { get; set; }
        public string Timeline { get; set; }
        public string MentorRemarks { get; set; }
        public string overallRemarks { get; set; }
        public string AdminRemarks { get; set; }
        public bool status { get; set; }
        public int? stage { get; set; }
        public DateTime CreatedDate { get; set; }
        public DateTime? UpdatedDate { get; set; }
        public bool IsAdminApproved { get; set; }
        public bool IsAdminRejected { get; set; }
        public string AgencyRemarks { get; set; }
        public string ImageUrl { get; set; }
        public bool IsMentorApproved { get; set; }
        public bool IsMentorRejected { get; set; }
        public bool IsagencyApproved { get; set; }
        public bool IsagencyRejected { get; set; }
    }

    
    public class ExpiryBucketResponse
    {
        public string ApplicableMonths { get; set; }
    }


}
