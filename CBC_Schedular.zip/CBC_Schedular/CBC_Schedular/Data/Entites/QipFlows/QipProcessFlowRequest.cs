﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace CBC_Schedular.Data.Entites.QipFlows
{
    public class QipProcessFlowRequest
    {
        public int InstituteId { get; set; }
        public List<QipMetricRequest> Metrics { get; set; }
    }

    public class QipMetricRequest
    {
        [Required]
        public string Pillar { get; set; }
        [Required]
        public int PillarWeightage { get; set; }
        [Required]
        public string MetricNo { get; set; }
        [Required]
        public int MaximumStage { get; set; }
        [Required]
        public double SimulatedScore { get; set; }
        [Required]
        public double Score { get; set; }
        [Required]
        public double PotentialGain { get; set; }

        [Required]
        public decimal PillarAverage { get; set; }


        public int? AspiringStageScore { get; set; }

        [Required]
        public string HealthStatus { get; set; }

        public double AspiredScore_PotentialGain { get; set; }

        public double aspiredScore_score { get; set; }

        // optional fields

    }

    public class AspireRequest
    {
        public int InstituteId { get; set; }
        public List<Aspirescore> aspirescores { get; set; }
    }

    public class Aspirescore
    {
        [Required]
        public string MetricId { get; set; }
        public int AspireScore { get; set; }
    }
    public class QipProcessFlowUpdateListRequest
    {
        [Required]
        public int InstituteId { get; set; }

        [Required]
        public List<MetricUpdateItem> Metrics { get; set; }
    }

    public class MetricUpdateItem
    {
        [Required]
        public string MetricId { get; set; }  // Assuming MetricNo is string

        [Required]
        public string HealthStatus { get; set; }

        [Required]
        public string ActionPoints { get; set; }

        [Required]
        public string Timeline { get; set; }

        public string imageurl { get; set; }
    }
    public class AgencyRemarksUpdateRequest
    {
        [Required]
        public int InstituteId { get; set; }

        [Required]
        public List<AgencyRemarkItem> Metrics { get; set; }
    }

    public class AgencyRemarkItem
    {
        [Required]
        public string MetricId { get; set; }   // MetricNo or SrNo

        public string agencyRemarks { get; set; }

        public bool is_agency_approved { get; set; } = false;

        public bool is_agency_rejected { get; set; } = false;


    }
    public class MentorRemarksUpdateRequest
    {
        [Required]
        public int InstituteId { get; set; }
        public string overallRemarks { get; set; }

        [Required]
        public List<MentorRemarkItem> Metrics { get; set; }

       
    }
    

    public class MentorRemarkItem
    {
        [Required]
        public string MetricId { get; set; }   // MetricNo or SrNo

        public string MentorRemarks { get; set; }
        //public string AgecyRemarks_updatedbyMentor { get; set; }


        public bool is_mentor_approved { get; set; } = false;

        public bool is_mentor_rejected { get; set; } = false;
    }

    public class AdminRemarksUpdateRequest
    {
        [Required]
        public int InstituteId { get; set; }

        [Required]
        public List<AdminRemarkItem> Metrics { get; set; }
    }

   public class AdminRemarkItem
{
    [Required]
    public string MetricId { get; set; }   // MetricNo or SrNo

    public string AdminRemarks { get; set; }
   //public string mentorRemarks_updatedbyAdmin { get; set; }

   public bool is_approved { get; set; } = false;

    public bool is_rejected { get; set; } = false;
}






}
