﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CBC_Schedular.Data.Entites.QipFlows
{
    public class GetQipInstitutesResponse
    {

        public long instituteId {  get; set; }
        public string instituteName { get; set; }
        public string app_no { get; set; }

       public int institute_stageid { get; set; }


    }

    public class QipAdminDashboardResponse
    {
        public int qip_allocated_institutes { get; set; }
        public int qip_notaccepted_institutes { get; set; }
        public int qip_accepted_insitutes {get;set; }     
        public int TaskForce_insitutes {get;set; }
        public int inprogress_qip_institutes { get; set; }
        public int mentor_allocated_instiute {  get; set; }
        public int admin_instiutes {  get; set; }
        public int qip_completed_institues_count{get; set; }

    }

   

}
