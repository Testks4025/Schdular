﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace CBC_Schedular.Data.Models
{
    [Table("oa_form_otp_history_app")]
    public class OaMobileOtpHistoryApp
    {
        [Key]
        public long id { get; set; }
        public String mobilenumber { get; set; }
        public String otp { get; set; }
        public DateTime createddate { get; set; }
        public int status { get; set; }
    }
}
