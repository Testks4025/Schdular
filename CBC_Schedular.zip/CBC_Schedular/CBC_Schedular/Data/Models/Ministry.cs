﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace CBC_Schedular.Data.Models
{
    [Table("ministry")]
    public class Ministry
    {
        [Key]
        public long id { get; set; }
        public long ministry_id { get; set; }
        public String ministry_name { get; set; }

    }
}
