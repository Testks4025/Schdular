﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CBC_Schedular.Data.Models
{
    [Table("qipflow_info_institute")]
    public class QipFlowInfo
    {
        [Key]
        [Column("id")]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        [Column("instituteid")]
        public long InstituteId { get; set; }

        [Column("userid")]
        public long UserId { get; set; }

        [Column("documenturl", TypeName = "text")]
        [Required]
        public string DocumentUrl { get; set; }

        [Column("createddate")]
        public DateTime CreatedDate { get; set; } = DateTime.Now;

        [Column("updateddate")]
        public DateTime? UpdatedDate { get; set; }

        [Column("is_approved")]
        public bool IsApproved { get; set; } = true;

        [Column("remarks", TypeName = "text")]
        public string Remarks { get; set; }

        
    }
}
