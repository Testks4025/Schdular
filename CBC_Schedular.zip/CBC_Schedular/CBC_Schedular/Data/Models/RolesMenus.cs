﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;
#pragma warning disable 1591
namespace CBC_Schedular.Data.Models
{
    [Table("rolesmenus")]
    public class RolesMenus
    {
        [Key]
        public long id { get; set; }
        public long? menuid { get; set; }
        public long? roleid { get; set; }
        public bool? allowaccess { get; set; }
    }
}
