﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace CBC_Schedular.Data.Models
{
    [Table("hospital_que_starndrad_code")]
    public class HospitalQueStandradCode
    {
        [Key]
        public long id { get; set; }
        public string organization_type { get; set; }
        public string stndrcode { get; set; }
        public string code { get; set; }        
        public string standards { get; set; }
        public string objctve_no { get; set; }
        public string objctve_elmnt { get; set; }
        public long code_id { get; set; }
    }

    [Table("center_que_starndrad_code")]
    public class CenterQueStandradCode
    {
        [Key]
        public long id { get; set; }
        public string organization_type { get; set; }
        public string stndrcode { get; set; }
        public string code { get; set; }
        public string standards { get; set; }
        public string objctve_no { get; set; }
        public string objctve_elmnt { get; set; }
        public long code_id { get; set; }
    }

}
