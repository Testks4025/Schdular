﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace CBC_Schedular.Data.Models
{
    [Table("forgot_pass_request")]
    public class ForgotPasswordRequest
    {


        [Key]
        public long id { get; set; }
        public String email { get; set; }
        public String guid { get; set; }
        public DateTime request_date { get; set; }

        public int status { get; set; }

        


    }
}
