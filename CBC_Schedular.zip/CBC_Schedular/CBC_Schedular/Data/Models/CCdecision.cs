﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace CBC_Schedular.Data.Models
{
    [Table("cc_decision")]
    public class CCdecision
    {
        [Key]
        public long id { get; set; }
        public long hospital_id { get; set; }
        [Column(TypeName = "jsonb")]
        public string scopes { get; set; }

        public DateTime? createdon { get; set; }
        public DateTime? updatedon { get; set; }
  
        public long? created_by { get; set; }

        public bool? recommended { get; set; }
        public bool? non_recommended { get; set; }
        public bool? pending_recommended { get; set; }
        public string recommend_remark { get; set; }
        public string non_recommend_remark { get; set; }
        public string pending_remark { get; set; }
        public string da_advisary { get; set; }
        public string oa_advisary { get; set; }
    }

}
