﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace CBC_Schedular.Data.Models.FormBuilder
{
	[Table("cc_pending_history")]
	public class CCPeningHistory
	{
		[Key]
		public long id { get; set; }
	
		public long hospitalid { get; set; }
		public long decision_id { get; set; }

		public string cc_remarks { get; set; }
		public DateTime? cc_created_date { get; set; }
		public string hco_reply { get; set; }
		public DateTime? hco_reply_created_date { get; set; }
		public int ccstage { get; set; }
		public string uploadurl { get; set; }
		public bool cc_status { get; set; }
		
	}
}
