﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace CBC_Schedular.Data.Models
{
    [Table("taskforcemember")]
    public class TaskForceMember
    {
        [Key]
        public int id { get; set; } // Primary Key
        public string role { get; set; } // Director, Faculty, Mentor
        public string name { get; set; }
        public string designation { get; set; }
        public string emailid { get; set; }
        public string contactnumber { get; set; }
        public int instituteid { get; set; } // FK to Institute
        public DateTime createddate { get; set; }
     
       public DateTime? updateddate { get; set; }

    }

}
