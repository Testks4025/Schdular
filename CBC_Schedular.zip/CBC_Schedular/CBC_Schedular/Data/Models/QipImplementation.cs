﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CBC_Schedular.Data.Models
{
    [Table("qip_implementation")]
    public class QipImplementation
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }

        [Column("institute_id")]
        public long InstituteId { get; set; }

        [Column("metric_no")]
        public string MetricNo { get; set; }   // NOT NULL

        [Column("file_urls")]
        public string[] FileUrls { get; set; }

        [Column("status")]
        [MaxLength(50)]
        public string Status { get; set; }  // "Pending", "Ongoing", "Completed", "Unable to Achieve"

        [Column("agency_remarks")]
        public string AgencyRemarks { get; set; }

        [Column("mentor_remarks")]
        public string MentorRemarks { get; set; }

        [Column("admin_remarks")]
        public string AdminRemarks { get; set; }

        [Column("created_date")]
        public DateTime CreatedDate { get; set; } = DateTime.UtcNow;

        [Column("updated_date")]
        public DateTime? UpdatedDate { get; set; } = DateTime.UtcNow;
    }
}
