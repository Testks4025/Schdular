﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;
#pragma warning disable 1591

namespace CBC_Schedular.Data.Models
{
    [Table("stagemaster")]
    public class StageMaster
    {
        [Key]
        public long id { get; set; }
        public long stageid { get; set; }
        public string stagename { get; set; }
        public long? stage_group { get; set; }
        public string group_color { get; set; }
        public string stageheader { get; set; } // rrc - Application/DA/OA/Committee
        public Int32? timeline_workingdays { get; set; }
    }
}
