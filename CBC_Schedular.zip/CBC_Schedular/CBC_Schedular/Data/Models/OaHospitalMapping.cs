﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace CBC_Schedular.Data.Models
{
    [Table("oa_hospital_mapping")]
    public class OaHospitalMapping
    {
        [Key]
        public long id { get; set; }
        public long hospid { get; set; }
        public long asrid { get; set; }
        public Boolean isactive { get; set; }

        public DateTime? created_on { get; set; }

        // rrc
        public long? principal_asrid { get; set; }
        public long? createdby { get; set; }
        public DateTime? assessmentdate { get; set; }
        public DateTime? to_assessmentdate { get; set; }
        public Int32? capacity_1 { get; set; }
        public Int32? capacity_2 { get; set; }
        public Int32? asmt_type { get; set; }
        // rrc
        
        public bool? date_rejected_by_hco { get; set; }

        public string date_reject_remarks { get; set; }
        public bool? date_rejected_by_assesor { get; set; }

        public string date_reject_byasr_remarks { get; set; }

        public bool? isaccptedbypasr { get; set; }

        public string isacceptedbypasr_remark { get; set; }


    }

}
