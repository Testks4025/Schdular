﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;


namespace CBC_Schedular.Data.Models
{
  
    [Table("hosp_certificate_number")]
    public class HospitalCertificateUniqueNo
    {

       [Key]
        public long id { get; set; }
        public long hosp_type { get; set; }
        public long certificate_ubique_numb { get; set; }
     

    }
}
