﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace CBC_Schedular.Data.Models
{
    [Table("edu_qualification")]
    public class EduQualification
    {
        [Key]
        public long id { get; set; }
        public string qualification { get; set; }
        public string details { get; set; }
    }
}
