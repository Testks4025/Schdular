﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace CBC_Schedular.Data.Models
{
    [Table("extension_log")]
    public class ExtensionLog
    {
        [Key]
        public long id { get; set; }
        public long? hospital_id { get; set; }
        public DateTime? extented_date { get; set; }

        public DateTime? extented_on { get; set; }
        public long? extented_by { get; set; }
        public long stageid { get; set; }

        public string remarks { get; set; }
        public bool? isactive { get; set; }


    }
}
