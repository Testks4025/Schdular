﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace CBC_Schedular.Data.Models
{
    [Table("institute_reg_info")]
    public class InstituteRegistraion
    {
        [Key]
        public long id { get; set; }
        public long userid { get; set; }
        public string org_name { get; set; }
        public string nodal_officer { get; set; }
        public string state_code { get; set; }
        public string? address { get; set; }
        public int city_id { get; set; }
        public String designation { get; set; }
        

        public String institute_type { get; set; }
        public string affliation { get; set; }


        

        public string email { get; set; }
        public string mobile { get; set; }
       
        public long stageid { get; set; }
        public DateTime creationdate { get; set; }
        public DateTime? updatedate { get; set; }
        [DefaultValue("true")]
        public bool isactive { get; set; }
        [DefaultValue("false")]
        public bool registration_approved { get; set; }
        public string organization_type { get; set; }
        public long application_no_unq_no { get; set; }
        public string application_no { get; set; }
        public string organisation_id { get; set; }
        public bool is_reapply_renew { get; set; }
        public bool is_qip_accepted { get; set; }

        public int hospital_apply_for { get; set; }
        public int hospital_application_type_no { get; set; }
        public bool is_approved { get; set; }
        [DefaultValue("false")]
        public bool is_part_a_submitted { get; set; }

        public int? hosp_progress { get; set; } // rrc

        //public string da_suggestion_remark { get; set; }
        //public string da_reject_remark { get; set; }


        // rrc
        public string gststatus { get; set; }
        public string gstin { get; set; }
        public string pan { get; set; }
        public string tan { get; set; }
        public string gstcertificate { get; set; }        
        public string tradename { get; set; }
        // rrc        

        //vk start
        public string rejected_withdrwan_reason { get; set; }

        public bool? mailsend_incompleteaplcnform_2ndmail { get; set; }

        public bool? mailsend_incompleteaplcnform_1stmail { get; set; }

        public bool? mailsend_deactivate_incompleteaplcn { get; set; }

        //public bool? mailsend_Reminder_DaNCReply1 { get; set; }

        //public bool? mailsend_Reminder_DaNCReply1_25days { get; set; }

        public DateTime? extented_date { get; set; }

        [DefaultValue("false")]
        public bool isrejectedby_admin { get; set; }

        public string isrejectedby_admin_reason { get; set; }

        public long invoiceuniquenumber { get; set; }

        public long  refrenceuniquenumber { get; set; }

        public long financialyear { get; set; }

        public long? department_id { get; set; }
        public long? ministry_id { get; set; }
        public String state_central { get; set; }

        public String city { get; set; }

        public bool is_cbc_institute { get; set; }
        public bool is_da_allocated_cbc_institute { get; set; }
        public String? certificate_reject_remark { get; set; }
        public long certificate_reject_remark_created_by { get; set; }
        public DateTime? last_login_date_time { get; set; }

        public String tag_1 { get; set; }
        public String tag_2 { get; set; }
        public String tag_3 { get; set; }

        public String tag_4 { get; set; }
        public String tag_5 { get; set; }
        public String tag_6 { get; set; }




        //vk end
    }
}
