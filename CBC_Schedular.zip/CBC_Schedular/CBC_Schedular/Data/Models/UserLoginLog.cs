﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;
#pragma warning disable 1591

namespace CBC_Schedular.Data.Models
{
    [Table("userloginlog")]
    public class UserLoginLog
    {
        [Key]
        public long userid { get; set; }
        public string guid { get; set; }
        public DateTime? logintime { get; set; }
    }
}
