﻿using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CBC_Schedular.Data.Models.FormBuilder
{
    [Table("onsite_assessments_response")]
    public class OnsiteAssessmentResponse
    {

        [Key]
        public long id { get; set; }
        public string guid { get; set; }
        public long assessment_id { get; set; }
        public long section_asmnt_complete_id { get; set; }

        
        public long? institute_id { get; set; }
   
        public long? section_id { get; set; }
        public long? ques_id { get; set; }
        public string ques_gui_id { get; set; }
        public string ques_ans { get; set; }

        public string ques_image_url { get; set; }
        public bool? isactive { get; set; }
        public string assessor_remark { get; set; }
        public string img_url_by_assr { get; set; }


    }

    [Table("onsite_assessments_section_completed")]
    public class OnsiteAssessmentSectionComplete
    {
        [Key]
        public long id { get; set; }
        public string guid { get; set; }
        public long? assessment_id { get; set; }
        public long? institute_id { get; set; }
        public long? section_id { get; set; }
      //  public long? syned_from { get; set; }
        public DateTime? section_create_date { get; set; }
        public DateTime? section_update_date { get; set; }

    }


}
