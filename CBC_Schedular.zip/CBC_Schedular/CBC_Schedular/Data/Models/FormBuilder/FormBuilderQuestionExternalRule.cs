﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace CBC_Schedular.Data.Models.FormBuilder
{
    [Table("formbuldr_que_extrnl_rule")]
    public class FormBuilderQuestionExternalRule
    {
        [Key]
        public long id { get; set; }
        public long form_id { get; set; }
        public long section_id { get; set; }
        public long source_ques_id { get; set; }
        public long rule_dependent_ques_id { get; set; }
        public long option_id { get; set; }
        public string rule_category_type { get; set; } //External/Internal
        [DefaultValue("true")]
        public bool is_show_image { get; set; }
        [DefaultValue("true")]
        public bool is_show_remark { get; set; }
        public string rule_condition { get; set; } //AND/or
        public string guid { get; set; }
        public string form_guid { get; set; }
        public string section_guid { get; set; }
        public string source_ques_guid { get; set; }
        public string rule_dependent_ques_guid { get; set; }
        public string option_guid { get; set; }
    }


    //[Table("formbuldr_extrnl_que_depent_rule_mapping")]
    //public class FormBuilderExternalQuestionDepententRuleMapping
    //{
    //    [Key]
    //    public long id { get; set; }
    //    public long external_rule_id { get; set; }
    //    public long ques_id { get; set; }

    //}


    [Table("formbuldr_extrnl_que_optn_rule_mapping")]
    public class FormBuilderExternalQuestionRuleOptionMapping
    {
        [Key]
        public long id { get; set; }
        public long external_rule_id { get; set; }
        public long que_id { get; set; }
        public long option_id { get; set; }
        public string guid { get; set; }
        public string external_rule_guid { get; set; }
        public string que_guid { get; set; }
        public string option_guid { get; set; }
        [DefaultValue("true")]
        public bool is_external_rule { get; set; }


    }



}
