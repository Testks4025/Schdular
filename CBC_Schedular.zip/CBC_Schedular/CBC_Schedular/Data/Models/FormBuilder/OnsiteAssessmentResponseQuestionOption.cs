﻿using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
namespace CBC_Schedular.Data.Models.FormBuilder
{

    [Table("onsite_assessment_response_question_option")]
    public  class OnsiteAssessmentResponseQuestionOption
    {
        [Key]
		public long id { get; set; }
		public long institute_id { get; set; }
		public long ques_id { get; set; }

		public long  section_asmnt_complete_id { get; set; }
		public long asmt_response_id { get; set; }
		public string option_text { get; set; }
		public string option_guid { get; set; }
		public string question_guid { get; set; }
		public bool? is_selected_ans { get; set; }

    }
}
