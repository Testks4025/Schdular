﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace CBC_Schedular.Data.Models.FormBuilder
{
    [Table("formbuldr_info")]
    public class FormBiulderInfo
    {
        [Key]
        public long id { get; set; }
        public string form_name { get; set; }
        public string form_category { get; set; } //hospital or center
        public string platform { get; set; } // web or mobile
        public DateTime create_date { get; set; }
        public DateTime? published_date { get; set; }
        [DefaultValue("false")]
        public bool status { get; set; } // false= draft or true= live
        public string guid { get; set;}
        [Column(TypeName = "jsonb")]
        public string generated_questionnaires_json { get; set; }
    }



    [Table("formbuldr_section")]
    public class FormBiulderSection
    {
        [Key]
        public long id { get; set; }
        public long form_id { get; set; }
        public string section_name { get; set; }
        public int section_order { get; set; }
        [DefaultValue("false")]
        public bool status { get; set; } // false= draft or true= live

        public string guid { get; set; }
        public string form_guid { get; set; }
        [DefaultValue("false")]
        public bool array_type_section { get; set; }
        public String pillar_desc { get; set; }

    }


    [Table("formbuldr_question_type")]
    public class FormBiulderQuestionType
    {
        [Key]
        public long id { get; set; }
        public string question_type { get; set; }    
        [DefaultValue("false")]
        public bool status { get; set; } // false= draft or true= live

        public string icon { get; set; }

        public string guid { get; set; }

    }





}
