﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace CBC_Schedular.Data.Models.FormBuilder
{
    [Table("training_institute_list")]
    public class InstituteList
    {
        [Key]
        public long id { get; set; }
        public String institute_name { get; set; }
        public String service { get; set; }
        public String location { get; set; }
        public long? department_id { get; set; }

        
    }
}
