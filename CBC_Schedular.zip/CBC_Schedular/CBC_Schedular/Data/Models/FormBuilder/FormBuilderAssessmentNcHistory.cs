﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace CBC_Schedular.Data.Models.FormBuilder
{
	[Table("formbuldr_assessments_nchistory")]
	public class FormBuilderAssessmentNcHistory
	{
		[Key]
		public long id { get; set; }
		public long userid { get; set; }
		public long hospitalid { get; set; }
		public long assessment_id { get; set; }
		public long form_id { get; set; }
		public long ques_id { get; set; }
		public long section_id { get; set; }
		public string section_name { get; set; }
		public string nc_details { get; set; }
		public DateTime? nc_created_date { get; set; }
		public string ca_remarks { get; set; }
		public DateTime? ca_created_date { get; set; }
		public int ncstage { get; set; }
		public string uploadurl { get; set; }
		public bool nc_status { get; set; }
		//public bool  isopen { get; set; }
        public int nc_cyle_count { get; set; }

		//public string finalremark { get; set; }
	}
}
