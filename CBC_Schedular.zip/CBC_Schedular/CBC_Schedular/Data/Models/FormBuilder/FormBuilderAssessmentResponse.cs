﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace CBC_Schedular.Data.Models.FormBuilder
{
    [Table("formbuldr_assessments_response")]
    public class FormBuilderAssessmentResponse
    {
        [Key]
        public long id { get; set; }
        public string guid { get; set; }
        public long? assessment_id { get; set; }
        public long? hospital_id { get; set; }
        public long? section_id { get; set; }
        public long? ques_id { get; set; }
        public string ques_gui_id { get; set; }
        public string ques_ans { get; set; }

        public string ques_nc_remark { get; set; }

        public bool? isnc { get; set; }
        public string remark { get; set; }
        public string form_guid { get; set; }


        public string ques_image_url { get; set; }
        public bool? isactive { get; set; }

        public long? section_asmnt_complete_id { get; set; }
    }

    [Table("formbuldr_assessments_section_completed")]
    public class FormBuilderAssessmentSectionComplete
    {
        [Key]
        public long id { get; set; }
        public string guid { get; set; }
        public long? assessment_id { get; set; }
        public long? hospital_id { get; set; }
        public long? section_id { get; set; }
        public long? syned_from { get; set; }
        public DateTime? section_create_date { get; set; }
        public DateTime? section_update_date { get; set; }

    }


    [Table("formbuldr_response_question_option")]
    public class FormBuilderResponseQuestionOption
    {
        [Key]
        public long id { get; set; }
        public long vendor_id { get; set; }
        public long asmt_response_id { get; set; }
        public long ques_id { get; set; }
        public string option_text { get; set; }
        public string option_guid { get; set; }
        public string question_guid { get; set; }
        public bool? is_selected_ans { get; set; }
        public long section_asmnt_complete_id { get; set; }
    }


    [Table("formbuldr_response_compelete")]
    public class FormBuilderAssessmentResponseComplete
    {
        [Key]
        public long id { get; set; }
        public long? vendor_id { get; set; }
        public long? form_id { get; set; }
        [DefaultValue("false")]
        public bool is_submitted_by_asr { get; set; }

        public DateTime? submit_create_date { get; set; }
        public DateTime? submit_update_date { get; set; }

    }
}
