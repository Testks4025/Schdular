﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace CBC_Schedular.Data.Models
{
    [Table("hospital_sections")]
    public class HospitalSections
    {
        [Key]
        public long id { get; set; }
        public long section_id { get; set; }
        public string section_name { get; set; }
    }
}
