﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;
#pragma warning disable 1591
namespace CBC_Schedular.Data.Models
{
    [Table("refreshtokens")]
    public class RefreshTokens
    {
        [Key]
        public long id { get; set; }
        public long? userid { get; set; }
        public string token { get; set; }
        public DateTime? issuedatetime { get; set; }
    }
}
