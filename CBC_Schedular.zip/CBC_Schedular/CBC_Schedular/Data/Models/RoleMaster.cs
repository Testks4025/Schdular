﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace CBC_Schedular.Data.Models
{
    [Table("rolemaster")]
    public class RoleMaster
    {
        [Key]
        public long id { get; set; }
        public string rolename { get; set; }
    }

}
