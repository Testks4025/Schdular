﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace CBC_Schedular.Data.Models
{
    [Table("onsite_assessment")]
    public class OnsiteAssessment
    {
        [Key]
        public long id { get; set; }
        public long hospid { get; set; }
        public long asrid { get; set; }
        public String oa_suggestion_remark { get; set; }
        public String oa_reject_remark { get; set; }
        public DateTime? oa_complete_date { get; set; }
        public DateTime? assessment_date { get; set; }
        public DateTime? to_assessmentdate { get; set; }

        public DateTime? created_on { get; set; }
        public DateTime? updated_on { get; set; }

        // rrc
        public long? principal_asrid { get; set; }
        public long? createdby { get; set; }
        public DateTime? starttime { get; set; }
        public Int32? capacity_1 { get; set; }
        public Int32? capacity_2 { get; set; }
        public Int32? asmt_type { get; set; }
        public bool is_active { get; set; }

        
        // rrc
    }
}
