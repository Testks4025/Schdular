﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace CBC_Schedular.Data.Models
{
    [Table("assessors")]
    public class Assessor
    {
        [Key]
        public long id { get; set; }
        public long? userid { get; set; }
        public string asrname { get; set; }
        public string email { get; set; }        
        public string mobileno1 { get; set; }
        public string mobileno2 { get; set; }
        public DateTime? dob { get; set; }
        public string aadharnumber { get; set; }
        public long? qualificationid { get; set; }
        public string otherqualification { get; set; }
        public string specialitiesids { get; set; } // coma separated ids
        public decimal? totalworkexp { get; set; }
        public string currentorg { get; set; }
        public string designation { get; set; }
        public string orgaddress { get; set; }
        public long? stateid { get; set; }
        public string state_code { get; set; }
        public long? districtid { get; set; }
        public string city { get; set; }
        public string residentialaddress { get; set; }
        public string pin { get; set; }
        public decimal? latitude { get; set; }
        public decimal? longitude { get; set; }

        public string bankname { get; set; }
        public string bankbranchname { get; set; }
        public string bankaccountnumber { get; set; }
        public string accountholdername { get; set; }
        public string ifsc_code { get; set; }
        public string pannumber { get; set; }

        public string photourl { get; set; }
        public long? createdby { get; set; }
        public DateTime? createdon { get; set; }
        public bool? isactive { get; set; }


        public bool is_profile_submitted { get; set; }

        [DefaultValue("false")] // rrc
        public bool? isdeleted { get; set; } // rrc

        public string cv_url { get; set; }
        public string cheque_url { get; set; }
        public string domain { get; set; }


        //public string gender { get; set; }                       
        //public string pan_no { get; set; }
        //public long? native_location { get; set; }
        //public long? current_location { get; set; }

        //public DateTime created_date { get; set; }
        //public DateTime updated_date { get; set; }

        //[DefaultValue("true")]
        //public bool isactive { get; set; }
        //public long? createdby { get; set; }

        //[DefaultValue("false")]
        //public bool blacklist { get; set; }

        //public string reasonofblacklist { get; set; }
        //public decimal? avgrating { get; set; }

    }
}
