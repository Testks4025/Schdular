﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace CBC_Schedular.Data.Models
{
    [Table("hospital_cntr_da_ncdetails")]
   public class DaNcHospitalOrCenterDetails
    {
        [Key]
        public long id { get; set; }
        public long hospital_id { get; set; }
        public long ques_id { get; set; }
        public string classobject { get; set; }
        public string propertyname { get; set; }
        public bool? isnc { get; set; }
        public string remarks { get; set; }
        public string reply { get; set; }
        public string uploadurl { get; set; }
        public bool? isopen { get; set; }
        public string finalremark { get; set; }
        public DateTime? nccreatedate { get; set; }
        public DateTime? nccreatedatebyda { get; set; }
        public int? ncstage { get; set; }
        public bool? isnc_status { get; set; }
        [DefaultValue("true")]
        public bool is_active { get; set; }
        [DefaultValue("false")]
        public bool is_reviewed { get; set; }
        public int? nc_cycle_count { get; set; }

    }
}
