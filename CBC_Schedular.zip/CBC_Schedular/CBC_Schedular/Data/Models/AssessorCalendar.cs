﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace CBC_Schedular.Data.Models
{
    [Table("assessorcalendar")]
    public class AssessorCalendar
    {
        [Key]
        public long id { get; set; }
        public long? assessorid { get; set; }
        //public string asrstatus { get; set; }   // available, not-available
        //public DateTime? datevalue { get; set; }
                
        public string title { get; set; }   // available, not-available
        public DateTime? start { get; set; }
    }
}
