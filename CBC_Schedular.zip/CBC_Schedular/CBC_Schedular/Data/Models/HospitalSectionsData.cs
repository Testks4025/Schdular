﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace CBC_Schedular.Data.Models
{
    [Table("hospital_sections_data")]
    public class HospitalSectionsData
    {
        [Key]
        public long id { get; set; }
        public long hospital_id { get; set; }
        [Column(TypeName = "jsonb")]
        public string genral_info { get; set; }

        [Column(TypeName = "jsonb")]
        public string infection_control { get; set; }

        [Column(TypeName = "jsonb")]
        public string quality_care { get; set; }
        [Column(TypeName = "jsonb")]
        public string training{ get; set; }
        [Column(TypeName = "jsonb")]
        public string patientrecord { get; set; }
        [Column(TypeName = "jsonb")]
        public string humanresourcerecord { get; set; }
        [Column(TypeName = "jsonb")]
        public string scope_of_service { get; set; }
        [Column(TypeName = "jsonb")]
        public string admin_record { get; set; }

        [Column(TypeName = "jsonb")]
        public string statutory_compliance { get; set; }
        [Column(TypeName = "jsonb")]
        public string support_service { get; set; }
        [Column(TypeName = "jsonb")]
        public string admission_dischrge { get; set; }

        [Column(TypeName = "jsonb")]
        public string opd_reg_process { get; set; }

        

    }
}
