﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace CBC_Schedular.Data.Models
{
    [Table("calldetails")]
    public class Calldetails
    {
        [Key]
        public long id { get; set; }
        public long institute_id { get; set; }
        public long agency_id { get; set; }  
        public string callername { get; set; }
        public DateTime? calling_date { get; set; }
        public DateTime? createdon { get; set; }
        public string? supportofcbc { get; set; }
        public string? issue { get; set; }
        public string? organization { get; set; }
        public string interactiondetails { get; set; }
        public string medium {  get; set; }
       
        public long stage_id { get; set; }
        public string med_other { get; set; }
        public string issue_othr { get; set; }
        public string unique_call_query_no { get; set; }

    }

}
