﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace CBC_Schedular.Data.Models
{
    [Table("institute_oa_payment_receipt")]
    public class Institute_oa_payment_receipt
    {
        [Key]
        public long id { get; set; }
        public long institute_id { get; set; }

        public string receipt_no { get; set; }
        public string amount { get; set; }
        public DateTime payment_date { get; set; }
        public string to_whom_pymt_done { get; set; }
        public string receipt_doc_url { get; set; }

    }
}
