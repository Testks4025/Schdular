﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace CBC_Schedular.Data.Models
{

    public class DropdownData
    {
        public long id { get; set; }
        public string value { get; set; }
    }
    public class DepartmentDropdown: DropdownData
    {

        public long ministry_id { get; set; }
    }
    public class InstituteDropdown : DropdownData
    {

        public long? department_id { get; set; }
    }
    public class MinistryDepartmentDropdown
    {
        public List<DropdownData> ministry_dropdown { get; set; }
        public List<DepartmentDropdown> department_dropdown { get; set; }
    }

}