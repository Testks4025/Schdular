﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;
#pragma warning disable 1591

namespace CBC_Schedular.Data.Models
{
    [Table("self_assessment_score")]
    public class SelfAssessmentScore
    {
        [Key]
        public long id { get; set; }
        public long institute_id { get; set; }
        public decimal pillar_1 { get; set; }
        public decimal pillar_2 { get; set; }
        public decimal pillar_3 { get; set; }

        public decimal pillar_4 { get; set; }
        public decimal pillar_5 { get; set; }
        public decimal pillar_6 { get; set; }
        public decimal pillar_7 { get; set; }
        public decimal pillar_8 { get; set; }








        
    }
}
