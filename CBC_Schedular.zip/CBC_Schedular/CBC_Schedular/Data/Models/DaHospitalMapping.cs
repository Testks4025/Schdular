﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace CBC_Schedular.Data.Models
{

    [Table("da_hospital_mapping")]
    public class DaHospitalMapping
    {
        [Key]
        public long id { get; set; }
        public long hospid { get; set; }
        public long dauser_id { get; set; }
        public Boolean isactive { get; set; }

        public DateTime? created_on { get; set; }


        


    }
}
