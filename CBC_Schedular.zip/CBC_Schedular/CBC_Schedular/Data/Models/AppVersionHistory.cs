﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;
namespace CBC_Schedular.Data.Models
{


    [Table("app_version_history")]
    public class AppVersionHistory
    {
        [Key]
        public long id { get; set; }
        public String version_name { get; set; }
        public String version_code { get; set; }
        public bool status { get; set; }
        public bool for_hosp { get; set; }
        public bool for_assr { get; set; }

        
            




    }
}
