﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace CBC_Schedular.Data.Models
{
    [Table("menus")]
    public class Menu
    {
        [Key]
        public long id { get; set; }
        public string menuitem { get; set; }
        public long? parentmenuid { get; set; }
        public string url { get; set; }
        public int? pos { get; set; }
        public string menufor { get; set; }
        public bool? newwindow { get; set; }
        public string icon { get; set; }
        public string badge_variant { get; set; }
        public string badge_text { get; set; }
    }
}
