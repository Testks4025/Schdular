﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace CBC_Schedular.Data.Models
{
    [Table("tblstate")]
    public class State
    {
        [Key]
        public long id { get; set; }
        public string statename { get; set; }
        public string statecode { get; set; }
        public string gstcode { get; set; }
    }

    [Table("tbldistrict")]
    public class District
    {
        [Key]
        public long id { get; set; }
        public string districtname { get; set; }
        public string statecode { get; set; }
        public string gstcode { get; set; }
    }
}

