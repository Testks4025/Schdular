﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace CBC_Schedular.Data.Models
{
    [Table("usermaster")]
    public class UserMaster
    {
        [Key]
        public long id { get; set; }
        public long roleid { get; set; }
        public string firstname { get; set; }
        public string? lastname { get; set; }
        public string email { get; set; }
        public string mobile { get; set; }
        public string userpassword { get; set; }
        public bool? isactive { get; set; }
        public string? notes { get; set; }
        public long? otplogid { get; set; }
        public DateTime? creationdate { get; set; }
        public bool isfirsttimelogin { get; set; }
        [DefaultValue("false")] // rrc
        public bool? isdeleted { get; set; }
        // rrc isdeleted is false so that it depeits a row which is NOT Deleted, If this col is true means the row is soft deleted
        // it cannot be nullable as it will create problem in linq query which are already created

        public Int32? capacity { get; set; }  // rrc Principal Assessor (1), Assessor (2)

        public long? agency_id { get; set; }
    }
}
