﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CBC_Schedular.Data.Models
{
    [Table("qip_consents")]
    public class QipConsent
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }   // Identity (auto-generated)

        [Column("institute_id")]
        public long InstituteId { get; set; }   // Nullable, matches DB column
        [Column("name")]
        public string Name { get; set; }

        [Column("email")]
        public string Email { get; set; }

        [Column("contact")]
        public string Contact { get; set; }

        [Column("remarks")]
        public string Remarks { get; set; }

        [Column("created_date")]
        public DateTime? CreatedDate { get; set; }

        [Column("updated_date")]
        public DateTime? UpdatedDate { get; set; }
    }
}
