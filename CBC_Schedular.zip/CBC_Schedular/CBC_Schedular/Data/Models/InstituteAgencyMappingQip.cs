﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace CBC_Schedular.Data.Models
{
    [Table("institute_agency_mapping_qip")]
    public class InstituteAgencyMappingQIP
    {
        [Key]
        public long id { get; set; }
        public long institute_id { get; set; }
        public long agency_id { get; set; }
        public bool is_active { get; set; }
        public DateTime created_on { get; set; }
    }
}
