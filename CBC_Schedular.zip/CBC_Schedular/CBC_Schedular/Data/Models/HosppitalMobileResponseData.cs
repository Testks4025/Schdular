﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace CBC_Schedular.Data.Models
{
    [Table("hospital_mobile_response_data")]
    public class HosppitalMobileResponseData
    {
        [Key]
        public long id { get; set; }
        public long hospital_id { get; set; }
        public long assessment_id { get; set; }
        [Column(TypeName = "jsonb")]
        public string genral_info { get; set; }
        [Column(TypeName = "jsonb")]
        public string scope_of_service { get; set; }
        [Column(TypeName = "jsonb")]
        public string intigrity { get; set; }




    }
}
