﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace CBC_Schedular.Data.Models
{
    [Table("certified_hospital")]
    public  class CertifiedHospital
    {

        [Key]
        public long id { get; set; }
        public long hospital_id { get; set; }
        public String certificate_no { get; set; }
        public DateTime? valid_from { get; set; }
        public DateTime? valid_to { get; set; }
        public long approved_by { get; set; }



    }
}
