﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace CBC_Schedular.Data.Models
{
    [Table("stagehistory")]
    public class StageHistory
    {
        [Key]
        public long id { get; set; }
        public long? updateby { get; set; }
        public long? createdby { get; set; }
        public long? hospital_id { get; set; }
        public long? stageid { get; set; }
        public DateTime? stage_creation_date { get; set; }
        public DateTime? stage_update_date { get; set; }
    }
}
