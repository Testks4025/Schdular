﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace CBC_Schedular.Data.Models
{
    [Table("performance_evaluation_byassessor")]
    public class AssessorPerformanceEvalution
    {
        [Key]
        public long id { get; set; }
        public long hospital_id { get; set; }
        public long asmt_id { get; set; }
 
        [Column(TypeName = "jsonb")]
        public string assessor_twofdbk { get; set; }

        public string summary { get; set; }
        public DateTime? createdon { get; set; }
        public DateTime? updatedon { get; set; }
  
        public long? created_by { get; set; }

        
    }

}
