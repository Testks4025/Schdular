﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace CBC_Schedular.Data.Models
{
    [Table("hospital_quesbank")]
    public class HospitalQuestionBank
    {
        [Key]
        public long id { get; set; }
        public long? section_id { get; set; }
        public long ques_stndrd_code { get; set; }
        public string ques_text { get; set; }
        public string ques_help_text { get; set; }
        public string question_property { get; set; }
    }

    [Table("center_quesbank")]
    public class CenterQuestionBank
    {
        [Key]
        public long id { get; set; }
        public long? section_id { get; set; }
        public long ques_stndrd_code { get; set; }
        public string ques_text { get; set; }
        public string ques_help_text { get; set; }
        public string question_property { get; set; }
    }

}
