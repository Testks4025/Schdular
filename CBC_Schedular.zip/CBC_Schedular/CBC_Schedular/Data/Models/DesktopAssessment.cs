﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace CBC_Schedular.Data.Models
{
    [Table("desktop_assessment")]
    public class DesktopAssessment
    {
        [Key]

      public long  id { get; set; }
        public long hospid { get; set; }
        public long dauser_id { get; set; }
        public String da_suggestion_remark { get; set; }
        public String da_reject_remark { get; set; }
        public DateTime? da_complete_date { get; set; }
        public DateTime? assessment_date { get; set; }

        
        public DateTime? created_on { get; set; }
        public DateTime? updated_on { get; set; }

        public bool? declar { get; set; }

        public bool? declaration_asr { get; set; }

    }
}
