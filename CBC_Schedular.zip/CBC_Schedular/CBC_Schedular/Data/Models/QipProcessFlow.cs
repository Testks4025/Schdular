﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CBC_Schedular.Data.Models
{
    [Table("qip_process_flow")]
    public class QipProcessFlow
    {
        [Key]
        [Column("id")]
        public int id { get; set; }   // Identity (auto-generated)

        [Column("institute_id")]
        public long instituteId { get; set; }   // NOT NULL

        [Column("pillar")]
        public string Pillar { get; set; }   // NOT NULL

        [Column("pillar_weightage")]
        public decimal PillarWeightage { get; set; }   // NOT NULL

        [Column("metric_no")]
        public string MetricNo { get; set; }   // NOT NULL

        [Column("maximum_stage")]
        public int MaximumStage { get; set; }   // NOT NULL

        [Column("simulated_score")]
        public double SimulatedScore { get; set; }

        [Column("score")]
        public double Score { get; set; }

        [Column("potential_gain")]
        public double PotentialGain { get; set; }

        [Column("aspiredscore_potential_gain")]
        public double AspiredScore_PotentialGain { get; set; }
        [Column("aspiredscore_score")]
        public double aspiredScore_score { get; set; }

        [Column("health_status")]
        public string HealthStatus { get; set; }

        [Column("pillar_average")]
        public decimal? PillarAverage { get; set; }

        [Column("aspiring_stage_score")]
        public int? AspiringStageScore { get; set; }

        [Column("action_points")]
        public string ActionPoints { get; set; }

        [Column("timeline")]
        public string Timeline { get; set; }

        [Column("mentor_remarks")]
        public string MentorRemarks { get; set; }
        [Column("overall_remarks")]
        public string overallRemarks { get; set; }

        [Column("admin_remarks")]
        public string AdminRemarks { get; set; }

        [Column("status")]
        public bool status { get; set; }

        [Column("stage")]
        public int? stage { get; set; }   // ✅ Added (values: 5,10,15,20,25)

        [Column("created_date")]
        public DateTime CreatedDate { get; set; }

        [Column("updated_date")]
        public DateTime? UpdatedDate { get; set; }
        [Column("is_admin_approved")]
        public bool IsAdminApproved { get; set; } = false;

        [Column("is_admin_rejected")]
        public bool IsAdminRejected { get; set; } = false;


        // 🆕 Added properties
        [Column("agency_remarks")]
        public string AgencyRemarks { get; set; }

        [Column("imageurl")]
        public string ImageUrl { get; set; }

        [Column("is_mentor_approved")]
        public bool IsMentorApproved { get; set; } = false;

        [Column("is_mentor_rejected")]
        public bool IsMentorRejected { get; set; } = false;

        [Column("is_agency_approved")]
        public bool IsagencyApproved { get; set; } = false;

        [Column("is_agency_rejected")]
        public bool IsagencyRejected { get; set; } = false;
    }
}
