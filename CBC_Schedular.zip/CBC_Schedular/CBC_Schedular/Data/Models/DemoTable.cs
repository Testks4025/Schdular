﻿using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace CBC_Schedular.Data.Models
{
    [Table("user_test")]
    public class DemoTable
    {

        [Key]
        public int id { get; set; }
        public String name { get; set; }
        public String email { get; set; }
        public String password { get; set; }
        public String gender { get; set; }
        public int role_id { get; set; }
      
        public String mobile { get; set; }

        
    }


    public class DemoTableDto
    {
        public int id { get; set; }
        public String name { get; set; }
        public String email { get; set; }
        public String password { get; set; }
        public String gender { get; set; }
        public int role_id { get; set; }

        public String mobile { get; set; }
        public String role { get; set; }
    }
}
