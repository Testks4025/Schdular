﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace CBC_Schedular.Data.Models
{
    [Table("department")]
    public class Department
    {
        [Key]
        public long id { get; set; }
        public long department_id { get; set; }
        public long ministry_id { get; set; }
        public String department_name { get; set; }

    }
}
