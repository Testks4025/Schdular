﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CBC_Schedular.Data.Enum
{
   public enum InstituteStages
    {

        Registration=5,
Registration_Accepted=10,
        DA_Allocated = 15,

        Registration_Rejected = 20,

        Application_in_Progress = 30,
        Part_A_Submitted = 35,
        Application_Submitted = 40,
        DA_In_Progress = 50,

        //DA_NC_Reply_1 = 60,
        //DA_NC_Review_1 = 70,
        //DA_NC_Reply_2 = 80,
        //DA_NC_Review_2 = 90,
        //DA_NC_Reply_3 = 100,
        //DA_NC_Review_3=105,


        DA_NC_Raise_1 = 60,
        DA_NC_Reply_1 = 70,
        DA_NC_Review_1 = 80,
        DA_NC_Reply_2 = 90,
        DA_NC_Review_2 = 100,
        DA_NC_Reply_3 = 105,

        DA_Accepted = 110,
        DA_Rejected = 120,
        Agency_Onsite_Allocated = 125,
        OA_Allocated = 130,
        OA_In_Progress = 140,
        OA_Completed = 150,
        OA_Feedback = 160,
        QC_Completed= 165,
        Certificate_Generated = 170,
        ReVisit = 175,
        
        Re_Applied = 180,
        Institute_QIP_Accepted =190,
        Institute_QIP_Rejected =195,
        Agency_QIP_Allocated = 200,
        Mentor_QIP_Allocated = 205,
        QIP_Implemented = 210,
        QIP_Completed = 220

    }
}
