﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;
using CBC_Schedular.Data.Models;
using CBC_Schedular.Data.Models.FormBuilder;

namespace CBC_Schedular.Data.Contexts
{
    public class MyDbContext : DbContext
    {        

        public MyDbContext(DbContextOptions<MyDbContext> options) :base(options) {  }

        public DbSet<RoleMaster> RoleMasters { get; set; }
        public DbSet<UserMaster> UserMasters { get; set; }
        public DbSet<RefreshTokens> RefreshTokens { get; set; }
        public DbSet<Menu> Menus { get; set; }
        public DbSet<RolesMenus> RolesMenus { get; set; }
        public DbSet<StageMaster> StageMaster { get; set; }
      
        
        public DbSet<UserLoginLog> UserLoginLogs { get; set; }
      
        public DbSet<HospitalSectionsData> HospitalSectionsData { get; set; }
        public DbSet<InstituteSectionData> instituteSectionsData { get; set; }
        

        public DbSet<State> State { get; set; }
        public DbSet<District> District { get; set; }
        public DbSet<HospitalQueStandradCode> HospitalQueStandradCode { get; set; }
        public DbSet<CenterQueStandradCode> CenterQueStandradCode { get; set; }
        public DbSet<HospitalSections> HospitalSections { get; set; }
        public DbSet<HospitalQuestionBank> HospitalQuestionBank { get; set; }
        public DbSet<CenterQuestionBank> CenterQuestionBank { get; set; }
        public DbSet<StageHistory> StageHistory { get; set; }
        public DbSet<InstituteRegistraion> InstituteRegistraions { get; set; }
        public DbSet<CertifiedHospital> CertifiedHospital { get; set; }

        

        public DbSet<DesktopAssessment> DesktopAssessment { get; set; }
        public DbSet<DaHospitalMapping> DaHospitalMapping { get; set; }
        public DbSet<OnsiteAssessment> OnsiteAssessment { get; set; }
        public DbSet<OaHospitalMapping> OaHospitalMapping { get; set; }

        public DbSet<CcHospitalMapping> ccHospitalMapping { get; set; } // rrc


      
        public DbSet<MobileOtpHistory> mobileOtpData { get; set; }
        public DbSet<EmailOtpHistory> emailOtpData { get; set; }

        public DbSet<DaMobileOtpHistory> damobileOtpData { get; set; }
        public DbSet<OaMobileOtpHistoryApp> oamobileOtpDataapp { get; set; }
        

        public DbSet<ForgotPasswordRequest> forgotPaswordRequest { get; set; }

        public DbSet<Assessor> Assessor { get; set; } // rrc
        public DbSet<AssessorCalendar> assessorCalendars { get; set; } // rrc
        public DbSet<EduQualification> eduQualifications { get; set; } // rrc

        public DbSet<DaNcHospitalOrCenterDetails> daNcHospitalOrCenterDetails { get; set; }

        public DbSet<PaymentCollection> PaymentCollections { get; set; } // rrc
        public DbSet<UndeliveredMails> undeliveredMails { get; set; } // rrc
        public DbSet<DaNcInstituteDetails> daNcinstituteDetails { get; set; } // rrc
        public DbSet<InstituteAgencyMapping> instituteAgencyMapping { get; set; }
        public DbSet<InstituteAgencyMappingOnsite> instituteAgencyMappingOnsite { get; set; }
        public DbSet<DaInstituteMappingOnsite> daInstituteMappingOnsite { get; set; }
        public DbSet<InstituteAgencyMappingQIP> instituteAgencyMappingQIP { get; set; }
        public DbSet<InstituteMentorMappingQIP> instituteMentorMappingQIPs { get; set; }


        public DbSet<Calldetails> calldetails { get; set; }
       


        #region formbuilder
        public DbSet<FormBiulderInfo> formBiulderInfos { get; set; }
        public DbSet<FormBiulderSection> formBiulderSections { get; set; }
        public DbSet<FormBiulderQuestionType> formBiulderQuestionTypes { get; set; }
        public DbSet<FormBuilderQuestionInfo> formBuilderQuestionInfos { get; set; }
        public DbSet<FormBuilderQuestionOption> formBuilderQuestionOptions { get; set; }
        public DbSet<FormBuilderQuestionExternalRule> formBuilderQuestionExternalRules { get; set; }
        public DbSet<FormBuilderExternalQuestionRuleOptionMapping> formBuilderExternalQuestionRuleOptionMappings { get; set; }

        public DbSet<FormBuilderAssessmentResponse> formBuilderAssessmentResponse { get; set; }

        public DbSet<FormBuilderAssessmentSectionComplete> formBuilderAssessmentSectionCompletes { get; set; }

        public DbSet<FormBuilderResponseQuestionOption> formBuilderResponseQuestionOptions { get; set; }


        public DbSet<FormBuilderAssessmentResponseComplete> formBuilderAssessmentComplete { get; set; }

        public DbSet<FormBuilderGroupInfo> formBuilderGroupInfos { get; set; }


        public DbSet<HosppitalMobileResponseData> HospitalMobileResponseData { get; set; }

        public DbSet<CCdecision> CommetteeDescision { get; set; }

        public DbSet<CCPeningHistory> CCPeningHistory { get; set; }
        

        public DbSet<FormBuilderAssessmentNcHistory> formBuilderAssessmentNcHistories { get; set; }

        public DbSet<ExtensionLog> ExtensionLog { get; set; }

        public DbSet<HospitalPerformanceEvalution> hospitalPerformanceEvalution { get; set; }

        public DbSet<AssessorPerformanceEvalution> AssessorPerformanceEvalution { get; set; }
        public DbSet<HospitalCertificateUniqueNo> hospitalCertificateUniqueNo { get; set; }



       
       
      
        public DbSet<AppVersionHistory> appVersionHistory { get; set; }
        public DbSet<OnsiteAssessmentResponse> onsiteAssessmentResponse { get; set; }
        public DbSet<OnsiteAssessmentResponseQuestionOption> onsiteAssessmentResponseQuestionOption { get; set; }
        public DbSet<OnsiteAssessmentSectionComplete> onsiteAssessmentSectionComplete { get; set; }

        public DbSet<DemoTable> demouserList { get; set; }
        public DbSet<InstituteList> instituteList { get; set; }
        public DbSet<SelfAssessmentScore> selfAssessmentScore { get; set; }
        public DbSet<OnsiteAssessmentScore> onsiteAssessmentScore { get; set; }

        public DbSet<Institute_da_payment_receipt> institute_da_payment_receipt { get; set; }
        public DbSet<Institute_oa_payment_receipt> institute_oa_payment_receipt { get; set; }
        public DbSet<Ministry> ministry { get; set; }
        public DbSet<Department> department{ get; set; }


        //history purpose added by keypoint
        public DbSet<ReapplyInfo> ReapplyInfos { get; set; }

        public DbSet<QipFlowInfo> qipFlowInfos { get; set; }
        public DbSet<QipFlowInfoAdmin> qipFlowInfoAdmins { get; set; }
        public DbSet<QipImplementation> qipImplementations { get; set; }
        public DbSet<QipConsent> qipConsents { get; set; }

        public DbSet<TaskForceMember> taskForceMembers { get; set; }
        public DbSet<QipProcessFlow> qipProcessFlows { get; set; }




        #endregion


    }
}
